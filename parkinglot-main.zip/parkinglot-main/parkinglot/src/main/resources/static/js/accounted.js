
var path;

jQuery(document).ready(function($){
    path = $("#path").val();
    console.log(path);

    /**
     * 车位配置页面表格数据方法
     */
    layui.use('table', function(){
        var table = layui.table;

        var $ = layui.$;

        //第一个实例
        table.render({
            elem: '#accounts'
            ,id: 'accounts'
            ,height: 480
            ,url: path + '/accounted/findAccounteds' //数据接口
            ,page: true //开启分页
            ,cols: [[ //表头
                {field: 'carNum', title: '车牌号', width:'20%',align:"center"}
                ,{field: 'enterTime', title: '入场时间', width:'20%',align:"center"}
                ,{field: 'outTime', title: '出场时间', width:'20%',align:"center"}
                ,{field: 'stay', title: '停车时间', width:'20%',align:"center"}
                ,{field: 'fee', title: '收取费用', width:'20%',align:"center"}
            ]]
        });

        // var $ = layui.$, active = {
        //     reload : function () {
        //
        //         table.reload('accounts',{
        //             page: {
        //                 curr: 1 //重新从第 1 页开始
        //             },
        //             where: { //设定异步数据接口的额外参数，任意设
        //                 adminId: $("#adminId").val()
        //             }
        //         }, 'data');
        //     }
        // };

        // $('.searchInfo .layui-btn').on('click', function(){
        //     var type = $(this).data('type');
        //     active[type] ? active[type].call(this) : '';
        // });

    });
});





