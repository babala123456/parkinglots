setInterval("time()", 1000);
var surplus = getSurplus();
var path = getPath();

//全局的停车信息
var parkInfo;
//全局的车位信息
var placeInfo

layui.use(['upload', 'layer', 'element'], function () {
    var upload = layui.upload, layer = layui.layer, element = layui.element
    if (surplus == 0) {
        layer.msg("当前停车场已满！", {icon: 2})
    }
    //识别车牌       进场
    upload.render({
        elem: '.selFile'
        , url: path + '/recognitionEnter'
        , accept: 'images'
        , auto: 'true'
        , field: 'carNumFile'
        , done: function (res, index, upload) { //上传后的回调
            if (0 != surplus) {
                if (res.code == 0) {
                    if (res.msg == "full") {
                        layer.msg("停车场已满！", {icon: 2})
                    } else {
                        layer.msg("入场成功！", {icon: 1})
                        var carNum = res.msg1
                        var placeInfo = JSON.parse(res.msg2);
                        //打开窗口
                        setTimeout(function () {
                            open(layer,"#enter_div",false)
                        },1000)

                        //延迟信息显示
                        infoShow(carNum, placeInfo.zone, placeInfo.placeName)
                    }
                } else if (res.code == 1) {
                    if (res.msg == "carNumError") {
                        layer.msg("检测到您的车牌有误，请检查车牌", {icon: 2})
                    } else if (res.msg == "full") {
                        layer.msg("当前停车场已满！", {icon: 2})
                    }else if (res.msg ="alreadyExist"){
                        layer.msg("该车牌已在车库中！", {icon: 2})
                    }
                }
            } else {
                layer.msg("当前停车场已满！", {icon: 2})
            }
        }
        , error: function () {
            //请求异常回调
            layer.msg("网络错误，请重试", {icon: 2})
        }
    })


//识别车牌      出场
    upload.render({
        elem: '.selOutFile'
        , url: path + '/recognitionOut'
        , accept: 'images'
        , auto: 'true'
        , field: 'carNumFile'
        , done: function (res, index, upload) { //上传后的回调
            if (res.code == 0) {
                var carNum = res.carNum;
                var parkTime = res.parkTime;
                if (res.msg=="white") {

                   setTimeout(function () {
                        open(layer,"#out_div",true)
                   },1000)
                    //延迟信息显示
                    outInfoShow(carNum, parkTime, 0,"白名单")
                    parkInfo = {"carNum":carNum,"parkTime":parkTime,"price":0,'particulars':'停车场停车，停车时间：'+parkTime,'payType':'park','recordId':res.recordId}
                }else if (res.msg=="month"){

                    setTimeout(function () {
                        open(layer,"#out_div",true)
                    },1000)
                    //延迟信息显示
                    outInfoShow(carNum, parkTime, 0,"包月用户")
                    parkInfo = {"carNum":carNum,"parkTime":parkTime,"price":0,'particulars':'停车场停车，停车时间：'+parkTime,'payType':'park','recordId':res.recordId}
                }else if (res.msg == "temporary"){
                    setTimeout(function () {
                        open(layer,"#out_div",true)
                    },1000)
                    //延迟信息显示
                    outInfoShow(carNum, parkTime, res.money,"临时用户")
                    parkInfo = {"carNum":carNum,"parkTime":parkTime,"price":res.money,'particulars':'停车场停车，停车时间：'+parkTime,'payType':'park','recordId':res.recordId}

                }
            }else if (res.code ==1){
                if (res.msg=="carNumError"){
                    layer.msg("车牌错误，请重新扫描校验", {icon: 2})
                }else if (res.msg == "nonentity"){
                    layer.msg("该车不在车库中，请找人工检查", {icon: 2})
                }
            }
        }
        , error: function () {
            //请求异常回调
            layer.msg("网络错误，请重试", {icon: 2})
        }


    })


})
// ---------------------------------------------------------

//手动输入车牌      进场
function manualCarNum() {
    if (0 != surplus) {
        layer.prompt({
            formType: 0,
            value: '',
            title: '请输入车牌',
            area: ['300px', '350px'] //自定义文本域宽高
        }, function (value, index, elem) {
            if (isVehicleNumber(value)) {
                $.ajax({
                    url: path + '/manualCarNum',
                    data: 'carNum=' + value,
                    dataType: 'text',
                    success: function (data) {
                        layer.close(index);
                        var jsonData = JSON.parse(data)
                        if (jsonData.code == 0) {
                            var carNum = jsonData.msg1;
                            var placeInfo = JSON.parse(jsonData.msg2);
                            layer.msg("入场成功！", {icon: 1})
                            layer.close();
                            setTimeout(function () {
                                open(layer,"#enter_div",false)
                            })
                            infoShow(carNum, placeInfo.zone, placeInfo.placeName)
                        } else if (jsonData.code == 1) {
                            console.log("msg:"+jsonData.msg)
                            if (jsonData.msg == "lose") {
                                layer.msg("lose,停车失败！", {icon: 2})
                            }else if(jsonData.msg == "carNumError"){
                                console.log("走到了carNumError")
                                layer.msg("检测到您的车牌有误，请检查车牌", {icon: 2})
                            } else if (jsonData.msg == "full") {
                                layer.msg("车位已满！", {icon: 2})
                            }else if (jsonData.msg =="alreadyExist"){
                                console.log("走到了alreadyExist")
                                layer.msg("该车已在车库中！", {icon: 2})
                            }
                        }
                    }
                    , error: function () {
                        layer.msg("网络错误！", {icon: 2})
                    }
                })
            } else {
                layer.msg("请输入正确的车牌！", {icon: 2})
            }
        });
    } else {
        layer.msg("当前停车场已满！", {icon: 2})
    }
}

//------------------------------------------------------------------

//手动输入车牌      出场
function manualCarNumOut() {
    layer.prompt({
        formType: 0,
        value: '',
        title: '请输入车牌',
        area: ['300px', '350px'] //自定义文本域宽高
    }, function (value, index, elem) {
        if (isVehicleNumber(value)) {
            $.ajax({
                url: path + '/manualOut',
                data: 'carNum=' + value,
                dataType: 'text',
                success: function (data) {
                    layer.close(index);
                    var res = JSON.parse(data)
                    if (res.code === 0) {
                        var carNum = res.carNum;
                        var parkTime = res.parkTime;
                        if (res.msg=="white") {
                            setTimeout(function () {
                                open(layer,"#out_div",true)
                            },1000)
                            //延迟信息显示
                            outInfoShow(carNum, parkTime, 0,"白名单")
                            parkInfo = {"carNum":carNum,"parkTime":parkTime,"price":0,'particulars':'停车场停车，停车时间：'+parkTime,'type':'park','recordId':res.recordId}
                        }else if (res.msg=="month"){
                            setTimeout(function () {
                                open(layer,"#out_div")
                            },1000)
                            //延迟信息显示
                            outInfoShow(carNum, parkTime, 0,"包月用户")
                            parkInfo = {"carNum":carNum,"parkTime":parkTime,"price":0,'particulars':'停车场停车，停车时间：'+parkTime,'payType':'park','recordId':res.recordId}
                        }else if (res.msg == "temporary"){

                            setTimeout(function () {
                                open(layer,"#out_div",true)
                            },1000)
                            //延迟信息显示
                            outInfoShow(carNum, parkTime, res.money,"临时用户")
                            parkInfo = {"carNum":carNum,"parkTime":parkTime,"price":res.money,'particulars':'停车场停车，停车时间：'+parkTime,'payType':'park','recordId':res.recordId}
                        }
                    }else if (res.code ==1) {
                        if (res.msg == "carNumError") {
                            layer.msg("车牌错误或不存在，请重新扫描校验", {icon: 2})
                        }else if (res.msg === "nonentity"){
                            layer.msg("该车不在车库中，请找人工检查", {icon: 2})
                        }
                    }
                }
                , error: function () {
                    layer.msg("网络错误！", {icon: 2})
                }
            })
        } else {
            layer.msg("请输入正确的车牌！", {icon: 2})
        }
    });
}


function time() {
    var vWeek, vWeek_s, vDay;
    vWeek = ["星期天", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    var date = new Date();
    year = date.getFullYear();
    month = date.getMonth() + 1;
    day = date.getDate();
    hours = date.getHours();
    minutes = date.getMinutes();
    seconds = date.getSeconds();
    vWeek_s = date.getDay();
    $("#nowTime").text(year + "年" + month + "月" + day + "日 \t" + vWeek[vWeek_s] + "\t" + hours + ":" + minutes + ":" + seconds + "\t");
};


//车牌正则验证
function isVehicleNumber(vehicleNumber) {
    var result = false;
    if (vehicleNumber.length == 7 || vehicleNumber.length == 8) {
        var express = /^(([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z](([0-9]{5}[DF])|([DF]([A-HJ-NP-Z0-9])[0-9]{4})))|([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z][A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳使领]))$/;
        result = express.test(vehicleNumber);
    }
    return result;
}

//入场信息显示
function infoShow(carNum, zone, placeName) {
    console.log("调用了infoShow")
    setTimeout(function () {
        $("#carNum").text(carNum).fadeIn("slow")
        setTimeout(function () {
            $("#area").text(zone).fadeIn("slow")
            setTimeout(function () {
                $("#stall").text(placeName).slideDown("slow")
            }, 500)
        }, 500)
    }, 1000)
}
//出场信息显示
function outInfoShow(outCarNum, parkTime, chargeMoney,type) {
    console.log("outInfoShow")
    setTimeout(function () {
        $("#type").text(type).slideDown("slow")
        setTimeout(function () {
            $("#outCarNum").text(outCarNum).fadeIn("slow")
            setTimeout(function () {
                $("#parkTime").text(parkTime).fadeIn("slow")
                setTimeout(function () {
                    $("#chargeMoney").text(chargeMoney).slideDown("slow")
                }, 500)
            }, 500)
        }, 1000)
    },500)
}


function open(layer,div,isBtn) {
    if (isBtn){
        layer.open({
            //弹出层类型
            type: 1,
            //取值
            content: $(div),
            title:'收费信息',
            //宽高
            area: ['350px', '400px'],
            //按钮名称
            btn:['立即前往支付'],
            yes: function(index, layero){
                console.log("车牌："+parkInfo.carNum+"|||停车时间："+parkInfo.parkTime
                +"||金额："+parkInfo.price+"||描述："+parkInfo.particulars+"||类型："+parkInfo.payType)

                location.href = path+"/showPay?" +
                    "carNum="+parkInfo.carNum+"" +
                    "&parkTime="+parkInfo.parkTime+
                    "&price="+parkInfo.price+
                    "&particulars="+parkInfo.particulars+
                    "&payType="+parkInfo.payType+
                    "&recordId="+parkInfo.recordId
            },
            //按钮位置
            btnAlign: 'c',
            //透明度+遮盖层颜色
            shade: [0.5, '#393D49'],
            //渐显动画
            anim: 2,
            // time: 3000,//关闭事件
            shadeClose: true  //点击遮罩关闭
            //当检测到弹出层被关闭时，自动刷新一下界面
            //用于后面修改信息请求提交后自动刷新查看修改结果
        }, 2000);
    }else{
        layer.open({
            //弹出层类型
            type: 1,
            //取值
            content: $(div),
            title:'停车信息',
            //宽高
            area: ['350px', '400px'],
            //按钮位置
            btnAlign: 'c',
            //透明度+遮盖层颜色
            shade: [0.5, '#393D49'],
            btn:['立即前往主页'],
            yes: function(index, layero){
                location.href=path+"/userMain";
            },
            //渐显动画
            anim: 2,
            // time: 3000,//关闭事件
            shadeClose: true  //点击遮罩关闭
            //当检测到弹出层被关闭时，自动刷新一下界面
            //用于后面修改信息请求提交后自动刷新查看修改结果
        }, 2000);
    }

}