
var path;
var placeId;

$(function () {
    path = $("#path").val();
});


/**
 * 车位配置页面表格数据方法
 */
layui.use('table', function(){
    var table = layui.table;

    //第一个实例
    table.render({
        elem: '#places'
        ,id: 'placeId'
        ,height: 480
        ,width: 1100
        ,url: path + '/place/findPlacesByPage' //数据接口
        ,page: true //开启分页
        ,cols: [[ //表头
            // {field: 'placeId', title: '车位ID', width:80, sort: true}
            {field: 'placeName', title: '车位名', width:'10%',align:"center"}
            ,{field: 'zone', title: '区域', width:'10%',align:"center"}
            ,{field: 'pointX', title: 'X轴坐标位置', width:'17%',align:"center"}
            ,{field: 'pointY', title: 'Y轴坐标位置', width:'17%',align:"center"}
            ,{field: 'showUse', title: '车位状态', width:'13%',align:"center"}
            ,{field: 'showState', title: '停车状态', width:'13%',align:"center"}
            ,{field: 'caozuo', title: '操作', width: '20%' , templet:"#bar",align:"center"}
        ]]
    });
    //监听工具条
    table.on('tool(myPlace)', function(obj){
        var data = obj.data;
        var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
        var tr = obj.tr; //获得当前行 tr 的 DOM 对象（如果有的话）

        var xhr = new XMLHttpRequest();
        var path = $("#path").val();

        if(layEvent === 'ban'){ //禁用

            layer.confirm('您确定要禁用当前车位吗？',function () {
                var place = {"placeId":data["placeId"],"isUse":7};
                var placeJson = JSON.stringify(place);

                $.ajax({
                    url: path + "/place/changeState",
                    data: placeJson,
                    contentType: "application/json",
                    dataType: "text",
                    type: "post",

                    success : function (data) {

                        if(data == "success")
                        {
                            layer.msg("禁用车位操作成功！");

                            obj.update({
                                isUse:7,
                                showUse: "禁用",
                                caozuo: 0
                            });
                        }
                        else if(data == "fail")
                        {
                            layer.msg("禁用车位操作失败！");
                        }
                    },

                    error : function () {
                        alert("网络繁忙，请稍后重试！");
                    }
                });
            })

        } else if(layEvent === 'reuse'){

            layer.confirm('您确定要启用当前车位吗？',function () {
                var place = {"placeId":data["placeId"],"isUse":6};
                var placeJson = JSON.stringify(place);

                $.ajax({
                    url: path + "/place/changeState",
                    data: placeJson,
                    contentType: "application/json",
                    dataType: "text",
                    type: "post",

                    success : function (info) {
                        if(info == "success")
                        {
                            layer.msg("启用车位操作成功！");

                            obj.update({
                                isUse: 6,
                                showUse: "启用",
                                caozuo: 0
                            });
                        }
                        else if(info == "fail")
                        {
                            layer.msg("启用车位操作失败！");
                        }
                    },

                    error : function () {
                        alert("网络繁忙，请稍后重试！");
                    }

                });
            })
        } else if(layEvent === 'delete'){ //删除

            layer.confirm('您确定要修改当前车位为已删除状态吗？', function(index){
                obj.del(); //删除对应行（tr）的DOM结构，并更新缓存
                layer.close(index);

                var place = {"placeId":data["placeId"],"isUse":8};
                var placeJson = JSON.stringify(place);

                //向服务端发送删除指令
                $.ajax({
                    url: path + "/place/changeState",
                    data: placeJson,
                    contentType: "application/json",
                    dataType: "text",
                    type: "post",

                    success : function (info) {
                        if(info == "success")
                        {
                            layer.msg("删除车位操作成功！");

                            obj.update({
                                isUse: 8,
                                showUse: "已删除",
                                caozuo: 0
                            });
                        }
                        else if(info == "fail")
                        {
                            layer.msg("删除车位操作失败！");
                        }
                    },

                    error : function () {
                        alert("网络繁忙，请稍后重试！");
                    }
                });
            });
        }
    });

    var $ = layui.$, active = {
        reload : function () {

            table.reload('placeId',{
                page: {
                    curr: 1 //重新从第 1 页开始
                },
                where: { //设定异步数据接口的额外参数，任意设
                    placeName: $("#placeName").val()
                    ,zone: $("#zone").val()
                    ,isUse: $("#isUse").val()
                    ,parkState: $("#parkState").val()
                }
            }, 'data');
        }
    };

    $('.searchInfo .layui-btn').on('click', function(){
        var type = $(this).data('type');
        active[type] ? active[type].call(this) : '';
    });

});


/*
 * 点击模型获取车位信息方法
 * @param mName
 */
function selectPlace(mName) {
    var xhr = new XMLHttpRequest();

    $.ajax({
        url: path + '/place/selectPlace',
        type: 'post',
        data: 'mName=' + mName,
        dataType: 'text',

        beforeSend : function(){
            var flag = false;

            if(mName != undefined && mName != "")
                flag = true;

            return flag;
        },

        success : function (info) {
            if(info == "fail") {

            }else{

                var place = JSON.parse(info);

                layer.open({
                    //layer提供了5种层类型。可传入的值有：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）
                    type: 1,
                    title: "修改车位信息",
                    area: ['420px', '260px'],
                    content: $("#changeInfo") //引用的弹出层的页面层的方式加载修改界面表单
                });

                console.log("车位状态"+place.isUse);
                console.log("停车状态"+place.parkState);

                placeId = place.placeId;
                $("#changeName").val(place.placeName);
                $("#changeZone").val(place.zone);
                $("#changeX").val(place.pointX);
                $("#changeY").val(place.pointY);

                var $pNode1 = $("<option value='6'>启用</option>");
                var $pNode2 = $("<option value='7'>禁用</option>");
                var $pNode3 = $("<option value='8'>已删除</option>");

                $("#changeUse").empty();
                $("#changeUse").append($pNode1);
                $("#changeUse").append($pNode2);
                $("#changeUse").append($pNode3);

                var $Node1 = $("<option value='9'>未停车</option>");
                var $Node2 = $("<option value='10'>已停车</option>");

                $("#changePark").empty();
                $("#changePark").append($Node1);
                $("#changePark").append($Node2);

                var optionNodes = $("option[value]");
                console.log(optionNodes.length);

                for(var i = 0;i < optionNodes.length;i++) {
                    if($(optionNodes[i]).val() == place.isUse
                        || $(optionNodes[i]).val() == place.parkState){
                        $(optionNodes[i]).prop('selected',true);
                    }
                }

                console.log("显示完毕");
            }
        }
    });
}


/*
 * 修改车位信息方法
 */
function setPlace() {

    var changeName = $("#changeName").val();
    var changeZone = $("#changeZone").val();
    var changeX = $("#changeX").val();
    var changeY = $("#changeY").val();
    var changeUse = $("#changeUse").val();
    var changePark = $("#changePark").val();

    var myPlace = {"placeId":placeId,"placeName":changeName,"zone":changeZone,
        "pointX":changeX,"pointY":changeY,"showUse":changeUse,"showState":changePark};

    var placeJson = JSON.stringify(myPlace);
    console.log("修改对象："+placeJson);

    $.ajax({
        url: path + '/place/setPlace',
        type: 'post',
        data: placeJson,
        contentType: "application/json",
        dataType: "text",

        beforeSend:function(){

            console.log("设置前判断");

            if(changeUse == undefined || changePark == "null") {
                alert("请先选择车位的状态！");
                return false;
            }else if(changePark == undefined || changePark == "null") {
                alert("请先选择停车的状态！");
                return false;
            }else{
                var flag = confirm("您确定要提交当前修改吗？");
                return flag;
            }
        },

        success:function (msg) {

            if(msg == 'success'){

                layer.msg("修改成功！");

                $("#changeName").val(changeName);
                $("#changeZone").val(changeZone);
                $("#changeUse").val(changeUse);
                $("#changePark").val(changePark);
            }else if(msg == "fail"){
                layer.msg("修改失败", {icon: 5});
            }else if(msg == "duplicated"){
                layer.msg("当前区域已存在相同车位名，请重试！");
            }
        }
    })
}


function toPlaceMg() {
    location.href = path + '/map/toMapMg';
}