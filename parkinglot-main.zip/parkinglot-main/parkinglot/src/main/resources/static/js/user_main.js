
var path  = getPath();

layui.use(['layer','form'],function () {
    var layer = layui.layer,form = layui.form;

    form.on('submit(loginSubmit)',function (data) {
        var user = {"account":data.field.account,"password":data.field.password}
        $.ajax({
            url:path+"/userLogin",
            data:user,
            type:"post",
            datatype: "text",
            success:function (data) {
                if (data=="success"){
                    layer.closeAll(); //疯狂模式，关闭所有层
                    layer.msg("登录成功",{icon:1})
                    setTimeout(function () {
                       location.href = path+"/findUserCarInfo"
                    },1200)
                }else if (data=="lose"){
                    layer.msg("登录失败，账号或密码错误，请重新输入",{icon:5})
                }
            },
            error:function () {
                layer.msg("网络错误",{icon:5})
            }
        })
        return false;
    })

})

//弹出层
function gotoLogin() {
    open(layer,'#userLogin')
}

//退出登录
function quite() {

}

// 弹窗方法
function open(layer,div) {
    layer.open({
        //弹出层类型
        type: 1,
        //取值
        content: $(div),
        //宽高
        area: ['350px', '400px'],
        //按钮名称
        // btn:['确认修改'],
        //按钮位置
        btnAlign: 'c',
        //透明度+遮盖层颜色
        shade: [0.5, '#393D49'],
        //渐显动画
        anim: 2,
        shadeClose: true  //点击遮罩关闭
        //当检测到弹出层被关闭时，自动刷新一下界面
        //用于后面修改信息请求提交后自动刷新查看修改结果
    });
}