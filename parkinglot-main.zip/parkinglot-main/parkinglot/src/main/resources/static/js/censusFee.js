
var path;
var myChart;

var nameArr = [];
var valueArr = [];

$(function() {

    path = $("#path").val();

    //初始调用统计方法
    feeCensus();

});


layui.use('laydate', function () {
    var laydate = layui.laydate;

    laydate.render({
        elem: '#startTime'
    });

    laydate.render({
        elem: '#endTime'
    });
})


/**
 * 缴费统计向服务器请求数据的方法
 */
function feeCensus() {

    var startTime = $("#startTime").val();  //起始时间
    var endTime = $("#endTime").val();  //终止时间

    if(startTime == undefined)
        startTime = "";
    if(endTime == undefined)
        endTime = "";


    $.ajax({
        method : "post",
        data: "startTime=" + startTime + "&endTime=" + endTime + "&methodName=feeCensus",
        url : path + "/census/doCensus",
        dataType : "text",

        success : function(info) {
            $("#counts").text(info.split("&")[2]);

            var nameList = JSON.parse(info.split("&")[0]);
            var countList = JSON.parse(info.split("&")[1]);

            console.log(nameList);
            console.log(countList);

            $(nameList).each(function (i) {
                nameArr.push(nameList[i]);
            });

            $(countList).each(function (i) {
                valueArr.push(countList[i]);
            });

            createEchars();// 创建普通柱状图
        },

        error : function() {
            alert("网络繁忙，请稍后重试...");
        }
    });
}


//创建柱状图
function createEchars() {

    if (myChart != null && myChart != "" && myChart != undefined) {
        myChart.dispose();//销毁
    }

    //基于准备好的dom，初始化echarts实例
    myChart = echarts.init(document.getElementById("echarts_div"));

    // 指定图表的配置项和数据
    var option = {
        title : {},
        tooltip : {},
        legend : {},
        xAxis : {
            data : nameArr
        },
        yAxis : {},
        series : [ {
            name : '缴费数量',
            type : 'bar',
            data : valueArr
        } ],
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);
    valueArr = [];
    nameArr = [];
}

