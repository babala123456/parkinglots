
var path;
var ruleId;

$(function () {
    path = $("#path").val();
});


layui.use('laydate', function(){
    var laydate = layui.laydate;

    //执行一个laydate实例
    laydate.render({
        elem: '#sOneTime',//指定元素
    });

    laydate.render({
        elem: '#sTwoTime', //指定元素
    });

    laydate.render({
        elem: '#eOneTime', //指定元素
    });

    laydate.render({
        elem: '#eTwoTime', //指定元素
    });

    laydate.render({
        elem: '#changeStart', //指定元素
        type: 'datetime'
    });

    laydate.render({
        elem: '#changeEnd', //指定元素
        type: 'datetime'
    });

});



/**
 * 规则配置页面表格数据方法
 */
layui.use('table', function(){
    var table = layui.table;

    //第一个实例
    table.render({
        elem: '#rules'
        ,id: 'ruleId'
        ,height: 480
        ,url: path + '/rule/findRulesByPage' //数据接口
        ,page: true //开启分页
        ,cols: [[ //表头
            // {field: 'ruleId', title: '规则ID', width:80, sort: true}
            {field: 'ruleName', title: '规则名字', width:'10%',align:"center"}
            ,{field: 'showState', title: '规则状态', width:'8%',align:"center"}
            ,{field: 'startDay', title: '起效时间', width:'15%',align:"center"}
            ,{field: 'endDay', title: '终止时间', width:'15%',align:"center"}
            ,{field: 'showFree', title: '是否免费', width:'8%',align:"center"}
            ,{field: 'baseTime', title: '不计费时限', width:'10%',align:"center"}
            ,{field: 'basicMoney', title: '基本费用', width:'8%',align:"center"}
            ,{field: 'oneLevel', title: '第一等级时限', width:'11%',align:"center"}
            ,{field: 'oneMoney', title: '第一等级费用', width:'11%',align:"center"}
            ,{field: 'twoLevel', title: '第二等级时限', width:'11%',align:"center"}
            ,{field: 'twoMoney', title: '第二等级费用', width:'11%',align:"center"}
            ,{field: 'thridLevel', title: '第二等级时限', width:'11%',align:"center"}
            ,{field: 'thridMoney', title: '第二等级费用', width:'11%',align:"center"}
            ,{field: 'caozuo', title: '操作', width: '20%' , templet:"#bar",align:"center"}
        ]]
    });

    //监听工具条
    table.on('tool(myRule)', function(obj){
        var data = obj.data;
        var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
        var tr = obj.tr; //获得当前行 tr 的 DOM 对象（如果有的话）

        var xhr = new XMLHttpRequest();
        var path = $("#path").val();

        if(layEvent === 'ban'){ //禁用

            layer.confirm('您确定要不启用当前规则吗？',function () {
                var rule = {"ruleId":data["ruleId"], "ruleState":13};
                var ruleJson = JSON.stringify(rule);

                $.ajax({
                    url: path + "/rule/changeState",
                    data: ruleJson,
                    contentType: "application/json",
                    dataType: "text",
                    type: "post",

                    success : function (data) {

                        if(data == "success")
                        {
                            layer.msg("不启用规则操作成功！");

                            obj.update({
                                ruleState: 13,
                                showState: "未启用",
                                caozuo: 0
                            });
                        }
                        else if(data == "fail")
                        {
                            layer.msg("不启用规则操作失败！");
                        }
                    },

                    error : function () {
                        alert("网络繁忙，请稍后重试！");
                    }
                });
            })

        } else if(layEvent === 'reuse'){ //启用

            layer.confirm('您确定要启用当前规则吗？',function () {
                var rule = {"ruleId":data["ruleId"], "ruleState":12};
                var ruleJson = JSON.stringify(rule);

                $.ajax({
                    url: path + "/rule/changeState",
                    data: ruleJson,
                    contentType: "application/json",
                    dataType: "text",
                    type: "post",

                    success : function (info) {
                        if(info == "success")
                        {
                            layer.msg("启用规则操作成功！");

                            obj.update({
                                ruleState: 12,
                                showState: "启用",
                                caozuo: 0
                            });
                        }
                        else if(info == "fail")
                        {
                            layer.msg("启用规则操作失败！");
                        }
                    },

                    error : function () {
                        alert("网络繁忙，请稍后重试！");
                    }

                });
            })

        } else if(layEvent === 'delete'){ //删除

            layer.confirm('您确定要修改当前规则为已删除状态吗？', function(index){
                obj.del(); //删除对应行（tr）的DOM结构，并更新缓存

                var rule = {"ruleId":data["ruleId"], "ruleState":14};
                var ruleJson = JSON.stringify(rule);

                //向服务端发送删除指令
                $.ajax({
                    url: path + "/rule/changeState",
                    data: ruleJson,
                    contentType: "application/json",
                    dataType: "text",
                    type: "post",

                    success : function (info) {
                        if(info == "success")
                        {
                            layer.msg("删除规则操作成功！");

                            obj.update({
                                ruleState: 14,
                                showState: "已删除",
                                caozuo: 0
                            });
                        }
                        else if(info == "fail")
                        {
                            layer.msg("删除车位操作失败！");
                        }
                    },

                    error : function () {
                        alert("网络繁忙，请稍后重试！");
                    }
                });
            });

        } else if(layEvent === 'change'){ //修改

            layer.open({
                //layer提供了5种层类型。可传入的值有：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）
                type: 1,
                title: "修改计费规则信息",
                area: ['420px', '260px'],
                padding_top: '20px',
                content: $("#changeInfo") //引用的弹出层的页面层的方式加载修改界面表单
            });

            ruleId = data.ruleId;
            console.log("点击id："+ruleId);

            $("#changeName").val(data.ruleName);
            $("#changeStart").val(data.startDay);
            $("#changeEnd").val(data.endDay);
            $("#basicMoney").val(data.basicMoney);
            $("#oneLevel").val(data.oneLevel);
            $("#twoLevel").val(data.twoLevel);
            $("#twoMoney").val(data.twoMoney);
            $("#oneMoney").val(data.oneMoney);
            $("#thridLevel").val(data.thridLevel);
            $("#thridMoney").val(data.thridMoney);

            addOption();  //添加选项

            var optionNodes = $("option[value]");
            console.log(optionNodes.length);

            for(var i = 0;i < optionNodes.length;i++) {
                if($(optionNodes[i]).val() == data.ruleState || $(optionNodes[i]).val() == data.isFree
                    || $(optionNodes[i]).val() == data.baseTime){
                    $(optionNodes[i]).prop('selected',true);
                }
            }

            $("#changeBtn").css('display','block');
            $("#myBtn").append($("#changeBtn"));

            console.log("显示完毕");
        }
    });

    var $ = layui.$, active = {
        reload : function () {

            table.reload('ruleId',{
                page: {
                    curr: 1 //重新从第 1 页开始
                },
                where: { //设定异步数据接口的额外参数，任意设
                    ruleName: $("#ruleName").val()
                    ,ruleState: $("#ruleState").val()
                    ,sOneTime: $("#sOneTime").val()
                    ,sTwoTime: $("#sTwoTime").val()
                    ,eOneTime: $("#eOneTime").val()
                    ,eTwoTime: $("#eTwoTime").val()
                }
            }, 'data');
        }
    };

    $('.searchInfo .layui-btn').on('click', function(){
        var type = $(this).data('type');
        active[type] ? active[type].call(this) : '';
    });
});


/**
 * 添加下拉框选项方法
 */
function addOption(){
    var $pNode1 = $("<option value='12'>启用</option>");
    var $pNode2 = $("<option value='13'>未启用</option>");
    var $pNode3 = $("<option value='14'>已删除</option>");

    $("#changeState").empty();
    $("#changeState").append($pNode1);
    $("#changeState").append($pNode2);
    $("#changeState").append($pNode3);

    var $Node1 = $("<option value='0'>否</option>");
    var $Node2 = $("<option value='1'>是</option>");

    $("#changeFree").empty();
    $("#changeFree").append($Node1);
    $("#changeFree").append($Node2);

    var $tNode1 = $("<option value='0'>无时限</option>");
    var $tNode2 = $("<option value='0.5'>半小时</option>");
    var $tNode3 = $("<option value='1'>一小时</option>");

    $("#changeTime").empty();
    $("#changeTime").append($tNode1);
    $("#changeTime").append($tNode2);
    $("#changeTime").append($tNode3);
}


//form表单修改规则信息
layui.use('form', function () {
    var form = layui.form;

    form.render();//刷新所有渲染效果，也可以单独熟悉某个效果

    //监听提交
    form.on('submit(*)', function(data){

        var setId = ruleId;
        var changeName = $("#changeName").val();
        var changeState = $("#changeState").val();
        var changeStart = $("#changeStart").val();
        var changeEnd = $("#changeEnd").val();
        var changeFree = $("#changeFree").val();
        var changeTime = $("#changeTime").val();
        var basicMoney = $("#basicMoney").val();
        var oneLevel = $("#oneLevel").val();
        var oneMoney = $("#oneMoney").val();
        var twoLevel = $("#twoLevel").val();
        var twoMoney = $("#twoMoney").val();
        var thridLevel = $("#thridLevel").val();
        var thridMoney = $("#thridMoney").val();

        var rule = {"ruleId":setId,"ruleName":changeName,"ruleState":changeState,
            "startDay":changeStart, "endDay":changeEnd,"isFree":changeFree,
            "baseTime":changeTime,"basicMoney":basicMoney, "oneLevel":oneLevel,
            "oneMoney":oneMoney, "twoLevel":twoLevel,"twoMoney":twoMoney,
            "thridLevel":thridLevel,"thridMoney":thridMoney};

        var ruleJson = JSON.stringify(rule);
        console.log("修改数据："+ruleJson);

        $.ajax({
            url: path + '/rule/setRule',
            type: "post",
            data: ruleJson,
            contentType: "application/json",
            dataType: "text",

            beforeSend : function() {
                var flag = false;

                if(changeName == "") {
                    alert("规则名不能为空，请重试！");
                }else if(changeStart == ""){
                    alert("起效日期不能为空，请重试！");
                }else if(changeEnd == ""){
                    alert("失效日期不能为空，请重试！");
                }else if(changeFree == 0){

                    var nodes = $("#changeInfo input[type = 'number']");
                    console.log(nodes.length);

                    for (var i = 0;i < nodes.length;i++){

                        console.log($(nodes[i]).attr("name") + " : " + $(nodes[i]).val());

                        if($(nodes[i]).val() !=  ""){
                            var flag = /^((0{1}\.\d{1,2})|([1-9]\d*\.{1}\d{1,2})|([1-9]+\d*)|0)$/.test($(nodes[i]).val());

                            if(flag == false){
                                var tipNode = $(nodes[i]).parent().prev();
                                console.log(tipNode);
                                alert("输入的" + $(tipNode).text() +"格式应为正数，请重试!");
                            }
                        }
                    }

                    return true;
                }
                else
                    return true;
            },

            success: function (info) {
                if (info == "success") {

                    alert("修改规则信息成功！");


                }
                else if(info == "fail")
                {
                    alert("修改规则信息成功失败！");
                }
            },

            error : function () {
                layer.msg("当前网络繁忙，请稍后重试！");
            }
        });
        return false;
    });
});


/**
 * 弹出新增规则
 */
function showNew() {
    layer.open({
        //layer提供了5种层类型。可传入的值有：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）
        type: 1,
        title: "修改计费规则信息",
        area: ['420px', '260px'],
        padding_top: '20px',
        content: $("#changeInfo") //引用的弹出层的页面层的方式加载修改界面表单
    });

    addOption();  //添加选项

    // if($("#myBtn").children().length > 0)
    //     $("#myBtn").empty();
    $("#newBtn").css('display','block');
    $("#myBtn").append($("#newBtn"));

    console.log("新增层显示完毕");
}


/**
 * 正数检验
 * @param num
 * @returns {boolean}
 */
function testZheng(num) {
    var res = /^((0{1}\.\d{1,2})|([1-9]\d*\.{1}\d{1,2})|([1-9]+\d*)|0)$/.test(num);
    return res;
}


/**
 * 新增规则方法
 */
function newRule() {

    var changeName = $("#changeName").val();
    var changeState = $("#changeState").val();
    var changeStart = $("#changeStart").val();
    var changeEnd = $("#changeEnd").val();
    var changeFree = $("#changeFree").val();
    var changeTime = $("#changeTime").val();
    var basicMoney = $("#basicMoney").val();
    var oneLevel = $("#oneLevel").val();
    var oneMoney = $("#oneMoney").val();
    var twoLevel = $("#twoLevel").val();
    var twoMoney = $("#twoMoney").val();
    var thridLevel = $("#thridLevel").val();
    var thridMoney = $("#thridMoney").val();

    var rule = {"ruleName":changeName,"ruleState":changeState,
        "startDay":changeStart, "endDay":changeEnd,"isFree":changeFree,
        "baseTime":changeTime,"basicMoney":basicMoney, "oneLevel":oneLevel,
        "oneMoney":oneMoney, "twoLevel":twoLevel,"twoMoney":twoMoney,
        "thridLevel":thridLevel,"thridMoney":thridMoney};

    var ruleJson = JSON.stringify(rule);

    console.log("新增对象："+ruleJson);

    $.ajax({
        url: path + '/rule/newRule',
        type: 'post',
        data: ruleJson,
        contentType: "application/json",
        dataType: "text",

        beforeSend : function() {

            if(changeName == "") {
                alert("规则名不能为空，请填写！");
                return false;
            }

            if(changeStart == ""){
                alert("起效日期不能为空，请填写！");
                return false;
            }else{
                var date = new Date();
                var now = date.toLocaleDateString().replaceAll
                    ("/","-") + " " + date.getHours()
                    + ":" + date.getMinutes() + ":" + date.getSeconds();
                console.log(now);
                console.log("起始时间是否大于当前时间：" + changeStart > now);

                if(changeStart < now){
                    alert("起效时间不能小于当前时间，请重试！");
                    return false;
              }
            }

            if(changeEnd == ""){
                alert("失效日期不能为空，请填写！");
                return false;
            }else{
                if(changeEnd <= changeStart){
                    alert("终止时间必须大于起始时间，请重试！");
                    return false;
                }
            }

            //不免费
            if(changeFree == 0){

                if(changeTime == 0){
                alert("非免费规则下，基础的免费时限不能为无时限！请重新填写！");
                return false;
                }

                if(basicMoney == ""){
                alert("非免费规则下，基本费用不能为空，请重新填写！");
                return false;
            }else if(testZheng(basicMoney) == false){
                alert("基本费用必须是一个大于零的数，请重新填写！");
                return false;
            }

                if(oneLevel != ""){
                if(!testZheng(oneLevel)){
                    alert("第一等级时限必须是一个大于零的数，请重新填写！");
                    return false;
                }else{
                    if(oneMoney == ""){
                        alert("第一等级时限不为空时，第一等级费用不能为空，请重新填写！");
                        return false;
                    }else if(testZheng(oneMoney) == false){
                        alert("第一等级费用的格式不符合正数规范，请重新填写！");
                        return false;
                    }
                }
            }

                if(twoLevel != ""){
                if(!testZheng(twoLevel)){
                    alert("第二等级时限必须是一个大于零的数，请重新填写！");
                    return false;
                }else{
                    if(twoMoney == ""){
                        alert("第二等级时限不为空时，第二等级费用不能为空，请重新填写！");
                        return false;
                    }else if(testZheng(twoMoney) == false){
                        alert("第二等级费用的格式不符合正数规范，请重新填写！");
                        return false;
                    }
                }
            }

                if(thridLevel != ""){
                if(!testZheng(thridLevel)){
                    alert("第三等级时限必须是一个大于零的数，请重新填写！");
                    return false;
                }else{
                    if(thridMoney == ""){
                        alert("第三等级时限不为空时，第三等级费用不能为空，请重新填写！");
                        return false;
                    }else if(testZheng(thridMoney) == false){
                        alert("第三等级费用的格式不符合正数规范，请重新填写！");
                        return false;
                    }
                }
            }

                return true;
            }
            else
                return true;
        },

        success:function (msg) {

            if(msg == 'success'){

                layer.msg("新增规则成功！");
                // location.reload();

            }else if(msg == "fail"){
                layer.msg("修改失败", {icon: 5});
            }else if(msg == "duplicated"){
                layer.msg("当前规则名的规则已存在，不可重复创建！");
            }
        }
    })
}

