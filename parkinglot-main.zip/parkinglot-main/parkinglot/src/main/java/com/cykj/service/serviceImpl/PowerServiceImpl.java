package com.cykj.service.serviceImpl;

import com.cykj.mapper.PowerMapper;
import com.cykj.service.PowerService;
import com.google.gson.Gson;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service
public class PowerServiceImpl implements PowerService {
    @Resource
    private PowerMapper powerMapper;



    @Override
    public int deletePower(String roleId) {
        return powerMapper.deletePower(roleId);
    }

    @Override
    public int insertPower(String roleId, String menuId) {
        return powerMapper.insertPower(roleId, menuId);
    }

    @Override
    public int deleteAllPower(int roleId) {
        int i = powerMapper.deleteAllPower(roleId);
        return i;
    }

    @Override
    public int addPower(int menuId, int roleId) {
        int i = powerMapper.addPower(menuId, roleId);
        return i;
    }

    @Override
    public String judgePower(String arr, int roleId) {
        System.out.println("roleId:" + roleId);
        int[] ids = new Gson().fromJson(arr, int[].class);
//        将数据添加至list
        //当右边未分配菜单为空的时候 清空该ID的所有权限
        if (ids.length==0){
            int i = deleteAllPower(roleId);
            if (i>0){
                return "success";
            }else {
                return "lose";
            }
        }
        //当右边未分配的菜单不为空的时候，删除所有记录并且 添加新的权限
        if (ids.length!=0){
            //删除所有的权限
            int i  = deleteAllPower(roleId);
            System.out.println("添加前删除所有权限完毕");
            //添加所分配的权限
            int addResult = 0 ;
            for (int id:ids) {
                addResult =  addPower(id,roleId);
            }
            System.out.println("受影响的行数："+addResult);
            if (addResult>0){
                System.out.println("权限添加完毕");
                return "success";
            }else{
                return "lose";
            }
        }
        return "lose";
    }
}
