package com.cykj.service.serviceImpl;

import com.cykj.bean.TbRefund;
import com.cykj.mapper.RefundMapper;
import com.cykj.service.RefundService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class RefundServiceImpl implements RefundService {

    @Resource
    private RefundMapper refundMapper;

    @Override
    public List<TbRefund> findRefundPage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit",limit);
        map.put("offset",(curPage-1)*limit);
        return refundMapper.findRefundPage(map);
    }

    @Override
    public int findRefundNum(Map<String, Object> map) {
        return refundMapper.findRefundNum(map);
    }
}
