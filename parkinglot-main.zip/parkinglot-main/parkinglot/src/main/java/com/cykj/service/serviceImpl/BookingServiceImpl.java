package com.cykj.service.serviceImpl;

import com.cykj.bean.TbBooking;
import com.cykj.bean.TbCar;
import com.cykj.mapper.BookingMapper;
import com.cykj.service.BookingService;
import com.cykj.service.CarService;
import com.cykj.service.PlaceService;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author Administrator
 */
@Service
public class BookingServiceImpl implements BookingService {
    @Resource
    private BookingMapper bookingMapper;
    @Resource
    private PlaceService placeServiceImpl;

    @Override
    public String addBooking(TbBooking tbBooking) {
        //判断该车牌是否已经预约
        TbBooking tbBooking1 = bookingMapper.whetherBooking((int) tbBooking.getCarId(), 36);
        if (null!=tbBooking1){
            return "yetBooking";
        }else{
            int i = bookingMapper.addBooking(tbBooking);
            if (i > 0) {
                int parkState = placeServiceImpl.upParkState(35, (int) tbBooking.getPlaceId());
                if (parkState > 0) {
                    return "success";
                }
            }
            return "lose";
        }

    }

    @Override
    public List<TbBooking> findBookingByCarId(int carId) {
        return bookingMapper.findBookingByCarId(carId);
    }

    @Override
    public int findBookingCountByCarId(int carId) {
        return bookingMapper.findBookingCountByCarId(carId);
    }

    @Override
    public List<TbBooking> findBooking() {
        return bookingMapper.findBooking();
    }

    @Override
    public int findBookingCount() {
        return bookingMapper.findBookingCount();
    }

    @Override
    public TbBooking whetherBooking(int carId, int bookingState) {
        return bookingMapper.whetherBooking(carId, bookingState);
    }

    @Override
    public int updateBookingState(int bookingState, int bookingId) {
        int i = bookingMapper.updateBookingState(bookingState, bookingId);
        return i;
    }

    @Override
    public int delBooking(int bookingId) {
        return bookingMapper.delBooking(bookingId);
    }
}
