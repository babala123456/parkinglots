package com.cykj.bean;

import org.springframework.stereotype.Component;

/**
 * @author Administrator
 */
@Component
public class TbRecord {

    private int recordId;
    private int parkId;
    private String parkTime;
    private String moneyPay;
    private String outTradeNo;
    private int type;
    private TbCar tbCar;
    private TbPark tbPark;
    private TbParameter tbParameter;



  public TbRecord() {
  }

    public TbRecord(int recordId, int parkId, String parkTime, String moneyPay, String outTradeNo, int type, TbCar tbCar, TbPark tbPark, TbParameter tbParameter) {
        this.recordId = recordId;
        this.parkId = parkId;
        this.parkTime = parkTime;
        this.moneyPay = moneyPay;
        this.outTradeNo = outTradeNo;
        this.type = type;
        this.tbCar = tbCar;
        this.tbPark = tbPark;
        this.tbParameter = tbParameter;
    }

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public int getParkId() {
        return parkId;
    }

    public void setParkId(int parkId) {
        this.parkId = parkId;
    }

    public String getParkTime() {
        return parkTime;
    }

    public void setParkTime(String parkTime) {
        this.parkTime = parkTime;
    }

    public String getMoneyPay() {
        return moneyPay;
    }

    public void setMoneyPay(String moneyPay) {
        this.moneyPay = moneyPay;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public TbCar getTbCar() {
        return tbCar;
    }

    public void setTbCar(TbCar tbCar) {
        this.tbCar = tbCar;
    }

    public TbPark getTbPark() {
        return tbPark;
    }

    public void setTbPark(TbPark tbPark) {
        this.tbPark = tbPark;
    }

    public TbParameter getTbParameter() {
        return tbParameter;
    }

    public void setTbParameter(TbParameter tbParameter) {
        this.tbParameter = tbParameter;
    }
}
