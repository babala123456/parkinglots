package com.cykj.bean;

import org.springframework.stereotype.Component;

@Component
public class TbSchedules {

  private int sId;
  private int adminId;
  private int workId;
  private int scheduleState;
  private String workDay;

  private TbAdmin admins;
  private TbWork works;
  private TbParameter parameter;
  private String saName;
  private String saWorkday;
  private String saStarTime;
  private String saEndTime;
  private String saState;

  public TbSchedules() {
  }

  public TbSchedules(int sId, int adminId, int workId, int scheduleState, String workDay, TbAdmin admins, TbWork works, TbParameter parameter, String saName, String saWorkday, String saStarTime, String saEndTime, String saState) {
    this.sId = sId;
    this.adminId = adminId;
    this.workId = workId;
    this.scheduleState = scheduleState;
    this.workDay = workDay;
    this.admins = admins;
    this.works = works;
    this.parameter = parameter;
    this.saName = saName;
    this.saWorkday = saWorkday;
    this.saStarTime = saStarTime;
    this.saEndTime = saEndTime;
    this.saState = saState;
  }

  public int getsId() {
    return sId;
  }

  public void setsId(int sId) {
    this.sId = sId;
  }

  public int getAdminId() {
    return adminId;
  }

  public void setAdminId(int adminId) {
    this.adminId = adminId;
  }

  public int getWorkId() {
    return workId;
  }

  public void setWorkId(int workId) {
    this.workId = workId;
  }

  public int getScheduleState() {
    return scheduleState;
  }

  public void setScheduleState(int scheduleState) {
    this.scheduleState = scheduleState;
  }

  public String getWorkDay() {
    return workDay;
  }

  public void setWorkDay(String workDay) {
    this.workDay = workDay;
  }

  public TbAdmin getAdmins() {
    return admins;
  }

  public void setAdmins(TbAdmin admins) {
    this.admins = admins;
  }

  public TbWork getWorks() {
    return works;
  }

  public void setWorks(TbWork works) {
    this.works = works;
  }

  public TbParameter getParameter() {
    return parameter;
  }

  public void setParameter(TbParameter parameter) {
    this.parameter = parameter;
  }

  public String getSaWorkday() {
    return saWorkday;
  }

  public void setSaWorkday(String saWorkday) {
    this.saWorkday = saWorkday;
  }

  public String getSaName() {
    return admins.getaName();
  }

  public void setSaName(String saName) {
    this.saName = saName;
  }


  public String getSaStarTime() {
    return works.getStarTime();
  }

  public void setSaStarTime(String saStarTime) {
    this.saStarTime = saStarTime;
  }

  public String getSaEndTime() {
    return works.getEndTime();
  }

  public void setSaEndTime(String saEndTime) {
    this.saEndTime = saEndTime;
  }

  public String getSaState() {
    return saState;
  }

  public void setSaState(String saState) {
    this.saState = saState;
  }
}
