package com.cykj.bean;

import org.springframework.stereotype.Component;

/**
 * @author Administrator
 */
@Component
public class TbPlace {

  private int placeId;
  private String mName;
  private String placeName;
  private String zone;
  private String pointX;
  private String pointY;
  private int isUse;
  private String showUse;
  private int parkState;
  private String showState;
  private int caozuo;

  public TbPlace() {
  }

  public TbPlace(int placeId, String placeName, String zone, String pointX, String pointY,
               int isUse, int parkState) {
    this.placeId = placeId;
    this.placeName = placeName;
    this.zone = zone;
    this.pointX = pointX;
    this.pointY = pointY;
    this.isUse = isUse;
    this.parkState = parkState;
  }

  @Override
  public String toString() {
    return "TbPlace{" +
            "placeId=" + placeId +
            ", mName='" + mName + '\'' +
            ", placeName='" + placeName + '\'' +
            ", zone='" + zone + '\'' +
            ", pointX='" + pointX + '\'' +
            ", pointY='" + pointY + '\'' +
            ", isUse=" + isUse +
            ", showUse='" + showUse + '\'' +
            ", parkState=" + parkState +
            ", showState='" + showState + '\'' +
            ", caozuo=" + caozuo +
            '}';
  }

  public int getPlaceId() {
    return placeId;
  }

  public void setPlaceId(int placeId) {
    this.placeId = placeId;
  }


  public String getPlaceName() {
    return placeName;
  }

  public void setPlaceName(String placeName) {
    this.placeName = placeName;
  }


  public String getZone() {
    return zone;
  }

  public void setZone(String zone) {
    this.zone = zone;
  }


  public String getPointX() {
    return pointX;
  }

  public void setPointX(String pointX) {
    this.pointX = pointX;
  }


  public String getPointY() {
    return pointY;
  }

  public void setPointY(String pointY) {
    this.pointY = pointY;
  }


  public int getIsUse() {
    return isUse;
  }

  public void setIsUse(int isUse) {
    this.isUse = isUse;
  }


  public int getParkState() {
    return parkState;
  }

  public void setParkState(int parkState) {
    this.parkState = parkState;
  }

  public int getCaozuo() {
    return caozuo;
  }

  public void setCaozuo(int caozuo) {
    this.caozuo = caozuo;
  }

  public String getShowUse() {
    return showUse;
  }

  public void setShowUse(String showUse) {
    this.showUse = showUse;
  }

  public String getShowState() {
    return showState;
  }

  public void setShowState(String showState) {
    this.showState = showState;
  }

  public String getmName() {
    return mName;
  }

  public void setmName(String mName) {
    this.mName = mName;
  }
}
