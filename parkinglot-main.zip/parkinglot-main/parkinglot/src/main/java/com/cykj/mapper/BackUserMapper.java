package com.cykj.mapper;

import com.cykj.bean.TbRole;
import com.cykj.bean.TbUser;
import com.cykj.bean.TbWhite;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface BackUserMapper {
    public List<TbUser> findUserAll();

    public List<TbRole> roleSelect();

    public List<TbUser> selectAccount(@Param("account") String account);//查询账号是否已存在

    public int deFrontUser(@Param("userId") int userId);

    boolean changeState(@Param("userId") int userId,@Param("userState") int userState);

    public int insertUser(TbUser tbUser);//添加前台用户

    public int updateUser(TbUser tbUser);//修改前台用户信息

    List<TbUser> findUserPage(Map<String, Object> map);//分页

    int findUserNum(Map<String, Object> map);//分页数

    /**
     * 修改
     * @param userId
     * @param userName
     * @param phone
     * @param email
     * @return
     */
    public int updateUser(@Param("userId") int userId, @Param("userName") String userName,@Param("phone") String phone,@Param("email") String email);
}
