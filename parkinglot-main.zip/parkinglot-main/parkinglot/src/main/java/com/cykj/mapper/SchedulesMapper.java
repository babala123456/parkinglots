package com.cykj.mapper;

import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbSchedules;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface SchedulesMapper {
    /**
     * 查询值班表
     * @param map
     * @param starNum
     * @param endNum
     * @return
     */
    public List<TbSchedules> findSchedule(@Param("map") Map map, @Param("starNum") Integer starNum, @Param("endNum") Integer endNum);

    /**
     * 查询记录数
     * @param map
     * @return
     */
    public int findRecords(@Param("map") Map<String, Object> map);

    /**
     * 删除一条值班表信息
     * @param sId
     * @return
     */
    public int delSchedule(int sId);

    /**
     * 修改值班信息
     * @param map
     * @return
     */
    public int updateSchedule(Map map);

    /**
     * 新增排班信息
     * @param map
     * @return
     */
    public int addSchedule(Map map);

    /**
     * 查找admin的aName
     * @return
     */
    public List<TbAdmin> findAdminName();

    public TbSchedules findBySid(@Param("id") int id);

    public TbSchedules findByAdminId(@Param("adminId") int adminId,
         @Param("workDay") String workDay,@Param("time") String time);
}
