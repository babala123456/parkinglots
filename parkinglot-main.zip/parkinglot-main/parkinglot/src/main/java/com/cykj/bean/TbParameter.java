package com.cykj.bean;


public class TbParameter {

  private int pId;
  private String pType;
  private String pValue;

  public TbParameter() {
  }

  public TbParameter(int pId, String pType, String pValue) {
    this.pId = pId;
    this.pType = pType;
    this.pValue = pValue;
  }

  public int getpId() {
    return pId;
  }

  public void setpId(int pId) {
    this.pId = pId;
  }

  public String getpType() {
    return pType;
  }

  public void setpType(String pType) {
    this.pType = pType;
  }

  public String getpValue() {
    return pValue;
  }

  public void setpValue(String pValue) {
    this.pValue = pValue;
  }
}
