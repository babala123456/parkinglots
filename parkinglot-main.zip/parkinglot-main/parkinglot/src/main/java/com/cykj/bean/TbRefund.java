package com.cykj.bean;


public class TbRefund {

  private int redId;
  private int proId;
  private String redTime;
  private String unit;
  private String money;
  private TbProduct tbProduct;

    public TbRefund() {
    }

    public TbRefund(int redId, int proId, String redTime, String unit, String money, TbProduct tbProduct) {
        this.redId = redId;
        this.proId = proId;
        this.redTime = redTime;
        this.unit = unit;
        this.money = money;
        this.tbProduct = tbProduct;
    }

    public int getRedId() {
        return redId;
    }

    public void setRedId(int redId) {
        this.redId = redId;
    }

    public int getProId() {
        return proId;
    }

    public void setProId(int proId) {
        this.proId = proId;
    }

    public String getRedTime() {
        return redTime;
    }

    public void setRedTime(String redTime) {
        this.redTime = redTime;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public TbProduct getTbProduct() {
        return tbProduct;
    }

    public void setTbProduct(TbProduct tbProduct) {
        this.tbProduct = tbProduct;
    }
}
