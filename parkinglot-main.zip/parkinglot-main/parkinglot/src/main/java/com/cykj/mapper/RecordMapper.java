package com.cykj.mapper;

import com.cykj.bean.TbRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
@Repository
@Mapper
public interface RecordMapper {

    /**
     * 将车牌的消费情况添加至该表
     * @param tbRecord
     * @return
     */
    public int addRecord(TbRecord tbRecord);


    /**
     * 根据停车id查询消费记录
     * @param parkId
     * @return
     */
    public TbRecord findByParkId(int parkId);

    /**
     * 根据停车类型和时间段查询数量
     * @param type
     * @param startTime
     * @param endTime
     * @return
     */
    public int getFeeCensus(int type, String startTime, String endTime);


    public List<TbRecord> findRecordPage(Map<String,Object> map);//查询数据与模糊查询
    public int findRecordNum(Map<String,Object> map);//分页查询


    /**
     *根据日志id 更新 订单编号字段
     * @param outTradeNo
     * @param recordId
     * @return
     */
    public int updateOutTradeNo(@Param("outTradeNo") String outTradeNo, @Param("recordId") int recordId);
}
