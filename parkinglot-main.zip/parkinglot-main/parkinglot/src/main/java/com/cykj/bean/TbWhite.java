package com.cykj.bean;

public class TbWhite {

  private int whiteId;
  private String carNum;
  private String regtime;
  private String wState;


    public TbWhite() {
    }

    public TbWhite(int whiteId, String carNum, String regtime, String wState) {
        this.whiteId = whiteId;
        this.carNum = carNum;
        this.regtime = regtime;
        this.wState = wState;
    }

    public int getWhiteId() {
        return whiteId;
    }

    public void setWhiteId(int whiteId) {
        this.whiteId = whiteId;
    }

    public String getCarNum() {
        return carNum;
    }

    public void setCarNum(String carNum) {
        this.carNum = carNum;
    }

    public String getRegtime() {
        return regtime;
    }

    public void setRegtime(String regtime) {
        this.regtime = regtime;
    }

    public String getwState() {
        return wState;
    }

    public void setwState(String wState) {
        this.wState = wState;
    }

    @Override
    public String toString() {
        return "TbWhite{" +
                "whiteId=" + whiteId +
                ", carNum='" + carNum + '\'' +
                ", regtime='" + regtime + '\'' +
                ", wState='" + wState + '\'' +
                '}';
    }
}
