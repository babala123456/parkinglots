package com.cykj.mapper;

import com.cykj.bean.TbRefund;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository(value = "refundMapper")
@Mapper
public interface RefundMapper {
    public List<TbRefund> findRefundPage(Map<String, Object> map);//查询数据与模糊查询
    public int findRefundNum(Map<String, Object> map);//分页查询

}
