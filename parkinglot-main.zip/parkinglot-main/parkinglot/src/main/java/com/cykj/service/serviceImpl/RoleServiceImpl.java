package com.cykj.service.serviceImpl;

import com.cykj.bean.TbRole;
import com.cykj.mapper.RoleMapper;
import com.cykj.service.RoleService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class RoleServiceImpl implements RoleService {

    @Resource
    private RoleMapper roleMapper;

    /**
     * 查询角色
     * @return
     */
    @Override
    public List<TbRole> roleSelect() {
        return roleMapper.roleSelect();
    }

    /**
     * 模糊查询
     * @param map
     * @param curPage
     * @param limit
     * @return
     */
    @Override
    public List<TbRole> findRolePage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit", limit);
        map.put("offset", (curPage - 1) * limit);
        return roleMapper.findRolePage(map);
    }

    /**
     * 分页查询
     *
     * @param map
     * @return
     */
    @Override
    public int findRoleNum(Map<String, Object> map) {
        return roleMapper.findRoleNum(map);
    }

    /**
     * 添加角色
     * @param roleId
     * @param userRole
     * @return
     */
    @Override
    public int updateRole(int roleId, String userRole) {
        return roleMapper.updateRole(roleId, userRole);
    }

    /**
     * 添加角色
     * @param userRole
     * @return
     */
    @Override
    public int insertRole(String userRole) {
        return roleMapper.insertRole(userRole);
    }

    @Override
    public List<TbRole> findRole() {
        return null;
    }


}
