package com.cykj.service.serviceImpl;

import com.cykj.mapper.StatisticsMapper;
import com.cykj.service.StatisticsService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class StatisticsServiceImpl implements StatisticsService {
    @Resource
    public StatisticsMapper statisticsMapper;

    @Override
    public int findComboMenu(int productId) {
        return statisticsMapper.findComboMenu(productId);
    }

    @Override
    public int findusergrowth(String nowData,int mouth,int userType) {
        return statisticsMapper.findusergrowth(nowData,mouth,userType);
    }

    @Override
    public int findwhiteuser(String nowData,int mouth) {
        return statisticsMapper.findwhiteuser(nowData,mouth);
    }


//    @Override
//    public int findStatistics(String times,int i,int j) {
//        return statisticsMapper.findStatistics(times,i,j);
//    }
}
