package com.cykj.bean;


public class TbWork {

  private long wId;
  private String starTime;
  private String endTime;
  private long workState;


  public TbWork(){

  }


  public long getWId() {
    return wId;
  }

  public void setWId(long wId) {
    this.wId = wId;
  }


  public String getStarTime() {
    return starTime;
  }

  public void setStarTime(String starTime) {
    this.starTime = starTime;
  }


  public String getEndTime() {
    return endTime;
  }

  public void setEndTime(String endTime) {
    this.endTime = endTime;
  }


  public long getWorkState() {
    return workState;
  }

  public void setWorkState(long workState) {
    this.workState = workState;
  }

}
