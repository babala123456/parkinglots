package com.cykj.service.serviceImpl;

import com.cykj.bean.SpCommodity;
import com.cykj.bean.SpType;
import com.cykj.mapper.CommodityMapper;
import com.cykj.service.CommodityService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CommodityServiceImpl implements CommodityService {

    @Resource
    CommodityMapper commodityMapper;

    String result = null;

    int n;

    /**
     * 查询商品列表
     * @param map
     * @param starNum
     * @param endNum
     * @return
     */
    @Override
    public List<SpCommodity> findCommodity(Map<String, Object> map, Integer starNum, Integer endNum) {
        return commodityMapper.findCommodity(map,starNum,endNum);
    }

    //查询记录数
    @Override
    public int findComRecords(Map<String, Object> map){
        int res = commodityMapper.findComRecords(map);
        return res;
    }

    /**
     * 新增商品信息
     * @return
     */
    @Override
    public int addCommodity(String spName,int price,int inventory,int teid,String spDetails) {
        List<SpCommodity> spCommodityList = commodityMapper.findNameAgain(spName);
        if(spCommodityList.size()==0) {
            Map<String, Object> addMap = new HashMap<>();
            addMap.put("spName", spName);
            addMap.put("price", price);
            addMap.put("inventory", inventory);
            addMap.put("teid", teid);
            addMap.put("spDetails", spDetails);
            int n = commodityMapper.addCommodity(addMap);
        }else {
             n = 0;
        }
        return n;
    }

    @Override
    public List<SpCommodity> findNameAgain(String spName) {
        return commodityMapper.findNameAgain(spName);
    }

    /**
     * 修改商品信息
     * @param spName
     * @param price
     * @param inventory
     * @param spDetails
     * @param cmtId
     * @return
     */
    @Override
    public int updateCommodity(String spName, int price, int inventory, int teid,String spDetails, int cmtId) {
        List<SpCommodity> spCommodityList = commodityMapper.findNameAgain(spName);
        if(spCommodityList.size()==0) {
            return commodityMapper.updateCommodity(spName, price, inventory, teid, spDetails, cmtId);
        }else {
            return n=0;
        }
    }

    /**
     * 删除一条商品表信息
     * @param cmtId
     * @return
     */
    @Override
    public String delCommodity(int cmtId) {
        int i = commodityMapper.delCommodity(cmtId);
        if(i>0){
            result = "success";
        }else {
            result = "fail";
        }
        return result;
    }

    /**
     * 商品的禁用启用
     * @param cmtId
     * @param spState
     * @return
     */
    @Override
    public String changeSpState(int cmtId, int spState) {
        int n = commodityMapper.changeSpState(cmtId,spState);
        if(spState == 31){
            spState = 32;
            result = "success";
        }else if ( spState ==32){
            spState =31;
            result = "fail";
        }
        return result;
    }

    /**
     * 查找admin中的aName,用来做新增名称下拉
     * @return
     */
    @Override
    public List<SpType> findSpType(){
        List<SpType> spTypeList = commodityMapper.findSpType();
        return spTypeList;
    }

}
