package com.cykj.controller;


import com.cykj.bean.TbUser;
import com.cykj.service.AlipayService;
import com.cykj.util.Log;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@Controller
public class ALiPayController {

    @Resource
    private AlipayService alipayServiceImpl;



    @RequestMapping("/showProductPay")
    @Log(operationName = "访问业务支付页面",operationType = "访问业务支付页面")
    public String showProductPay(String proId, String fee, String showEffect, int carId
         , String pName, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getSession().setAttribute("proId",proId);
        request.getSession().setAttribute("showEffect",showEffect);
        request.setAttribute("type","业务缴费");
        request.getSession().setAttribute("carId", carId);
        request.setAttribute("fee",fee);
        request.setAttribute("body",pName + "套餐，有效期" + showEffect + "天。");

        TbUser user = (TbUser) request.getSession().getAttribute("user");
        if(user == null){
            request.setAttribute("unLogin",0);
            request.getRequestDispatcher("getProducts").forward(request,response);
        }else{
            request.removeAttribute("unLogin");
        }

        return "alipay/payProduct";
    }


    //用于请求首页显示支付付款功能
    @RequestMapping("/showPay")
    @Log(operationName = "访问停车费用支付页面",operationType = "访问停车费用支付页面")
    public String showPay(String carNum,String parkTime,String price,
      String particulars,String payType,int recordId, HttpServletRequest request){
        System.out.println("访问支付页面");
        Map<String,Object> map = new HashMap<>(16);
        System.out.println("record:"+recordId);
        map.put("recordId",recordId);
        map.put("carNum",carNum);
        map.put("parkTime",parkTime);
        map.put("price",price);
        map.put("particulars",particulars);
        map.put("payType",payType);
        request.getSession().setAttribute("map",map);

        return "alipay/payPark";
    }

    @RequestMapping("/doPay")
    @Log(operationName = "展示付款页面",operationType = "展示付款页面")
    public String doPay(){
        return "alipay/alipay.trade.page.pay";
    }

    @RequestMapping("/toNotify")
    @Log(operationName = "支付宝异步通知页面",operationType = "支付宝异步通知页面")
    public String toNotify(){
        System.out.println("支付宝异步通知页面");
        return "alipay/notify_url";
    }


    @RequestMapping("/toReturn")
    @Log(operationName = "支付宝同步通知页面",operationType = "支付宝同步通知页面")
    public String toReturn(){
        System.out.println("支付宝同步通知页面");
        return "alipay/return_url";
}

    //支付成功后的异步回调，用于处理服务端业务
    @RequestMapping("/notifyUrl")
    @Log(operationName = "支付成功后的异步回调",operationType = "支付成功后的异步回调")
    public void notifyUrl(HttpServletRequest request)throws Exception{
        System.out.println("异步回调");
        alipayServiceImpl.notifyUrl(request);

    }

    //支付成功后同步回调，用于展示给用户查看
    @RequestMapping("/returnUrl")
    @Log(operationName = "支付成功后同步回调",operationType = "支付成功后同步回调")
    public String returnUrl(HttpServletRequest request)throws Exception{
        System.out.println("同步回调");
        return alipayServiceImpl.returnUrl(request);
    }


    //用户点击付款后请求此方法
    @RequestMapping("/alipayTradePagePay")
    @Log(operationName = "点击付款后请求方法",operationType = "点击付款后请求方法")
    public String alipayTradePagePay(HttpServletRequest request, HttpServletResponse response) throws Exception{
        return alipayServiceImpl.alipayTradePagePay(request,response);
    }

}
