package com.cykj.mapper;

import com.cykj.bean.TbCar;
import com.cykj.bean.TbPlace;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface PlaceMapper {

    /**
     * 根据车牌号查询车位信息
     * @param carNum
     * @return
     */
    public TbPlace findByCarNum(@Param("carNum") String carNum);


    /**
     * 根据区域和车位名，判断车位是否已存在
     * @param zone
     * @param placeName
     * @return
     */
    public TbPlace findByZoneName(String zone, String placeName);


    /**
     * 点选地图模型展示车位信息
     * @param myPlace
     * @return
     */
    public int setPlace(@Param("myPlace") TbPlace myPlace);


    /**
     * 获取所有区域类型
     * @return
     */
    public List<String> getZones();


    /**
     * 条件查询数据总数
     * @param condition
     * @return
     */
    public int findRecords(@Param("condition") Map<String, Object> condition);


    /**
     * 分页查询停车位数据
     * @param condition
     * @return
     */
    public List<TbPlace> findPlacesByPage(@Param("condition") Map<String, Object> condition,
        @Param("startIndex") Integer startIndex, @Param("endIndex") Integer endIndex);


    /**
     * 修改车位状态方法
     * @param place
     * @return
     */
    public int changeState(@Param("place") TbPlace place);

    /**
     * 点选地图模型展示车位信息
     * @param mName
     * @return
     */
    public TbPlace selectPlace(@Param("mName") String mName);


    /**
     * 根据车位状态，查询车位信息
     * @param parkState
     * @return
     */
    public List<TbPlace> findByState(@Param("parkState") int parkState);


    /**
     * 根据停车状态，查询车位信息
     * @param isUse
     * @return
     */
    public List<TbPlace> findByUsed(@Param("isUse") int isUse);

    /**
     * 康春杰
     * [前台车辆入场功能]：通过参数查询车位可用数
     * @param parkState
     * @return
     */
    public int findPlaceByParkState(@Param("parkState") String parkState);

    /**
     * 康春杰
     * [前台车辆入场功能]：拿到一个可用的车位对象
     * @return
     */
    public TbPlace findUsableStall();

    /**
     * 康春杰
     * [前台车辆入场功能]：修改车位状态为 已停车
     * @param parkState
     * @param placeId
     * @return
     */
    public int upParkState(@Param("parkState")int parkState ,@Param("placeId")int placeId);

    /**
     * 康春杰
     * [车位预约功能] 根据条件动态返回    车位信息
     * 2020年11月29日16:14:18
     * @param zone
     * @param isUse
     * @param parkState
     * @return
     */
    public List<TbPlace> findBookingPlace(@Param("zone")String zone,@Param("isUse")int isUse,@Param("parkState")int parkState);


    /**
     * 康春杰
     * [车位预约功能] 根据条件动态返回    某一个区域车位可用
     * 2020年11月29日16:14:20
     * @param zone
     * @param isUse
     * @param parkState
     * @return
     */
    public int findBookingCount(@Param("zone")String zone,@Param("isUse")int isUse,@Param("parkState")int parkState);

    /**
     * 康春杰
     * [车位预约功能]  查询所有的 车位 区
     * 2020年11月29日16:14:39
     * @return
     */
    public List<TbPlace> findZone ();

    /**
     * 康春杰
     * [车位预约功能]  根据ID查询车位
     * 2020年11月29日16:14:39
     * @param placeId
     * @return
     */
    public TbPlace findPlaceByPlaceId(@Param("placeId")int placeId);
}
