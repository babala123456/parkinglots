package com.cykj.bean;


import org.springframework.stereotype.Component;

import javax.annotation.Resource;

@Component  //日结算对象
public class MyAccounted {

    private String carNum;
    private String enterTime;  //入场时间
    private String outTime;  //出场时间
    private String stay;  //停车时间
    private double fee;  //停车费用
    private String parkType;  //收费类型



    public MyAccounted() {
    }



    
    public String getCarNum() {
        return carNum;
    }

    public void setCarNum(String carNum) {
        this.carNum = carNum;
    }

    public String getEnterTime() {
        return enterTime;
    }

    public void setEnterTime(String enterTime) {
        this.enterTime = enterTime;
    }

    public String getOutTime() {
        return outTime;
    }

    public void setOutTime(String outTime) {
        this.outTime = outTime;
    }

    public String getStay() {
        return stay;
    }

    public void setStay(String stay) {
        this.stay = stay;
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }


    public String getParkType() {
        return parkType;
    }

    public void setParkType(String parkType) {
        this.parkType = parkType;
    }
}
