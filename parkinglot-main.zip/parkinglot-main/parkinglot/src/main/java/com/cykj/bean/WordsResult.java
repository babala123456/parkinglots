package com.cykj.bean;

import java.util.Arrays;

/**
 * @author Administrator
 */
public class WordsResult {
    private String number;
    private String [] vertexes_location;
    private String color;
    private String [] probability;

    public WordsResult() {
    }

    public WordsResult(String number, String[] vertexes_location, String color, String[] probability) {
        this.number = number;
        this.vertexes_location = vertexes_location;
        this.color = color;
        this.probability = probability;
    }

    @Override
    public String toString() {
        return "WordsResult{" +
                "number='" + number + '\'' +
                ", vertexes_location=" + Arrays.toString(vertexes_location) +
                ", color='" + color + '\'' +
                ", probability=" + Arrays.toString(probability) +
                '}';
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String[] getVertexes_location() {
        return vertexes_location;
    }

    public void setVertexes_location(String[] vertexes_location) {
        this.vertexes_location = vertexes_location;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String[] getProbability() {
        return probability;
    }

    public void setProbability(String[] probability) {
        this.probability = probability;
    }
}
