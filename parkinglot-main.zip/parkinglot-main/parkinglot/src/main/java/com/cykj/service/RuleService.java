package com.cykj.service;

import com.cykj.bean.TbRecord;
import com.cykj.bean.TbRule;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface RuleService {
    /**
     * 查询当前启用的计费规则
     * @return
     */
    public TbRule selUsingRule();


    /**
     * 条件查询数据总数
     * @param condition
     * @return
     */
    public int findRecords(Map<String, Object> condition);


    /**
     * 分页查询规则数据
     * @param condition
     * @return
     */
    public List<TbRule> findRulesByPage(Map<String, Object> condition,
                                        Integer startIndex, Integer endIndex);


    /**
     * 修改规则状态方法
     * @param rule
     * @return
     */
    public int changeState(TbRule rule);


    /**
     * 修改规则信息方法
     * @param rule
     * @return
     */
    public int setRule(TbRule rule);


    /**
     * 根据规则名字，查询是否已存在相同名字规则
     * @param ruleName
     * @return
     */
    public TbRule legal(String ruleName);


    /**
     * 新增规则方法
     * @param rule
     * @return
     */
    public int newRule(TbRule rule);

    /**
     * 通过 车牌 计算 费用
     * @param carNum
     * @param parkId
     * @return
     */
    public String consume(String carNum, int parkId);

}
