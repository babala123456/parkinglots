package com.cykj.service.serviceImpl;

import com.cykj.bean.TableInfo;
import com.cykj.bean.TbHandle;
import com.cykj.bean.TbUser;
import com.cykj.mapper.UserMapper;
import com.cykj.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {
    @Resource
    private UserMapper userMapper;

    @Override
    public TbUser login(String username, String userpwd) {

        return userMapper.selUser(username,userpwd);
    }

    @Override
    public List<TbHandle> findUserOrder(Map map) {
        return userMapper.findUserOrder(map);
    }

    @Override
    public TbUser userLogin(String account, String password) {
        TbUser tbUser = userMapper.userLogin(account, password);
        return tbUser;
    }

    @Override
    public int stopNumber(int userId) {
        return userMapper.stopNumber(userId);
    }

    @Override
    public String resetPassword(String password, int userId) {
        int i = userMapper.resetPassword(password, userId);
        if (i>0){
            return "success";
        }
        return "lose";
    }

    @Override
    public TbUser findUserInfo(int userId) {
        TbUser userInfo = userMapper.findUserInfo(userId);
        return userInfo;
    }

    @Override
    public int findUserOrderRecord(Map map) {
        int userOrderRecord = userMapper.findUserOrderRecord(map);
        return userOrderRecord;
    }


}

