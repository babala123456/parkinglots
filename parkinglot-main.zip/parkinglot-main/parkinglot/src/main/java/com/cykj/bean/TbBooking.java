package com.cykj.bean;

import org.springframework.stereotype.Component;

/**
 * @author Administrator
 * 车位预约
 */
@Component
public class TbBooking {

  private long bookingId;
  private long carId;
  private long placeId;
  private String temporaryPhone;
  private String bookingTime;
  private long bookingState;

  private TbCar tbCar;
  private TbPlace tbPlace;
  private TbParameter tbParameter;



  public TbBooking() {
  }


  public TbBooking(long bookingId, long carId, long placeId, String temporaryPhone, String bookingTime, long bookingState, TbCar tbCar, TbPlace tbPlace, TbParameter tbParameter) {
    this.bookingId = bookingId;
    this.carId = carId;
    this.placeId = placeId;
    this.temporaryPhone = temporaryPhone;
    this.bookingTime = bookingTime;
    this.bookingState = bookingState;
    this.tbCar = tbCar;
    this.tbPlace = tbPlace;
    this.tbParameter = tbParameter;
  }

  @Override
  public String toString() {
    return "TbBooking{" +
            "bookingId=" + bookingId +
            ", carId=" + carId +
            ", placeId=" + placeId +
            ", temporaryPhone='" + temporaryPhone + '\'' +
            ", bookingTime='" + bookingTime + '\'' +
            ", bookingState=" + bookingState +
            ", tbCar=" + tbCar +
            ", tbPlace=" + tbPlace +
            ", tbParameter=" + tbParameter +
            '}';
  }

  public TbCar getTbCar() {
    return tbCar;
  }

  public void setTbCar(TbCar tbCar) {
    this.tbCar = tbCar;
  }

  public TbPlace getTbPlace() {
    return tbPlace;
  }

  public void setTbPlace(TbPlace tbPlace) {
    this.tbPlace = tbPlace;
  }

  public TbParameter getTbParameter() {
    return tbParameter;
  }

  public void setTbParameter(TbParameter tbParameter) {
    this.tbParameter = tbParameter;
  }

  public long getBookingId() {
    return bookingId;
  }

  public void setBookingId(long bookingId) {
    this.bookingId = bookingId;
  }


  public long getCarId() {
    return carId;
  }

  public void setCarId(long carId) {
    this.carId = carId;
  }


  public String getTemporaryPhone() {
    return temporaryPhone;
  }

  public void setTemporaryPhone(String temporaryPhone) {
    this.temporaryPhone = temporaryPhone;
  }


  public String getBookingTime() {
    return bookingTime;
  }

  public void setBookingTime(String bookingTime) {
    this.bookingTime = bookingTime;
  }

  public long getPlaceId() {
    return placeId;
  }

  public void setPlaceId(long placeId) {
    this.placeId = placeId;
  }

  public long getBookingState() {
    return bookingState;
  }

  public void setBookingState(long bookingState) {
    this.bookingState = bookingState;
  }

}
