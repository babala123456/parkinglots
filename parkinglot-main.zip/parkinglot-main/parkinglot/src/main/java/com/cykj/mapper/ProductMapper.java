package com.cykj.mapper;

import com.cykj.bean.TbProduct;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface ProductMapper {

    //查询可办理的业务信息
    public List<TbProduct> getProducts();

  //按条件查找
    public List<TbProduct> findProduct(@Param("map") Map map, @Param("starNum") Integer starNum, @Param("endNum") Integer endNum);

    //查询记录数
    public int findRecords(@Param("map") Map<String, Object> map);

    //重复名判断
    public List<TbProduct> findNameAgain(String proName);

    //删除一条月缴产品数据
    public int delProduct(int proId,int proState);

    //删除一条月缴产品数据
    public int recoverProduct(int proId,int proState);

    //修改一条产品数据
    public int updateProduct(Map map);

    //月缴产品的禁用启用
    public int changeProState(int proId, int proState);

    //新增一条月缴产品数据
    public int addProduct(Map map);


}
