package com.cykj.service.serviceImpl;

import com.cykj.bean.TbRole;
import com.cykj.bean.TbUser;
import com.cykj.bean.TbWhite;
import com.cykj.mapper.BackUserMapper;
import com.cykj.mapper.UserMapper;
import com.cykj.service.BackUserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class BackUserServiceImpl implements BackUserService {

    @Resource
    private BackUserMapper backUserMapper;

    @Override
    public List<TbUser> backuserSelect() {
        return backUserMapper.findUserAll() ;
    }

    @Override
    public List<TbRole> roleSelect() {
        return backUserMapper.roleSelect();
    }

    @Override
    public List<TbUser> selectAccount(String account) {
        return backUserMapper.selectAccount(account);
    }

    @Override
    public int deFrontUser(int userId) {
        return backUserMapper.deFrontUser(userId);
    }

    @Override//用户状态修改
    public boolean changeUserState(String userId, String userState) {
        return backUserMapper.changeState(Integer.parseInt(userId),Integer.parseInt(userState));
    }

    @Override//用户注册
    public int insertUser(TbUser tbUser) {

        return backUserMapper.insertUser(tbUser);
    }


    @Override
    public List<TbUser> finduserPage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit",limit);
        map.put("offset",(curPage-1)*limit);
        List<TbUser> findUserPage = backUserMapper.findUserPage(map);
        return findUserPage;
    }

    @Override
    public int finduserNum(Map<String, Object> map) {
        int all = backUserMapper.findUserNum(map);
        return all;
    }

    /**
     * 修改
     * @param userId
     * @param userName
     * @param phone
     * @param email
     * @return
     */
    @Override
    public int updateUser(int userId, String userName, String phone, String email) {
        return backUserMapper.updateUser(userId,userName,phone,email);
    }
}
