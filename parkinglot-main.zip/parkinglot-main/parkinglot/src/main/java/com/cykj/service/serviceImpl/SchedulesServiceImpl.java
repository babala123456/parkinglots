package com.cykj.service.serviceImpl;

import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbSchedules;
import com.cykj.mapper.SchedulesMapper;
import com.cykj.service.SchedulesService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SchedulesServiceImpl implements SchedulesService {

    @Resource
    SchedulesMapper schedulesMapper;

    String result = null;
    /**
     * 查询值班表列表
     * @return
     */
    @Override
    public List<TbSchedules> findSchedule(Map<String, Object> map, Integer starNum, Integer endNum) {
        List<TbSchedules> list = schedulesMapper.findSchedule(map,starNum,endNum);
        return list;
    }

    /**
     * 查找所有记录数
     * @param map
     * @return
     */
    @Override
    public int findRecords(Map<String, Object> map) {
        int n = schedulesMapper.findRecords(map);
        return n;
    }

    /**
     * 删除一条值班表信息
     * @param sId
     * @return
     */
    @Override
    public String delSchedule(int sId) {
        int i = schedulesMapper.delSchedule(sId);
        if(i>0){
            result = "success";
        }else {
            result = "fail";
        }
        return result;
    }

    /**
     * 修改一条值班信息
     * @param saState
     * @param sId
     * @return
     */
    public int updateSchedule(String saWorkday, int workId, String saState, int sId){
        Map<String, Object> scheduleMap = new HashMap<>();
        int n = schedulesMapper.updateSchedule(scheduleMap);
        return n;
    }

    /**
     * 新增排班信息
     * @param saWorkday
     * @param workId
     * @param saState
     * @return
     */
    @Override
    public int addSchedule(int adminId, String saWorkday, int workId, int saState) {
        Map<String, Object> addMap = new HashMap<>();
        addMap.put("adminId",adminId);
        addMap.put("saWorkday",saWorkday);
        addMap.put("workId",workId);
        addMap.put("saState",saState);
        int n = schedulesMapper.addSchedule(addMap);
        return n;
    }

    /**
     * 查找admin的aName
     * @return
     */
    public List<TbAdmin> findAdminName(){
        List<TbAdmin> nameList = schedulesMapper.findAdminName();
        return nameList;
    }


    @Override
    public TbSchedules findByAdminId(int adminId,String workDay,String time) {
        return schedulesMapper.findByAdminId(adminId,workDay,time);
    }

}
