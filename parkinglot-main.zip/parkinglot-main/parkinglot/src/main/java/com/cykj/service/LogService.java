package com.cykj.service;

import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbLog;

import java.util.List;
import java.util.Map;

public interface LogService {

    List<TbLog> findLogOnPage(Map<String, Object> map, int page, int limit);

    int findLogNum(Map<String, Object> map);

    int addBackLog(TbLog tbLog);
}
