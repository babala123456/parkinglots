package com.cykj.service;

import com.cykj.bean.TbMenu;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


public interface MenuService {
    /**
     * 数据查询与模糊查询
     * @param map
     * @param page
     * @param limit
     * @return
     */
    public List<TbMenu> findMenuPage(Map<String, Object> map, int page, int limit);
    public int findMenuNum(Map<String, Object> map);//分页查询



    public Map<String, List<TbMenu>> findMenusByPid(String roleId, int relevanceId);//后台菜单栏
    public   Map<String, List<TbMenu>> laterMenu(@Param("roleid") String roleId);//角色未拥有的菜单查询
    public List<TbMenu> Menu();//总的菜单
    public int deleteMenu(int menuId);//删除菜单
    public int updateMenu(int menuId, String menuName, String menuPath, String relevanceId);//更改菜单
    public int insertMenu(String menuName, String menuPath, String relevanceId);//添加菜单

    /**
     * 测试方法拥有的菜单
     * @param roleId
     * @param relevanceId
     * @return
     */
    public List<TbMenu> findMenu(String roleId, int relevanceId);

    /**
     * 测试方法未拥有的菜单
     * @param roleId
     * @return
     */
    public List<TbMenu> lateList(String roleId);


    /**-------------------------------------------------*/
    /**
     * 康春杰
     * [权限配置功能]--返回 已拥有的菜单和未分配的菜单，放置 数组中
     * 2020年11月23日18:46:12
     * @param roleId
     * @return
     */
    public Object[] findMenu(int roleId);

    /**
     *  康春杰
     *  [权限配置功能]--返回 已拥有的菜单和未分配的菜单，放置 数组中
     *  2020年11月23日18:46:12     * 康春杰
     * @param relevanceId
     * @return
     */
    public List<TbMenu>findParent (int relevanceId);
    /**-------------------------------------------------*/
}
