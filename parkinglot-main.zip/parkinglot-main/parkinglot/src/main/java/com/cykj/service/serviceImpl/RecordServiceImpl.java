package com.cykj.service.serviceImpl;

import com.cykj.bean.TbRecord;
import com.cykj.bean.TbRefund;
import com.cykj.mapper.RecordMapper;
import com.cykj.service.RecordService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
@Service
public class RecordServiceImpl implements RecordService {
    @Resource
    private RecordMapper recordMapper;

    @Override
    public int addRecord(TbRecord tbRecord) {
        int i = recordMapper.addRecord(tbRecord);
        return i;
    }

    @Override
    public List<TbRecord> findRecordPage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit",limit);
        map.put("offset",(curPage-1)*limit);
        return recordMapper.findRecordPage(map);
    }

    @Override
    public int findRecordNum(Map<String, Object> map) {
        return recordMapper.findRecordNum(map);
    }
    @Override
    public int[] getFeeCensus(List<Integer> idList, String startTime, String endTime) {
        int[] res = new int[idList.size()];

        for (int i = 0;i < idList.size();i++){
            res[i] = recordMapper.getFeeCensus(idList.get(i),startTime,endTime);
        }

        return res;
    }

    @Override
    public int updateOutTradeNo(String outTradeNo, int recordId) {
        int i = recordMapper.updateOutTradeNo(outTradeNo, recordId);
        return i;
    }

}
