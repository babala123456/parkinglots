package com.cykj.controller;


import com.alibaba.fastjson.JSON;
import com.cykj.bean.TableInfo;
import com.cykj.bean.TbPlace;
import com.cykj.service.PlaceService;
import com.cykj.util.Common;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/place")
public class PlaceController {

    @Resource
    private PlaceService placeServiceImpl;


    /**
     * 跳转车位配置页面方法
     * @return
     */
    @RequestMapping("/toPlaceMg")
    @Log(operationName = "访问车位配置页面",operationType = "访问车位配置页面")
    public String toPlaceMg()
    {
        return "back_placeMg";
    }

    /**
     * 查询车位信息方法
     * @param response
     * @throws IOException
     */
    @RequestMapping("/findPlacesByPage")
    @Log(operationName = "查询车位信息方法",operationType = "查询车位信息方法")
    public void findPlacesByPage(HttpServletResponse response, HttpServletRequest request,
         String placeName, String zone, String isUse, String parkState) throws IOException {

        Map<String, Object> condition = new HashMap<>();

        //车位名字
        if(Common.notEmpty(placeName))
        {
            condition.put("placeName", "%" + placeName + "%");
        }

        //车位区域
        if(Common.notEmpty(zone))
        {
            condition.put("zone",zone);
        }

        //车位状态
        if(Common.notEmpty(isUse))
        {
            condition.put("isUse", isUse);
        }

        //停车状态
        if(Common.notEmpty(parkState))
        {
            condition.put("parkState", parkState);
        }

        TableInfo tableInfo = new TableInfo();

        int records = placeServiceImpl.findRecords(condition);

        String curPage = request.getParameter("page");
        String pageSize = request.getParameter("limit");
        int cur = Integer.parseInt(curPage);
        int sizes = Integer.parseInt(pageSize);
        List<TbPlace> list = placeServiceImpl.findPlacesByPage(condition,
                (cur - 1) * sizes,cur * sizes);

        if(list != null && list.size() > 0){
            for (TbPlace place : list) {

                //获取展示的车位状态
                place.setShowUse(Common.getString(place.getIsUse()));
                //获取展示的停车状态
                place.setShowState(Common.getString(place.getParkState()));
            }
        }

        tableInfo.setCode(0);
        tableInfo.setMsg("车位列表数据信息");
        tableInfo.setCount(records);
        tableInfo.setData(list);

        String json = new Gson().toJson(tableInfo);
        response.getWriter().write(json);
    }

    /**
     * 修改车位状态方法
     * @param response
     * @param place
     * @throws IOException
     */
    @RequestMapping("/changeState")
    @Log(operationName = "修改车位状态方法",operationType = "修改车位状态方法")
    public void changeState(HttpServletResponse response, @RequestBody TbPlace place) throws IOException {
        int res = placeServiceImpl.changeState(place);

        if(res > 0)
        {
            response.getWriter().write("success");
        }
        else
        {
            response.getWriter().write("fail");
        }
    }


    /**
     * 选中车位展示信息方法
     * @param request
     * @param mName
     * @return
     * @throws IOException
     */
    @RequestMapping("/selectPlace")
    @Log(operationName = "选中车位展示信息方法",operationType = "选中车位展示信息方法")
    public @ResponseBody String selectPlace(HttpServletRequest request, String mName) throws IOException {
        TbPlace place = placeServiceImpl.selectPlace(mName);

        String res = "";

        if(place != null){
            //获取展示的车位状态
            place.setShowUse(Common.getString(place.getIsUse()));
            //获取展示的停车状态
            place.setShowState(Common.getString(place.getParkState()));

            res = JSON.toJSONString(place);
        }else{
            res = "fail";
        }

        return res;
    }


    /**
     * 修改车位信息方法
     * @param response
     * @param place
     * @throws IOException
     */
    @RequestMapping("/setPlace")
    @Log(operationName = "修改车位信息方法",operationType = "修改车位信息方法")
    public @ResponseBody String setPlace(HttpServletResponse response, @RequestBody TbPlace place) throws IOException {
        String msg = "";

        //设置状态值
        place.setIsUse(Integer.parseInt(place.getShowUse()));
        place.setParkState(Integer.parseInt(place.getShowState()));

        //根据区域和车位名，判断车位是否已存在
        TbPlace tbPlace = placeServiceImpl.findByZoneName(place.getZone(),
                place.getPlaceName());

        if(!tbPlace.getPointX().equals(place.getPointX())){
            msg = "duplicated";
        }else{
            int res = placeServiceImpl.setPlace(place);

            System.out.println("修改结果：" + res);

            if(res > 0)
            {
                msg = "success";
            }
            else
            {
                msg = "fail";
            }
        }

        return msg;
    }


    /**
     * 查询已使用、未启用车位的信息
     * @return
     */
    @RequestMapping("/showChanges")
    @Log(operationName = "查询已使用、未启用车位的信息",operationType = "查询已使用、未启用车位的信息")
    public @ResponseBody String findChanges(){

        //查询已停车的车位信息
        List<TbPlace> usedList = placeServiceImpl.findByState(10);
        //查询禁用的车位信息
        List<TbPlace> banList = placeServiceImpl.findByUsed(7);
        //查询已删除的车位信息
        List<TbPlace> delList = placeServiceImpl.findByUsed(8);
        //合并集合
        banList.addAll(delList);

        String usedJson = JSON.toJSONString(usedList);
        String banJson = JSON.toJSONString(banList);
        String res = usedJson + "-" + banJson;

        System.out.println(banList.size() + delList.size());
        System.out.println("车位改变信息:"+res);

        return res;
    }


    /**
     * 查询所有状态的车位的数量
     * @return
     */
    @RequestMapping("/getCounts")
    @Log(operationName = "查询所有状态的车位的数量",operationType = "查询所有状态的车位的数量")
    public @ResponseBody String getCounts(){

        //查询已停车的车位信息
        List<TbPlace> usedList = placeServiceImpl.findByState(10);
        //查询禁用的车位信息
        List<TbPlace> banList = placeServiceImpl.findByUsed(7);
        //查询已删除的车位信息
        List<TbPlace> delList = placeServiceImpl.findByUsed(8);

        String res = usedList.size() + "-" + (26 - usedList.size() - banList.size()
                - delList.size());

        System.out.println("停车场实时信息:"+res);

        return res;
    }
}
