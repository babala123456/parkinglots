package com.cykj.controller;

import com.cykj.bean.*;
import com.cykj.service.BookingService;
import com.cykj.service.CarService;
import com.cykj.service.PlaceService;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
@Controller
public class UserBookingController {
    @Resource
    private CarService carServiceImpl;
    @Resource
    private PlaceService placeServiceImpl;
    @Resource
    private BookingService bookingServiceImpl;

    @Resource
    private TableInfo tableInfo;


    @RequestMapping("userBooking")
    @Log(operationName = "返回用户登录页",operationType = "")
    public String gotoBooking(int data, HttpServletRequest request){
        List<TbCar> cars = carServiceImpl.findCarNum(data);
        System.out.println("cars:"+cars);

        //区域map
        List<TbPlace> zone = placeServiceImpl.findZone();

        Map map = placeServiceImpl.disposePlace();
        request.setAttribute("placeMap",map);
        request.setAttribute("zone",zone);
        request.setAttribute("cars",cars);
        return "user_booking";
    }

    @RequestMapping("booking")
    @ResponseBody
    @Log(operationName = "用户预约车位",operationType = "")
    public String userBooking(TbBooking tbBooking, HttpServletRequest request){
        String result = bookingServiceImpl.addBooking(tbBooking);
        return result;
    }

    @RequestMapping("bookingLog")
    @ResponseBody
    @Log(operationName = "预约记录表",operationType = "")
    public String userBookingLog(int carId, HttpServletRequest request){

        List<TbBooking> booking = bookingServiceImpl.findBookingByCarId(carId);
        int bookingCount = bookingServiceImpl.findBookingCountByCarId(carId);
        tableInfo.setCode(0);
        tableInfo.setCount(bookingCount);
        tableInfo.setData(booking);
        String result = new Gson().toJson(tableInfo);
        return result;
    }

    @RequestMapping("bookingLogMaa")
    @ResponseBody
    @Log(operationName = "预约记录表",operationType = "")
    public String bookingLogMaa( HttpServletRequest request){

        List<TbBooking> booking = bookingServiceImpl.findBooking();
        int bookingCount = bookingServiceImpl.findBookingCount();
        tableInfo.setCode(0);
        tableInfo.setCount(bookingCount);
        tableInfo.setData(booking);
        String result = new Gson().toJson(tableInfo);
        return result;
    }
    @RequestMapping("deleteBooking")
    @ResponseBody
    @Log(operationName = "后台删除预约记录",operationType = "")
    public String deleteBooking(int bookingId){
        int i = bookingServiceImpl.delBooking(bookingId);
        if (i>0){
            return "success";
        }
        return "lose";
    }

    @RequestMapping("updateBooking")
    @ResponseBody
    @Log(operationName = "后台删除预约记录",operationType = "")
    public String updateBooking(int bookingId){
        int i = bookingServiceImpl.updateBookingState(37,bookingId);
        if (i>0){
            return "success";
        }
        return "lose";
    }

    @RequestMapping("/gotoBookingLog")
    @Log(operationName = "用户预约列表界面跳转",operationType = "")
    public String bookingLog(int carId,HttpServletRequest request){
        request.setAttribute("carId",carId);
        return "booking_log";
    }
}
