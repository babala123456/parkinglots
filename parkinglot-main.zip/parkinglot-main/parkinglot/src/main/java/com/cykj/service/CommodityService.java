package com.cykj.service;

import com.cykj.bean.SpCommodity;
import com.cykj.bean.SpType;
import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbProduct;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface CommodityService {

    /**
     * 查询商品列表
     * @param map
     * @param starNum
     * @param endNum
     * @return
     */
    public List<SpCommodity> findCommodity(Map<String, Object> map, Integer starNum, Integer endNum);

    /**
     * 查询记录数
     * @param map
     * @return
     */
    public int findComRecords(Map<String, Object> map);


    /**
     * 修改商品信息
     * @return
     */
    public int updateCommodity(@Param("spName") String spName,
                              @Param("price") int price,@Param("inventory") int inventory,
                              @Param("teid") int teid,
                              @Param("spDetails") String spDetails, @Param("cmtId") int cmtId);

    /**
     * 商品的禁用启用
     * @param cmtId
     * @param spState
     * @return
     */
    public String changeSpState(@Param("cmtId") int cmtId, @Param("spState") int spState);

    /**
     * 查找sp_type中的spType,用来做新增名称下拉
     * @return
     */
    public List<SpType> findSpType();

    /**
     * 新增商品
     * @return
     */
    public int addCommodity(@Param("spName") String spName, @Param("price") int price,
                           @Param("inventory") int inventory, @Param("teid") int teid,@Param("spDetails") String spDetails);

    //重复名判断
    public List<SpCommodity> findNameAgain(String spName);

    /**
     * 删除一条商品表信息
     * @param cmtId
     * @return
     */
    public String delCommodity(int cmtId);

}
