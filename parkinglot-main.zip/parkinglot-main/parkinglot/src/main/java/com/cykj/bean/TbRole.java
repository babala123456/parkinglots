package com.cykj.bean;


public class TbRole {

  private int roleId;
  private String userRole;
  private TbAdmin tbAdmin;

  public TbRole() {
  }

    public TbRole(int roleId, String userRole) {
    this.roleId = roleId;
    this.userRole = userRole;
  }

    @Override
    public String toString() {
        return "TbRole{" +
                "roleId=" + roleId +
                ", userRole='" + userRole + '\'' +
                '}';
    }

    public int getRoleId() {
    return roleId;
  }

  public void setRoleId(int roleId) {
    this.roleId = roleId;
  }


    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

}
