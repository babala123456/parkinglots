package com.cykj.service.serviceImpl;

import com.cykj.bean.TbWork;
import com.cykj.mapper.WorkMapper;
import com.cykj.service.WorkService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service
public class WorkServiceImpl implements WorkService {

    @Resource
    private WorkMapper workMapper;


    /**
     * 根据工作点id，查询排班信息
     * @param workId
     * @return
     */
    @Override
    public TbWork findWork(int workId) {
        return workMapper.findWork(workId);
    }
}
