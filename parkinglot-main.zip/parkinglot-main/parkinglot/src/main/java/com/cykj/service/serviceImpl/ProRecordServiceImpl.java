package com.cykj.service.serviceImpl;


import com.cykj.bean.TbProRecord;
import com.cykj.mapper.ProRecordMapper;
import com.cykj.service.ProRecordService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class ProRecordServiceImpl implements ProRecordService {

    @Resource
    private ProRecordMapper proRecordMapper;

    /**
     * 添加产品办理记录方法
     * @param proRecord
     * @return
     */
    @Override
    public int addRecord(TbProRecord proRecord) {
        return proRecordMapper.addRecord(proRecord);
    }


    /**
     * 修改产品办理状态方法
     * @param proRecordId
     * @param state
     * @return
     */
    @Override
    public int changeState(int proRecordId, int state) {
        return proRecordMapper.changeState(proRecordId,state);
    }
}
