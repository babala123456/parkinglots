package com.cykj.mapper;


import com.cykj.bean.MyAccounted;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface AccountedMapper {

    /**
     * 查询日结算基础信息方法
     * @return
     */
    public List<MyAccounted> findAccounts(@Param("startTime") String startTime,
          @Param("endTime") String endTime,@Param("startIndex") Integer startIndex,
          @Param("endIndex") Integer endIndex);
}
