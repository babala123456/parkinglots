package com.cykj.mapper;

import com.cykj.bean.TbHandle;
import com.cykj.bean.TbProduct;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
@Repository
@Mapper
public interface HandleMapper {


    /**
     * 康春杰
     * 2020年11月19日14:13:54 -1.0
     * 2020年11月20日19:59:40 -2.0 修改
     * [车辆出场功能] 查询 用户是否有办理 产品
     * @param carId
     * @param handleState
     * @return
     */
    public List<TbHandle> findHandleByCarId(@Param("carId")int carId, @Param("handleState")int handleState);

    public List<TbHandle> findHandlePage(Map<String,Object> map);//查询数据与模糊查询
    public int findHandleNum(Map<String,Object> map);//分页查询


    /**
     * 根据车辆id查询车辆办理业务
     * @param carId
     * @return
     */
    public TbHandle findByCarId(int carId);

    /**
     * 办理业务时续费业务的方法
     * @param tbHandle
     * @return
     */
    public int setFinishTime(@Param("tbHandle") TbHandle tbHandle);



    /**
     *新增业务办理记录方法
     * @param tbHandle
     * @return
     */
    public int addHandle(@Param("tbHandle") TbHandle tbHandle);
}
