package com.cykj.bean;

import org.springframework.stereotype.Component;

/**
 * @author Administrator
 */
@Component
public class TbCar {

  private int carId;
  private String carNum;
  private int userId;

  public TbCar() {
  }

  public TbCar(int carId, String carNum, int userId) {
    this.carId = carId;
    this.carNum = carNum;
    this.userId = userId;
  }

  @Override
  public String toString() {
    return "TbCar{" +
            "carId=" + carId +
            ", carNum='" + carNum + '\'' +
            ", userId=" + userId +
            '}';
  }

  public int getCarId() {
    return carId;
  }

  public void setCarId(int carId) {
    this.carId = carId;
  }


  public String getCarNum() {
    return carNum;
  }

  public void setCarNum(String carNum) {
    this.carNum = carNum;
  }


  public int getUserId() {
    return userId;
  }

  public void setUserId(int userId) {
    this.userId = userId;
  }



}
