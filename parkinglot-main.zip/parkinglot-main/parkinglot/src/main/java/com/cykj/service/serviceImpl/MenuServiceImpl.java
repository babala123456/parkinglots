package com.cykj.service.serviceImpl;


import com.cykj.bean.TbMenu;
import com.cykj.mapper.MenuMapper;
import com.cykj.service.MenuService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

@Service
public class MenuServiceImpl implements MenuService {

    @Resource
    private MenuMapper menuMapper;

    @Override
    public List<TbMenu> findMenuPage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit",limit);
        map.put("offset",(curPage-1)*limit);
        return menuMapper.findMenuPage(map);
    }

    @Override
    public int findMenuNum(Map<String, Object> map) {
        return 0;
    }

    /**
     * 动态菜单查询
     * @param roleId
     * @param relevanceId
     * @return
     */
    @Override
    public Map<String, List<TbMenu>> findMenusByPid(String roleId , int relevanceId) {
        Map<String, List<TbMenu>> menuMap=new LinkedHashMap<>();
        //拿到一级菜单
        List<TbMenu> fMenuList = findParent(0);
        for(TbMenu menu : fMenuList){
            //拿到子菜单
            List<TbMenu> sonMenuList  = menuMapper.findMenusByPid(roleId,menu.getMenuId());
            if(sonMenuList.size()!=0){
                menuMap.put(menu.getMenuName(),sonMenuList);
            }
        }
        return menuMap;
    }

    /***
     * 角色未拥有菜单查询
     * @param roleId
     * @return
     */
    @Override
    public   Map<String, List<TbMenu>> laterMenu(String roleId) {
        Map<String, List<TbMenu>> laterMenuMap=new LinkedHashMap<>();//未拥有的菜单
        List<TbMenu> laterMenu = menuMapper.laterMenu(roleId);//未拥有的菜单集合，
        List<TbMenu> noenMenu = new ArrayList<>();//一级菜单
        List<TbMenu> towMenu = new ArrayList<>();//二级菜单
        for(TbMenu menu : laterMenu){
            if (menu.getRelevanceId().equals("0")){
                noenMenu.add(menu);
                System.out.println("未拥有的一级菜单："+menu.getMenuName());
                for (TbMenu laterList : laterMenu){
                    if ( menu.getMenuId()==Integer.parseInt(laterList.getRelevanceId())){
                        towMenu.add(laterList);
                        laterMenuMap.put(menu.getMenuName(),towMenu);
//                            towMenu.clear();
                        System.out.println("未拥有的二级菜单："+laterList.getMenuName());
                    }
                    else {
                        laterMenuMap.put(menu.getMenuName(),null);
                    }
                }
            }
        }

        return laterMenuMap;
    }

    /**
     * 查询所有菜单
     * @return
     */
    @Override
    public List<TbMenu> Menu() {
        return menuMapper.Menu();
    }

    /**
     * 删除菜单
     * @param menuId
     * @return
     */
    @Override
    public int deleteMenu(int menuId) {
        return menuMapper.deleteMenu(menuId);
    }

    /**
     * 更改菜单
     * @param menuId
     * @param menuName
     * @param menuPath
     * @param relevanceId
     * @return
     */
    @Override
    public int updateMenu(int menuId, String menuName, String menuPath, String relevanceId) {
        return menuMapper.updateMenu(menuId, menuName, menuPath, relevanceId);
    }

    /**
     * 添加菜单
     * @param menuName
     * @param menuPath
     * @param relevanceId
     * @return
     */
    @Override
    public int insertMenu(String menuName, String menuPath, String relevanceId) {
        return menuMapper.insertMenu(menuName, menuPath, relevanceId);
    }

    /**
     * 动态菜单
     * @param roleId
     * @param relevanceId
     * @return
     */
    @Override
    public List<TbMenu> findMenu(String roleId, int relevanceId) {
        List<TbMenu> sonMenuList = new ArrayList<>();
        //拿到一级菜单
        List<TbMenu> fMenuList = findParent(relevanceId);
        for(TbMenu menu : fMenuList){
            //拿到子菜单
            sonMenuList = menuMapper.findMenusByPid(roleId,menu.getMenuId());
            System.out.println("测试类菜单");
        }

        return sonMenuList;
    }

    /**
     * 测试方法
     * @param roleId
     * @return
     */
    @Override
    public List<TbMenu> lateList(String roleId) {
        return menuMapper.laterMenu(roleId);
    }

    @Override
    public Object[] findMenu(int roleId) {
        //所有父级菜单
        List<TbMenu> pList = menuMapper.findParentMenu(0);
        Map<TbMenu,List<TbMenu>> allMap = new HashMap<>(16);
        Map<TbMenu,List<TbMenu>> noneMap = new HashMap<>(16);
        for (TbMenu tbmenu:pList) {
            //所有菜单
            List<TbMenu> sonList = menuMapper.findMenuByPid(roleId,tbmenu.getMenuId());
            //添加 父级菜单和 子级菜单 至map
            allMap.put(tbmenu,sonList);

            //所有未分配的菜单
            List<TbMenu> noneMenu = menuMapper.findNoneMenu(roleId,tbmenu.getMenuId());
            noneMap.put(tbmenu,noneMenu);
        }
        Object [] obj = {allMap,noneMap};
        return  obj;
    }

    @Override
    public List<TbMenu> findParent(int relevanceId) {
        List<TbMenu> parentList = menuMapper.findParentMenu(relevanceId);
        return parentList;
    }
}
