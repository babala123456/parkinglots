package com.cykj.mapper;

import com.cykj.bean.TbPlace;
import com.cykj.bean.TbRule;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface RuleMapper {

    /**
     * 查询当前启用的计费规则
     * @return
     */
    public TbRule selUsingRule();


    /**
     * 条件查询数据总数
     * @param condition
     * @return
     */
    public int findRecords(@Param("condition") Map<String, Object> condition);


    /**
     * 分页查询规则数据
     * @param condition
     * @return
     */
    public List<TbRule> findRulesByPage(@Param("condition") Map<String, Object> condition,
      @Param("startIndex") Integer startIndex, @Param("endIndex") Integer endIndex);



    /**
     * 修改规则状态方法
     * @param rule
     * @return
     */
    public int changeState(@Param("rule") TbRule rule);


    /**
     * 修改规则信息方法
     * @param rule
     * @return
     */
    public int setRule(@Param("rule") TbRule rule);


    /**
     * 根据规则名字，查询是否已存在相同名字规则
     * @param ruleName
     * @return
     */
    public TbRule legal(@Param("ruleName") String ruleName);


    /**
     * 新增规则方法
     * @param rule
     * @return
     */
    public int newRule(@Param("rule") TbRule rule);
}
