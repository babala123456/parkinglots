package com.cykj.service;

import com.cykj.bean.MyAccounted;

import java.util.List;

public interface AccountedService {
    /**
     * 根据收费员id，查询日结算信息方法
     * @return
     */
    public String findAccounts(int adminId, Integer startIndex, Integer endIndex,int schedule);
}
