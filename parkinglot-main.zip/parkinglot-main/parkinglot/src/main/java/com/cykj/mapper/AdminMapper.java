package com.cykj.mapper;

import com.cykj.bean.TbAdmin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.mybatis.spring.annotation.MapperScan;

import java.util.List;
import java.util.Map;

@MapperScan(value = "adminMapper")
@Mapper
public interface AdminMapper {
    public List<TbAdmin> adminUser();
    public int delAdminById(@Param("aid") int aId);
    public TbAdmin login(@Param("name") String name, @Param("pwd") String pwd);//后台

    public int insertAdminUser(TbAdmin tbAdmin);//后台用户添加

    List<TbAdmin> findAdminPage(Map<String, Object> map);

    int findAdminNum(Map<String, Object> map);

    /**
     * 修改
     * @param aId
     * @param aName
     * @return
     */
    public int updateAdminUser(@Param("aId") int aId, @Param("aName") String aName);
//    boolean changeState(@Param("userId") int userId,@Param("userState") int userState);
}
