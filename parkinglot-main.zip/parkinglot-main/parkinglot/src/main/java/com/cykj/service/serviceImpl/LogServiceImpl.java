package com.cykj.service.serviceImpl;

import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbLog;
import com.cykj.mapper.AdminMapper;
import com.cykj.mapper.LogMapper;
import com.cykj.service.LogService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class LogServiceImpl implements LogService {
    @Resource
    private LogMapper logMapper;

    @Override
    public List<TbLog> findLogOnPage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit",limit);
        map.put("offset",(curPage-1)*limit);
        List<TbLog> allOnPage = logMapper.findLogOnPage(map);
        return allOnPage;
    }


    @Override
    public int findLogNum(Map<String, Object> map) {
        int all = logMapper.findLogNum(map);

        return all;
    }

    @Override
    public int addBackLog(TbLog tbLog) {
        System.out.println("进入日志!");
        int n = logMapper.addBackLog(tbLog);
        return n;
    }
}
