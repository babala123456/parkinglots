package com.cykj.service;

import com.cykj.bean.TbCar;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author Administrator
 */
public interface CarService {

    /**
     * 康春杰
     * [前台车辆入场功能]：将车牌信息添加至 tb_car表中 并返回插入后的 ID
     * @param tbCar
     * @return
     */
    public int addCar(TbCar tbCar);


    /**
     * 康春杰
     * [前台车辆出场功能]：根据 车牌查询 ID
     * @param carNum
     * @return
     */
    public int findCarIdByCarNum(@Param("carNum") String carNum);

    /**
     * 康春杰
     * 2020年11月19日18:12:52
     * [前台车辆出场功能]：根据 车牌删除记录
     * @param carId
     * @return
     */
    public int deleteCarByCarId(@Param("carId") int carId);

    /**
     * 康春杰
     * 2020年11月20日10:37:44
     * [前台车辆入场功能]：判断该车牌是否存在
     * @param carNum
     * @return
     */
    public Boolean findCarByCarNum(@Param("carNum") String carNum);

    /**
     * 根据用户id，查询车辆信息
     * @param userId
     * @return
     */
    public List<TbCar> findByUserId(int userId);


     /* 查询车牌
     * @param userId
     * @return
     */
    public List<TbCar> findCarNum(int userId);


    /**
     * [车牌绑定功能] --根据 id和车牌号查询是否有重复车牌
     * 2020年11月28日00:07:55
     * @param carNum
     * @param userId
     * @return
     */
    public int duplicateCar(String carNum, int userId);

    /**
     * [车牌绑定功能] --根据 id和车牌号 进行绑定车牌
     * 2020年11月28日00:07:52
     * @param carNum
     * @param userId
     * @return
     */
    public int bindingCarNum(String carNum,int userId);

    /**
     *  [车牌绑定功能] --绑定车牌的逻辑操作
     *  2020年11月28日00:07:48
     * @param carNum
     * @param userId
     * @return
     */
    public String bingDing(String carNum,int userId);

    /**
     * 根据 carId 返回 Car对象
     * 2020年11月29日16:33:21
     * @param carId
     * @return
     */
    public TbCar selCarNumByCarId(@Param("carId")int carId);


}
