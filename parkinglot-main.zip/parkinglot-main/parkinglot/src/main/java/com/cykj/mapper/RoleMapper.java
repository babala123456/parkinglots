package com.cykj.mapper;


import com.cykj.bean.TbRole;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository(value = "roleMapper")
@Mapper
public interface RoleMapper {
    public List<TbRole> roleSelect();//角色查询
    public List<TbRole> findRolePage(Map<String,Object> map);//查询数据与模糊查询
    public int findRoleNum(Map<String,Object> map);//分页查询
    public int updateRole(@Param("roleId")int roleId, @Param("userRole")String userRole);//更改角色
    public int insertRole(@Param("userRole")String userRole);//添加角色

    /**
     * 康春杰
     * [权限管理功能]：角色选择
     * 2020年11月23日10:10:28
     *
     * @return
     */
    public List<TbRole> findRole();
}
