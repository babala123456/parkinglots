package com.cykj.controller;

import com.cykj.mapper.RecordMapper;
import com.cykj.service.ParkService;
import com.cykj.service.PlaceService;
import com.cykj.service.RecordService;
import com.cykj.util.Log;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.beans.FeatureDescriptor;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

/**
 * @author Administrator
 */
@Controller
public class EnterController {

    @Resource
    private PlaceService placeServiceImpl;

    @Resource
    private ParkService parkServiceImpl;

    @Resource
    private RecordService recordServiceImpl;

    private Map map;

    String resultInfo = null;

    /**
     * 前往 入场页面
     */
    @RequestMapping("/welcome")
    @Log(operationName = "前往入场页面",operationType = "页面跳转")
    public String gotoWelcomePage(HttpServletRequest request) {
        //所有车位
        int allPlace = placeServiceImpl.findPlaceByParkState(null);
        //已使用车位
        int used = placeServiceImpl.findPlaceByParkState("used");
        int surplus = placeServiceImpl.findPlaceByParkState("usable");
        //剩余停车位
        request.setAttribute("allPlace", allPlace);
        request.setAttribute("used", used);
        request.setAttribute("surplus", surplus);
        return "welcome";
    }

    /**
     * 添加 record记录并返回 welcome页面
     * @param recordId
     * @return
     */
    @RequestMapping("/addRecord")
    @Log(operationName = "前往入场页面",operationType = "页面跳转")
    public String addRecord(int recordId,String out_trade_no,HttpServletRequest request){
        int i = recordServiceImpl.updateOutTradeNo(out_trade_no, recordId);
        if (i>0){
            System.out.println("更新out_trade_no成功");
        }else{
            System.out.println("更新out_trade_no失败");
        }
        //所有车位
        int allPlace = placeServiceImpl.findPlaceByParkState(null);
        //已使用车位
        int used = placeServiceImpl.findPlaceByParkState("used");
        int surplus = placeServiceImpl.findPlaceByParkState("usable");
        //剩余停车位
        request.setAttribute("allPlace", allPlace);
        request.setAttribute("used", used);
        request.setAttribute("surplus", surplus);
        return "welcome";
    }


    /**
     * 识别车牌     进场
     * @param carNumFile
     * @param request
     * @return
     * @throws IOException
     */
    @RequestMapping("/recognitionEnter")
    @ResponseBody
    @Log(operationName = "识别车辆入场操作",operationType = "逻辑操作")
    public String recognitionEnter(MultipartFile carNumFile, HttpServletRequest request) throws IOException {
        //得到可用车位数
        int surplus = placeServiceImpl.findPlaceByParkState("usable");
        //将图片存入工程
        String[] carEnters = uploadFile(carNumFile, request, "carEnter");
        //进行识别图片的逻辑操作
        resultInfo = parkServiceImpl.parkByCarNumImg(surplus, carEnters[0],carEnters[1]);
        return resultInfo;
    }

    /**
     * 手动输入车牌   进场
     * @param carNum
     * @return
     */
    @RequestMapping("/manualCarNum")
    @ResponseBody
    @Log(operationName = "手动输入车牌入场操作",operationType = "逻辑操作")
    public String manualCarNum(String carNum) {
        int surplus = placeServiceImpl.findPlaceByParkState("usable");
        resultInfo = parkServiceImpl.parkByCarNum(surplus,carNum);
        System.out.println("resultInfo:"+resultInfo);
        return resultInfo;
    }

    /**
     * 识别车牌     出场
     * @param carNumFile
     * @param request
     * @return
     * @throws IOException
     */
    @RequestMapping("/recognitionOut")
    @ResponseBody
    @Log(operationName = "识别车辆出场",operationType = "逻辑操作")
    public String recognitionOut(MultipartFile carNumFile, HttpServletRequest request) throws IOException {
        //文件上传
        String[] carOuts = uploadFile(carNumFile, request, "carOut");
        //出场业务
        resultInfo = parkServiceImpl.outByCarNumImg(carOuts[0],carOuts[1]);
        return resultInfo;
    }

    /**
     * 手动输入车牌     出场
     * @return
     */
    @RequestMapping("/manualOut")
    @ResponseBody
    @Log(operationName = "手动输入车辆出场",operationType = "逻辑操作")
    public String manualOut(String carNum){
        resultInfo = parkServiceImpl.outByCarNum(carNum);
        return resultInfo;
    }

    @RequestMapping("/test")
    @Log(operationName = "页面跳转",operationType = "")
    public String test() {
        return "user_booking";
    }


    public String [] uploadFile(MultipartFile carNumFile, HttpServletRequest request, String uplFile) throws IOException {
        String path  = ResourceUtils.getURL("classpath:").getPath() + "static/carImg/"+uplFile;
        System.out.println("Path:"+path);

        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        //3、创建目录
        File file = new File(path, date);
        //3.1不存在则创建目录或者子目录
        if (!file.exists()) {
            file.mkdirs();
            System.out.println("创建了文件夹");
        }
        System.out.println("filePath:"+file.getPath());
        //4.1 获取原始文件名
        String fileName = carNumFile.getOriginalFilename();
        System.out.println("原始文件名:"+fileName);
        fileName = UUID.randomUUID().toString() + fileName.substring(fileName.lastIndexOf("."));
        System.out.println("重命后文件名："+fileName);

        //4.2 文件上传
        carNumFile.transferTo(new File(file, fileName));
        String carNumberFile = file.getPath() + "/"+ fileName;
        String imgFile = "/carImg/"+uplFile+"/"+date+"/"+fileName;
        System.err.println("文件源：" + carNumFile);
        System.out.println("carNumberFile 具体文件地址："+carNumberFile);
        String [] str = {carNumberFile,imgFile};
        return str;

    }

}
