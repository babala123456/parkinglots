package com.cykj.service;

import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbSchedules;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface SchedulesService {

    /**
     * 查询值班表列表
     * @return
     */
    public List<TbSchedules> findSchedule(Map<String, Object> map, Integer starNum, Integer endNum);

    /**
     * 查询记录数
     * @param map
     * @return
     */
    public int findRecords(Map<String, Object> map);

    /**
     * 删除一条值班表信息
     * @param sId
     * @return
     */
    public String delSchedule(int sId);

    /**
     * 修改值班信息
     * @param saState
     * @param sId
     * @return
     */
    public int updateSchedule(@Param("saWorkday") String saWorkday,
                              @Param("workId") int workId,
                              @Param("saState") String saState, @Param("sId") int sId);

    /**
     * 新增排班
     * @param adminId
     * @param saWorkday
     * @param workId
     * @param saState
     * @return
     */
    public int addSchedule(@Param("adminId") int adminId, @Param("saWorkday") String saWorkday,
                           @Param("workId") int workId, @Param("saState") int saState);

    /**
     * 查找admin中的aName,用来做新增名称下拉
     * @return
     */
    public List<TbAdmin> findAdminName();


    public TbSchedules findByAdminId(int adminId,String workDay,String time);
}
