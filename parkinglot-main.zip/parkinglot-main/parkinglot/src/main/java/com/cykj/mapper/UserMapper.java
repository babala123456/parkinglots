package com.cykj.mapper;

import com.cykj.bean.TbHandle;
import com.cykj.bean.TbUser;
import com.cykj.bean.TbWhite;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface UserMapper {

    public TbUser selUser(@Param("name") String name, @Param("pwd") String pwd);

    /**
     * 根据条件查询 用户订单
     * @param map
     * @return
     */
    public List<TbHandle> findUserOrder(Map map);

    /**
     * 根据条件查询返回的记录数
     * @param map
     * @return
     */
    public int findUserOrderRecord(Map map);

    /**
     * 康春杰
     * [前台用户登录功能]
     * 2020年11月24日21:11:38
     * @param account
     * @param password
     * @return
     */
    public TbUser userLogin(@Param("account")String account,@Param("password")String password);

    /**
     * 查询停车次数
     * @param userId
     * @return
     */
    public int stopNumber(@Param("userId") int userId);

    /**
     * [车主端] 自主修改密码
     * @param password
     * @param userId
     * @return
     */
    public int resetPassword(@Param("password")String password,@Param("userId")int userId);

    /**
     * [车主端] 根据ID返回用户信息
     * @param userId
     * @return
     */
    public TbUser findUserInfo(@Param("userId")int userId);
}
