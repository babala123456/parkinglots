package com.cykj.service;

import com.cykj.bean.TbRefund;

import java.util.List;
import java.util.Map;

public interface RefundService {
    /**
     * 数据查询与模糊查询
     * @param map
     * @param curPage
     * @param limit
     * @return
     */
    public List<TbRefund> findRefundPage(Map<String, Object> map, int curPage, int limit);
    public int findRefundNum(Map<String, Object> map);//分页查询
}
