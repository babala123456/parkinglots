package com.cykj.interceptor.Configurer;

import com.cykj.interceptor.EncodeInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

@Configuration
public class EncodeConfigurer implements WebMvcConfigurer {

    @Resource
    private EncodeInterceptor encodeInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(encodeInterceptor).addPathPatterns("/**");
    }
}
