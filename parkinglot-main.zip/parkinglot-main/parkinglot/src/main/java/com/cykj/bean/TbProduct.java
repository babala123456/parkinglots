package com.cykj.bean;


public class TbProduct {

  private Integer proId;
  private String proName;
  private Integer proDeadline;
  private String proUnit;
  private Integer proPrice;
  private Integer proState;
  private Integer showEffect;
  private String showYuan;  //显示折合每天的钱

  public TbProduct() {
  }

  public TbProduct(Integer proId, String proName, Integer proDeadline, String proUnit, Integer proPrice, Integer proState) {
    this.proId = proId;
    this.proName = proName;
    this.proDeadline = proDeadline;
    this.proUnit = proUnit;
    this.proPrice = proPrice;
    this.proState = proState;
  }

  public Integer getProId() {
    return proId;
  }

  public void setProId(Integer proId) {
    this.proId = proId;
  }

  public String getProName() {
    return proName;
  }

  public void setProName(String proName) {
    this.proName = proName;
  }

  public Integer getProDeadline() {
    return proDeadline;
  }

  public void setProDeadline(Integer proDeadline) {
    this.proDeadline = proDeadline;
  }

  public String getProUnit() {
    return proUnit;
  }

  public void setProUnit(String proUnit) {
    this.proUnit = proUnit;
  }

  public Integer getProPrice() {
    return proPrice;
  }

  public void setProPrice(Integer proPrice) {
    this.proPrice = proPrice;
  }

  public Integer getProState() {
    return proState;
  }

  public void setProState(Integer proState) {
    this.proState = proState;
  }


  public Integer getShowEffect() {
    return showEffect;
  }

  public void setShowEffect(Integer showEffect) {
    this.showEffect = showEffect;
  }

  public String getShowYuan() {
    return showYuan;
  }

  public void setShowYuan(String showYuan) {
    this.showYuan = showYuan;
  }
}
