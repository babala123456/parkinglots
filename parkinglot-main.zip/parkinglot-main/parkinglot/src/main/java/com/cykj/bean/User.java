package com.cykj.bean;

/**
 * @author Administrator
 */
public class User {

    private String name ;
    private String Age;
    private String account;


    public static void main(String[] args) {
        System.out.println("修改");
    }

}
