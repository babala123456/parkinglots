package com.cykj.service;

import com.cykj.bean.TbProduct;

import java.util.List;
import java.util.Map;

public interface ProductService {

    //搜索产品列表
    public List<TbProduct> findProduct(Map<String, Object> map, Integer starNum, Integer endNum);

    //查询记录数
    public int findRecords(Map<String, Object> map);

    //重复名判断
    public List<TbProduct> findNameAgain(String proName);


    //删除月缴产品数据
    public String delProduct(int proId,int proState);
    //删除月缴产品数据
    public String recoverProduct(int proId,int proState);

    //修改月缴产品数据

    public String updateProduct(String proName, int proDeadline, String proUnit, int proPrice, int proId);

    //月缴产品的禁用启用
    public String changeProState(int proId, int proState);
    //新增产品
    public String addProduct(String proName, int proDeadline, String proUnit, int proPrice);
}