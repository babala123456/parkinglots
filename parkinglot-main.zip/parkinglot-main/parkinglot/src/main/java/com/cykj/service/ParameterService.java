package com.cykj.service;

import com.cykj.bean.TbParameter;

import java.util.List;
import java.util.Map;

public interface ParameterService {
    /**
     * 数据查询与模糊查询
     * @param map
     * @param curPage
     * @param limit
     * @return
     */
    public List<TbParameter> findParameterOnPage(Map<String, Object> map, int curPage, int limit);
    public int findParameterNum(Map<String, Object> map);//分页查询
    public List<TbParameter> selectParameter();//查询参数
    public int deleteParameter(int pId);//删除参数
    public int updateParameter(int pId, String pType, String pValue);//更改参数
    public int insertParameter(String pType, String pValue);//添加参数

    //根据参数类型查询参数值
    public String findByType(String pType);

    //根据参数类型查询同类型的所有参数信息
    public List<TbParameter> findTypeList(String pType);
}
