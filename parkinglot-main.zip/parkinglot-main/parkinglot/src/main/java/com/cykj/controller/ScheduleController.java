package com.cykj.controller;

import com.cykj.bean.TableInfo;
import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbSchedules;
import com.cykj.service.SchedulesService;
import com.cykj.util.Common;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/schedule")
public class ScheduleController {

    @Resource
    SchedulesService scheduleImpl;

    /**
     * 跳转到值班表窗口
     * @return
     */
    @RequestMapping("/look")
    @Log(operationName = "返回值班页面",operationType = "返回值班页面")
    public String checkSchedule(HttpServletRequest request ){
        List<TbAdmin> nameList = scheduleImpl.findAdminName();
        request.setAttribute("nameList",nameList);
        return "back_schedule";
    }

    /**
     * 查询值班表列表
     * @param 
     */
    @RequestMapping("/test")
    @Log(operationName = "返回值班页面",operationType = "返回值班页面")
    @ResponseBody
    public String findSchedule(HttpServletRequest request, int page, int limit, String saName, String saStarTime, String saEndTime) throws IOException {
        Map<String, Object> map = new HashMap<>();
        if(Common.notEmpty(saName)){
            request.setAttribute("saName",saName);
            map.put("saName", "%" + saName + "%");
        }
        if(Common.notEmpty(saStarTime)){
            request.setAttribute("saStarTime",saStarTime);
            map.put("saStarTime",saStarTime);
        }
        if(Common.notEmpty(saEndTime)){
            request.setAttribute("saEndTime",saEndTime);
            map.put("saEndTime",saEndTime);
        }
        List<TbSchedules> scheduleList = scheduleImpl.findSchedule(map,(page-1)*limit,limit);
        int res = scheduleImpl.findRecords(map);
        TableInfo tableInfo = new TableInfo();
        tableInfo.setCode(0);
        tableInfo.setCount(res);
        tableInfo.setMsg("用户列表数据信息");
        tableInfo.setData(scheduleList);

        String remsg = new Gson().toJson(tableInfo);
        return remsg;
    }

    /**
     * 删除一条值班信息
     * @param sId
     * @return
     */
    @RequestMapping("/delSchedule")
    @Log(operationName = "返回值班页面",operationType = "返回值班页面")
    @ResponseBody
    public String delSchedule(int sId){
        String result = scheduleImpl.delSchedule(sId);
        return result;
    }

    /**
     * 修改一条值班信息
     * @param saState
     * @param sId
     * @return
     */
    @RequestMapping("/updateSchedule")
    @Log(operationName = "返回值班页面",operationType = "返回值班页面")
    @ResponseBody
    public int updateSchedule(String saWorkday, int workId, String saState, int sId){
        int n = scheduleImpl.updateSchedule(saWorkday,workId,saState,sId);
        System.out.println("这里的n是多少呢？"+n);
        return n;
    }

    @RequestMapping("/addSchedule")
    @Log(operationName = "返回值班页面",operationType = "返回值班页面")
    @ResponseBody
    public int addSchedule(int adminId, String saWorkday, int workId, int saState){
        int n = scheduleImpl.addSchedule(adminId,saWorkday,workId,saState);
        return n;
    }



}
