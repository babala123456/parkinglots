package com.cykj.service.serviceImpl;

import com.cykj.bean.TbProduct;
import com.cykj.mapper.ProductMapper;
import com.cykj.service.ProductService;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ProductServiceImpl implements ProductService {
    @Resource
    private ProductMapper productMapper;

    String result = null;

    //搜索月缴产品
    @Override
    public List<TbProduct> findProduct(Map<String, Object> map , Integer starNum, Integer endNum) {
        List<TbProduct> list  = productMapper.findProduct(map,starNum,endNum);
        return list;
    }

    //查询记录数
    @Override
    public int findRecords(Map<String, Object> map){
        int res = productMapper.findRecords(map);
        return res;
    }

    @Override
    public List<TbProduct> findNameAgain(String proName) {
        return productMapper.findNameAgain(proName);
    }

    //删除一条月缴产品数据
    @Override
    public String delProduct(@RequestParam  int proId,@RequestParam  int proState) {
        int i = productMapper.delProduct(proId,proState);
        if (i>0){
            proState = 29;
            result = "success";
        }else {
            result = "fail";
        }
        return result;
    }

    //恢复删除
    @Override
    public String recoverProduct(@RequestParam  int proId,@RequestParam  int proState) {
        int i = productMapper.recoverProduct(proId,proState);
        if (i>0){
            proState = 27;
            result = "success";
        }else {
            result = "fail";
        }
        return result;
    }

    //修改一条月缴产品数据
    @Override
    public String updateProduct(@RequestParam String proName , @RequestParam int proDeadline ,
                                @RequestParam String proUnit , @RequestParam int proPrice , @RequestParam int proId) {
        List<TbProduct> tbProductList = productMapper.findNameAgain(proName);
        if (tbProductList.size() == 0) {
        Map<String, Object> map = new HashMap();
        map.put("proName",proName);
        map.put("proDeadline",proDeadline);
        map.put("proUnit",proUnit);
        map.put("proPrice",proPrice);
        map.put("proId",proId);
        int n  = productMapper.updateProduct(map);
            if (n > 0) {
                result = "success";
            } else {
                result = "fail";
            }
        }else {
            result = "again";
        }
        return result;
    }

    //月缴产品的禁用启用
    @Override
    public String changeProState(@RequestParam int proId, @RequestParam int proState) {
        int n = productMapper.changeProState(proId,proState);
        if(proState == 28){
            proState = 27;
            result = "success";
        }else if(proState == 27){
            proState = 28;
            result = "fail";
        }
        return result;
    }

    //新增一条月缴产品数据
    @Override
    public String addProduct(String proName, int proDeadline, String proUnit, int proPrice) {
        List<TbProduct> tbProductList = productMapper.findNameAgain(proName);
        if (tbProductList.size() == 0) {
            Map<String, Object> map = new HashMap();
            map.put("proName", proName);
            map.put("proDeadline", proDeadline);
            map.put("proUnit", proUnit);
            map.put("proPrice", proPrice);
            int n = productMapper.addProduct(map);
            if (n > 0) {
                result = "success";
            } else {
                result = "fail";
            }
        }else {
            result = "again";
        }
        return result;
    }



}