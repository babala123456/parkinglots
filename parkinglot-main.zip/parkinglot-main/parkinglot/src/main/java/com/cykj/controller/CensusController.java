package com.cykj.controller;


import com.cykj.bean.TbParameter;
import com.cykj.service.ParameterService;
import com.cykj.service.RecordService;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/census")
public class CensusController {

    @Resource
    private ParameterService parameterServiceImpl;
    @Resource
    private RecordService recordServiceImpl;


    @RequestMapping("/toFeeCensus")
    @Log(operationName = "访问缴费统计页面",operationType = "访问缴费统计页面")
    public String toFeeCensus(){
        return "back_feeCensus";
    }

    @RequestMapping("/doCensus")
    @Log(operationName = "缴费统计获取数据",operationType = "缴费统计获取数据")
    public @ResponseBody String doCensus(String startTime, String endTime){
        List<TbParameter> list = parameterServiceImpl.findTypeList("用户类型");

        List<String> nameList = new ArrayList<>();
        List<Integer> idList = new ArrayList<>();

        for (int i = 0;i < list.size();i++){
            nameList.add(list.get(i).getpValue());
            idList.add(list.get(i).getpId());
        }

        int[] counts = recordServiceImpl.getFeeCensus(idList,startTime,endTime);

        int sum = 0;
        for (int i = 0;i < counts.length;i++){
            sum += counts[i];
        }

        //将对象转为json字符串
        String nameJson = new Gson().toJson(nameList);
        String countJson = new Gson().toJson(counts);
        String res = nameJson + "&" + countJson + "&" + sum;

        System.out.println("缴费统计数据：" + res);

        return res;
    }
}
