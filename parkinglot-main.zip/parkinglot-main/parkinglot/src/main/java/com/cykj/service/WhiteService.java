package com.cykj.service;

import com.cykj.bean.TbLog;
import com.cykj.bean.TbWhite;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface WhiteService {

    public List<TbWhite> whiteuserSelect();

    public int delWhiteById(int whiteid);

    List<TbWhite> findWhitePage(Map<String, Object> map, int page, int limit);//白名单分页管理

    int findWhiteNum(Map<String, Object> map);

    /**
     * 康春杰
     * [车辆出场功能] 查询车牌是否为白名单
     * @param carNum
     * @return
     */
    public Boolean findWhiteByCarNum(@Param("carNum")String carNum);

    /**
     * 白名单添加
     * @param tbWhite
     * @return
     */
    public int addWhite(TbWhite tbWhite);

    /**
     * 白名单状态修改
     * @param whiteId
     * @param wState
     * @return
     */
    boolean changewhiteState(String whiteId, String wState);
}
