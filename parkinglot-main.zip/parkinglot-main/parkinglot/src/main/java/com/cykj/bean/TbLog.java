package com.cykj.bean;

public class TbLog {
    private int logId;
    private int aId;
    private String logtime;
    private String mapper;
    private TbAdmin tbAdmin;

    public TbLog() {
    }

    @Override
    public String toString() {
        return "TbLog{" +
                "logId=" + logId +
                ", aId=" + aId +
                ", logtime='" + logtime + '\'' +
                ", mapper='" + mapper + '\'' +
                ", tbAdmin=" + tbAdmin +
                '}';
    }

    public TbLog(int logId, int aId, String logtime, String mapper, TbAdmin tbAdmin) {
        this.logId = logId;
        this.aId = aId;
        this.logtime = logtime;
        this.mapper = mapper;
        this.tbAdmin = tbAdmin;
    }

    public int getLogId() {
        return logId;
    }

    public void setLogId(int logId) {
        this.logId = logId;
    }

    public int getaId() {
        return aId;
    }

    public void setaId(int aId) {
        this.aId = aId;
    }

    public String getLogtime() {
        return logtime;
    }

    public void setLogtime(String logtime) {
        this.logtime = logtime;
    }

    public String getMapper() {
        return mapper;
    }

    public void setMapper(String mapper) {
        this.mapper = mapper;
    }

    public TbAdmin getTbAdmin() {
        return tbAdmin;
    }

    public void setTbAdmin(TbAdmin tbAdmin) {
        this.tbAdmin = tbAdmin;
    }
}
