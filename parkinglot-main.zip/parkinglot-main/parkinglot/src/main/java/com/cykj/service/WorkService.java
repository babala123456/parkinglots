package com.cykj.service;

import com.cykj.bean.TbWork;

public interface WorkService {

    /**
     * 根据工作点id，查询排班信息
     * @param workId
     * @return
     */
    public TbWork findWork(int workId);
}
