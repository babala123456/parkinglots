package com.cykj.service.serviceImpl;

import com.cykj.bean.TbCar;
import com.cykj.mapper.CarMapper;
import com.cykj.service.CarService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author Administrator
 */
@Service
public class CarServiceImpl implements CarService {

    @Resource
    private CarMapper carMapper;

    @Override
    public int addCar(TbCar tbCar) {
        int i = carMapper.addCar(tbCar);
        return i;
    }

    @Override
    public int findCarIdByCarNum(String carNum) {
        int carId = carMapper.findCarIdByCarNum(carNum);
        return carId;
    }

    @Override
    public int deleteCarByCarId(int carId) {
        int i = carMapper.deleteCarByCarId(carId);
        return i;
    }

    @Override
    public Boolean findCarByCarNum(String carNum) {
        TbCar tbCar = carMapper.findCarByCarNum(carNum);
        if (null == tbCar) {
            return true;
        }
        return false;
    }

    @Override

    public List<TbCar> findByUserId(int userId) {
        return carMapper.findByUserId(userId);
    }


    public List<TbCar> findCarNum(int userId) {
        return carMapper.findCarNum(userId);
    }

    @Override
    public int duplicateCar(String carNum, int userId) {
        return carMapper.duplicateCar(carNum, userId);
    }

    @Override
    public int bindingCarNum(String carNum, int userId) {
        return carMapper.bindingCarNum(carNum, userId);
    }

    @Override
    public String bingDing(String carNum, int userId) {
        //调用查重的方法
        int i = duplicateCar(carNum, userId);
        if (i > 0) {
            //账号重复的情况
            return "repetition";
        } else {
            int i1 = bindingCarNum(carNum, userId);
            if (i1 > 0) {
                return "success";
            }
        }
        return null;
    }

    @Override
    public TbCar selCarNumByCarId(int carId) {
        return carMapper.selCarNumByCarId(carId);
    }
}
