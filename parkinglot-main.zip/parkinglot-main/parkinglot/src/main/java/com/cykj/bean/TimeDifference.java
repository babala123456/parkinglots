package com.cykj.bean;

import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Administrator
 */
@Component
public class TimeDifference {
    private String enterTime;
    private String parkTime;
    private String outTime;
    private double money;

    private SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private  long nd = 1000 * 24 * 60 * 60;
    private long nh = 1000 * 60 * 60;
    private long nm = 1000 * 60;

    private long diff;
    private long hour;
    private long min;

    private long day;

    public TimeDifference() {
    }

    public TimeDifference(String enterTime, String outTime) {
        this.enterTime = enterTime;
        this.outTime = outTime;
    }

    public String getEnterTime() {
        return enterTime;
    }


    public String getParkTime() {
        // 计算差多少小时
        try {
            diff = simpleFormat.parse(outTime).getTime() - simpleFormat.parse(enterTime).getTime();
            // 计算差多少小时
            hour = diff % nd / nh;
            // 计算差多少分钟
             min = diff % nd % nh / nm;
            this.parkTime = hour+"小时"+min+"分";
            System.out.println(parkTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return parkTime;
    }

    public void setParkTime(String parkTime) {
        this.parkTime = parkTime;
    }

    public void setEnterTime(String enterTime) {
        this.enterTime = enterTime;
    }

    public String getOutTime() {
        return outTime;
    }

    public void setOutTime(String outTime) {
        this.outTime = outTime;
    }

    public double getMoney() throws ParseException {
        // long ns = 1000;
        // 获得两个时间的毫秒时间差异
         diff = simpleFormat.parse(outTime).getTime() - simpleFormat.parse(enterTime).getTime();
        // 计算差多少天
         day = diff / nd;
        // 计算差多少小时
         hour = diff % nd / nh;
        // 计算差多少分钟
         min = diff % nd % nh / nm;
        // 计算差多少秒//输出结果
        // long sec = diff % nd % nh % nm / ns;
        if(day>0) {
            hour = hour + (24 * day);
        }
        if(hour>=0 && min>=0) {
            //不足一小时按一小时计价
            if(min>0) {
                hour =  hour + 1;
            }
            //一小时内
            if(hour==1) {
                money = 0.0;
             //超过免费停车时间2小时内
            }else if(hour>1 && hour-1<=2) {
                money = 3.0;
            }else if(hour > 3) {
                money = 3.0 + (hour-3);
                //24小时内不超过10元
                if(hour <=24&& money >10) {
                    money = 10;
                }
            }
        }
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public int   computationTime(String enterTime, String outTime) {
         simpleFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm");
        /*小时差*/
        Date fromDate2 = null;
        try {
            fromDate2 = simpleFormat.parse(enterTime);
            Date toDate2 = simpleFormat.parse(outTime);
            long from2 = fromDate2.getTime();
            long to2 = toDate2.getTime();
            int hours = (int) ((to2 - from2) / (1000 * 60 * 60));
            System.out.println("两个时间之间的小时差为：" + hours);
            return hours;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        System.out.println("错误：这个是外面的return");
        return -1;
    }

    public  void aa() {
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date d1 = df.parse("2004-03-26 13:31:40");
            Date d2 = df.parse("2004-03-26 11:30:24");
            //这样得到的差值是毫秒级别
            long diff = d1.getTime() - d2.getTime();
            long days = diff / (1000 * 60 * 60 * 24);

            long hours = (diff - days * (1000 * 60 * 60 * 24)) / (1000 * 60 * 60);
            long minutes = (diff - days * (1000 * 60 * 60 * 24) - hours * (1000 * 60 * 60)) / (1000 * 60);
            System.out.println("" + days + "天" + hours + "小时" + minutes + "分");
            System.out.println( hours + "小时" + minutes + "分");
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        TimeDifference timeDifference = new TimeDifference();
        int i = timeDifference.computationTime("2004-03-26 13:31:40", "2004-03-26 11:30:24");
        System.out.println(i);
    }
}
