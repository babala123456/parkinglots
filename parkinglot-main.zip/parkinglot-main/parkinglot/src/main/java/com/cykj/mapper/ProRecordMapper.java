package com.cykj.mapper;


import com.cykj.bean.TbProRecord;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface ProRecordMapper {

    //添加产品办理记录方法
    public int addRecord(TbProRecord proRecord);

    //修改产品办理状态方法
    public int changeState(int proRecordId, int state);
}