package com.cykj.service.serviceImpl;

import com.cykj.bean.TbPlace;
import com.cykj.mapper.PlaceMapper;
import com.cykj.service.PlaceService;
import org.springframework.stereotype.Service;
import sun.util.resources.cldr.ga.TimeZoneNames_ga;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
@Service
public class PlaceServiceImpl implements PlaceService {
    @Resource
    private PlaceMapper placeMapper;
    @Resource
    private TbPlace  tbPlace;

    @Override
    public int findPlaceByParkState(String parkState) {
        int placeNum = placeMapper.findPlaceByParkState(parkState);
        return placeNum;
    }

    @Override
    public TbPlace findUsableStall() {
        TbPlace usableStall = placeMapper.findUsableStall();
        return usableStall;
    }

    @Override
    public int upParkState(int parkState, int placeId) {
        int i = placeMapper.upParkState(parkState, placeId);
        return i;
    }



    /**
     * 根据车位id查询车位信息
     * @param carNum
     * @return
     */
    @Override
    public TbPlace findByCarNum(String carNum) {
        TbPlace place = placeMapper.findByCarNum(carNum);
        return place;
    }

    /**
     * 传入MyPlace对象，修改对象属性
     * @param myPlace
     * @return
     */
    @Override
    public int setPlace(TbPlace myPlace) {
        int res = placeMapper.setPlace(myPlace);
        return res;
    }


    /**
     * 根据车位状态，查询车位信息
     * @param parkState
     * @return
     */
    @Override
    public List<TbPlace> findByState(int parkState) {
        return placeMapper.findByState(parkState);
    }


    /**
     * 根据停车状态，查询车位信息
     * @param isUse
     * @return
     */
    @Override
    public List<TbPlace> findByUsed(int isUse) {
        return placeMapper.findByUsed(isUse);
    }

    @Override
    public  List<TbPlace> findBookingPlace(String zone, int isUse, int parkState) {
        return  placeMapper.findBookingPlace(zone, isUse, parkState);
    }

    @Override
    public int findBookingCount(String zone, int isUse, int parkState) {
        return placeMapper.findBookingCount(zone, isUse, parkState);
    }

    @Override
    public List<TbPlace> findZone() {
        List<TbPlace> zone = placeMapper.findZone();
        for (TbPlace place:zone) {
            int bookingCount = findBookingCount(place.getZone(), 6, 9);
            place.setPlaceId(bookingCount);
        }
        return zone;
    }

    @Override
    public Map disposePlace() {
        //返回所有的区域
        List<TbPlace> zones = findZone();
        //装所有 区域 对应的车位的map
        Map<String,List<TbPlace>> placeMap = new HashMap<>(16);
        //装所有 区域 对饮的车位 数量
        for (TbPlace str:zones) {
            List<TbPlace> bookingPlace = findBookingPlace(str.getZone(), 0, 0);
            placeMap.put(str.getZone(),bookingPlace);
        }
        return placeMap;
    }

    @Override
    public TbPlace findPlaceByPlaceId(int placeId) {
        return placeMapper.findPlaceByPlaceId(placeId);
    }

    /**
     * 查询车位信息总数
     * @return
     */
    @Override
    public int findRecords(Map<String, Object> condition) {
        int res = placeMapper.findRecords(condition);
        return res;
    }

    /**
     * 查询所有车位的信息
     * @return
     */
    @Override
    public List<TbPlace> findPlacesByPage(Map<String, Object> condition,
              Integer startIndex, Integer endIndex) {
        List<TbPlace> list = placeMapper.findPlacesByPage(condition,startIndex,endIndex);
        return list;
    }


    /**
     * 修改车位状态方法
     * @param place
     * @return
     */
    @Override
    public int changeState(TbPlace place) {
        return placeMapper.changeState(place);
    }


    /**
     * 点选地图模型展示车位信息
     * @param mName
     * @return
     */
    @Override
    public TbPlace selectPlace(String mName) {
        return placeMapper.selectPlace(mName);
    }

    /**
     * 根据区域和车位名，判断车位是否已存在
     * @param zone
     * @param placeName
     * @return
     */
    @Override
    public TbPlace findByZoneName(String zone, String placeName) {
        return placeMapper.findByZoneName(zone,placeName);
    }


}
