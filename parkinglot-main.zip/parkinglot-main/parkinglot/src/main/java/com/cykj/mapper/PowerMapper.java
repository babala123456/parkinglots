package com.cykj.mapper;


import com.cykj.bean.TbPower;
import com.cykj.bean.TbWork;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
@Mapper
public interface PowerMapper {

    public int deletePower(@Param("roleId") String roleId);
    public int insertPower(@Param("roleId") String roleId, @Param("menuId") String menuId);

    /**
     * 删除所有的权限id等信息
     * @param roleId
     * @return
     */
    public int deleteAllPower(@Param("roleId")int roleId);

    /**
     * 康春杰
     * [权限配置功能] --添加权限
     * 2020年11月23日16:37:32
     * @param menuId
     * @param roleId
     * @return
     */
    public int addPower(@Param("menuId")int menuId,@Param("roleId")int roleId);
}
