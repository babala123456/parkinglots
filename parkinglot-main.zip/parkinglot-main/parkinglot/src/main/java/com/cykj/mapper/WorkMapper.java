package com.cykj.mapper;


import com.cykj.bean.TbWork;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;


@Repository
@Mapper
public interface WorkMapper {

    /**
     * 根据工作点id，查询排班信息
     * @param workId
     * @return
     */
    public TbWork findWork(@Param("workId") int workId);
}
