package com.cykj.service.serviceImpl;

import com.alibaba.fastjson.JSON;

import com.cykj.bean.*;
import com.cykj.mapper.ParkMapper;
import com.cykj.service.*;
import com.cykj.util.Recognition;
import com.google.gson.Gson;
import org.json.JSONObject;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author Administrator
 */
@Service
public class ParkServiceImpl implements ParkService {
    @Resource
    private ParkMapper parkMapper;
    @Resource
    private CarService carServiceImpl;
    @Resource
    private WhiteService whiteServiceImpl;
    @Resource
    private PlaceService placeServiceImpl;
    @Resource
    private RuleService ruleServiceImpl;
    @Resource
    private HandleService handleServiceImpl;
    @Resource
    private RecordService recordServiceImpl;
    @Resource
    private BookingService bookingServiceImpl;

    @Resource
    private TbCar tbCar;
    @Resource
    private TbPark Park;
    @Resource
    private TbRecord tbRecord;
    @Resource
    private TimeDifference timeDifference;
    @Resource
    private RecognitionInfo recognitionInfo;



    private JSONObject jsonObject = new JSONObject();

    /**
     * 车牌图片 识别进场
     *
     * @param surplus
     * @param carNumFile
     * @return
     */
    @Override
    public String parkByCarNumImg(int surplus, String carNumFile, String imgFile) {

        if (0 != surplus) {
            String result = null;
            if (null != carNumFile) {
                //识别返回识别结果字符串
                result = Recognition.licensePlateRecognition(carNumFile);
            }
            //将字符串映射至对象
            recognitionInfo = JSON.parseObject(result, RecognitionInfo.class);
            if (null != recognitionInfo) {
                //得到车牌
                int errorCode = 282103;
                if (errorCode == recognitionInfo.getError_code()) {
                    jsonObject.put("code", 1);
                    jsonObject.put("msg", "carNumError");
                    return jsonObject.toString();
                }
                String carNum = recognitionInfo.getWordsResult().getNumber();
                //进场方法
                return CarEnter(carNum, carNumFile, imgFile);
            }
        } else {
            jsonObject.put("code", 1);
            jsonObject.put("msg", "full");
            return jsonObject.toString();
        }
        return "停车失败";
    }

    /**
     * 手动输入车牌进场
     *
     * @param surplus
     * @param carNum
     * @return
     */
    @Override
    public String parkByCarNum(int surplus, String carNum) {
        if (0 != surplus) {
            return CarEnter(carNum, "进场：该车牌【" + carNum + "】为手动输入的车牌", "进场：该车牌【" + carNum + "】为手动输入的车牌");
        } else {
            jsonObject.put("code", 1);
            jsonObject.put("msg", "full");
            return jsonObject.toString();
        }
    }

    /**
     * 图片识别车牌出场
     *
     * @param carNumImg
     * @return
     */
    @Override
    public String outByCarNumImg(String carNumImg, String imgFile) {
        if (null != carNumImg) {
            //识别车牌
            String result = Recognition.licensePlateRecognition(carNumImg);
            System.err.println("Recognition:" + result);
            //得到车牌信息
            if (null != result) {
                recognitionInfo = JSON.parseObject(result, RecognitionInfo.class);
            }
            //调用 出场方法，将车牌、区域等信息 返回
            if (null != recognitionInfo) {
                //出场方法
                return carOut(recognitionInfo.getWordsResult().getNumber(), carNumImg, imgFile);
            }
        }
        return null;
    }

    /**
     * 手动输入车牌出场
     *
     * @param carNum
     * @return
     */
    @Override
    public String outByCarNum(String carNum) {
        //出场方法
        return carOut(carNum, "出场：该车牌[" + carNum + "]为手动输入的车牌", "出场：该车牌[" + carNum + "]为手动输入的车牌");
    }

    @Override
    public int updateInfo(String outImg, int parkState, int parkId) {
        int i = parkMapper.updateInfo(outImg, parkState, parkId);
        return i;
    }

    @Override
    public String findParkTime(int parkId) {
        TbPark parkTime = parkMapper.findParkTime(parkId);
        timeDifference.setEnterTime(parkTime.getEnterTime());
        timeDifference.setOutTime(parkTime.getOutTime());
        return timeDifference.getParkTime();
    }

    @Override
    public TbPark findCarImg(String mName) {
        TbPark carImg = parkMapper.findCarImg(mName);
        return carImg;
    }

    @Override
    public int addParkInfo(TbPark tbPark) {
        int i = parkMapper.addParkInfo(tbPark);
        return i;
    }

    /**
     * 进场
     *
     * @param carNum
     * @param carNumFile
     * @return
     */
    @Override
    public String CarEnter(String carNum, String carNumFile, String imgFile) {
        //判断识别后是否为正确的车牌，  设置car实体类属性
        if (Recognition.checkPlateNumberFormat(carNum)) {
            //设置属性
            tbCar.setCarNum(carNum);
            //判断是否在表中存在，如果不存在则加进去 取出CarId /如果存在则取出carId
            int n = 0;
            int carId = 0;
            if (carServiceImpl.findCarByCarNum(carNum)) {
                System.out.println("carId不存在，添加");
                //将car属性添加至 car 表中
                n = carServiceImpl.addCar(tbCar);
                //获取 carId
                carId = tbCar.getCarId();
            } else {
                System.out.println("carId存在");
                carId = carServiceImpl.findCarIdByCarNum(carNum);
            }

            if (0 != carId) {
                //判断 该车牌号 是否在park表中
                TbPark tbPark = parkMapper.findCarWhetherIn(carId, 20);
                if (null == tbPark) {
                    System.out.println("不在park表中");

                    //预约功能 1、查询该车牌 是否预约
                    TbBooking tbBooking = bookingServiceImpl.whetherBooking(carId, 36);
                    //未预约 则分配车位
                    if (null == tbBooking) {
                        //拿到一个可用的 车位的 数据
                        TbPlace tbPlace = placeServiceImpl.findUsableStall();
                        if (tbPlace != null) {
                            //将【车位表】中 该 车位 状态改为不可用
                            int parkState = placeServiceImpl.upParkState(10, tbPlace.getPlaceId());
                            if (parkState > 0) {
                                //将/carId / 车位ID / 进场图片/ 进出场状态/ 更新到【停车表】中
                                System.err.println("parkState > 0：" + carId);
                                Park.setCarId(carId);
                                Park.setPlaceId(tbPlace.getPlaceId());
                                Park.setEnterImg(imgFile);
                                Park.setParkState(20);
                                int i = addParkInfo(Park);
                                if (i > 0) {
                                    //将车牌号，具体车位等信息返回
                                    String tbPlaceJSon = new Gson().toJson(tbPlace);
                                    jsonObject.put("code", 0);
                                    jsonObject.put("msg1", carNum);
                                    jsonObject.put("msg2", tbPlaceJSon);
                                    return jsonObject.toString();
                                } else {
                                    System.out.println("停车失败");
                                    jsonObject.put("code", 1);
                                    jsonObject.put("msg", "lose");
                                    return jsonObject.toString();
                                }
                            }
                            System.out.println("车位状态：" + parkState);
                        }
                    } else {
                        //已预约则 拿到已经预约的车位属性
                        TbPlace bookingPlace = placeServiceImpl.findPlaceByPlaceId((int) tbBooking.getPlaceId());
                        if (null!=bookingPlace){
                            //将【车位表】中 该 车位 状态改为 已停车
                            int parkState = placeServiceImpl.upParkState(10, (int) tbBooking.getPlaceId());
                            //修改成功 添加至 park 表中
                            if (parkState>0){
                                Park.setCarId(carId);
                                Park.setPlaceId((int) tbBooking.getPlaceId());
                                Park.setEnterImg(imgFile);
                                Park.setParkState(20);
                                int i = addParkInfo(Park);
                                if (i > 0) {
                                    //将车牌号，具体车位等信息返回
                                    String tbPlaceJSon = new Gson().toJson(bookingPlace);
                                    jsonObject.put("code", 0);
                                    jsonObject.put("msg1", carNum);
                                    jsonObject.put("msg2", tbPlaceJSon);
                                    return jsonObject.toString();
                                } else {
                                    System.out.println("停车失败");
                                    jsonObject.put("code", 1);
                                    jsonObject.put("msg", "lose");
                                    return jsonObject.toString();
                                }
                            }
                        }
                    }
                } else {
                    System.out.println("在park表中");
                    jsonObject.put("code", 1);
                    jsonObject.put("msg", "alreadyExist");
                    return jsonObject.toString();
                }
            }
        } else {
            jsonObject.put("code", 1);
            jsonObject.put("msg", "carNumError");
            return jsonObject.toString();
        }
        return null;
    }

    /**
     * 出场方法
     *
     * @param carNum
     * @return
     */
    @Override
    public String carOut(String carNum, String carNumImg, String imgFile) {
        //车牌ID
        int carId = 0;
        //停车时间
        String parkTime = null;
        //费用
        String consume = null;

        //查询该车牌的ID
        if (null != carNum) {
            carId = carServiceImpl.findCarIdByCarNum(carNum);
        }

        TbPark tbPark = null;
        //首先 判断该车牌是否在 car表 中，以及识别的车牌是否正确
        if (0 != carId && Recognition.checkPlateNumberFormat(carNum)) {
            System.out.println("carId:" + carId);
            //其次 判断车牌是否在park表中
            tbPark = parkMapper.findCarWhetherIn(carId, 20);
            //如果在 park表中 ，则进行修改操作
            if (null != tbPark) {
                //通过 carID 修改表中 outTime为当前时间 outImg / parkState 出入场状态
                int i = updateInfo(imgFile, 21, tbPark.getParkId());
                //修改 座位表为 未停车状态
                placeServiceImpl.upParkState(9, tbPark.getPlaceId());
                //将预约状态改为过期
                //查询是否预约
                TbBooking tbBooking = bookingServiceImpl.whetherBooking(carId, 36);
                if(null!=tbBooking){
                    bookingServiceImpl.updateBookingState(37, (int) tbBooking.getBookingId());
                    System.err.println("预约作废");
                }

                //查询到车牌的停车时间
                parkTime = findParkTime(tbPark.getParkId());
                //如果不在，则返回字符串
            } else {
                jsonObject.put("code", 1);
                jsonObject.put("msg", "nonentity");
                System.out.println("错误");
                return jsonObject.toString();
            }

            //查询月缴用户信息
            List<TbHandle> tbHandle = handleServiceImpl.findHandleByCarId(carId, 15);
            System.out.println("是否为月缴用户：" + tbHandle.size());
            //通过车牌判断查询判断该用户是否为白名单 --放行
            if (whiteServiceImpl.findWhiteByCarNum(carNum)) {

                jsonObject.put("code", 0);
                jsonObject.put("msg", "white");
                jsonObject.put("carNum", carNum);
                jsonObject.put("parkTime", parkTime);

                //将数据添加至Record表中  设置 placeId parkImg moneyPay
                tbRecord.setParkId(tbPark.getParkId());
                tbRecord.setParkTime(parkTime);
                tbRecord.setMoneyPay("0");
                tbRecord.setType(22);
                //添加至表中
                recordServiceImpl.addRecord(tbRecord);
                System.out.println("是白名单");
                //判断是否为月缴用户        --放行
            } else if (0 != tbHandle.size()) {
                jsonObject.put("code", 0);
                jsonObject.put("msg", "month");
                jsonObject.put("carNum", carNum);
                jsonObject.put("parkTime", parkTime);

                //将数据添加至Record表中 设置 placeId parkImg moneyPay
                tbRecord.setParkId(tbPark.getParkId());
                tbRecord.setParkTime(parkTime);
                tbRecord.setMoneyPay("0");
                tbRecord.setType(23);
                //添加至表中
                recordServiceImpl.addRecord(tbRecord);

                System.out.println("是月缴用户");
            } else {
                //是否为临时用户        --计费放行
                //计算用户 停车费用
                consume = ruleServiceImpl.consume(carNum, tbPark.getParkId());
                System.out.println("consume:" + consume);

                //将停[停车费用、车牌信息、停车时间、回显]’
                jsonObject.put("code", 0);
                jsonObject.put("msg", "temporary");
                jsonObject.put("carNum", carNum);
                jsonObject.put("money", consume);
                jsonObject.put("parkTime", parkTime);

                //将数据添加至Record表中 设置 placeId parkImg moneyPay
                tbRecord.setParkId(tbPark.getParkId());
                tbRecord.setParkTime(parkTime);
                tbRecord.setMoneyPay(consume);
                tbRecord.setType(24);
                //添加至表中
                recordServiceImpl.addRecord(tbRecord);
                //将添加完后该条ID返回
                jsonObject.put("recordId", tbRecord.getRecordId());
                System.out.println("是临时用户");
            }
        } else {

            jsonObject.put("code", 1);
            jsonObject.put("msg", "carNumError");
            System.out.println("错误");
        }
        return jsonObject.toString();
    }

    @Override
    public TbPark findParkByCarNum(String carNum, int parkId) {
        return parkMapper.findParkByCarNum(carNum, parkId);
    }

    @Override
    public TbPark findCarWhetherIn(int carId, int parkState) {
        TbPark carWhetherIn = parkMapper.findCarWhetherIn(carId, parkState);
        return carWhetherIn;
    }


    /**
     * 查询当日停车总数
     *
     * @param startTime
     * @return
     */
    @Override
    public int findRecords(String startTime, String endTime) {
        return parkMapper.findRecords(startTime, endTime);
    }

    /**
     * 根据车牌号查询停车信息
     * @param carNum
     * @return
     */
    @Override
    public TbPark findByCarNum(String carNum) {
        return parkMapper.findByCarNum(carNum);
    }
}
