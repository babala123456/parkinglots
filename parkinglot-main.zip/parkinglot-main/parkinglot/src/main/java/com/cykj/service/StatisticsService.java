package com.cykj.service;

public interface StatisticsService {

    public int findComboMenu(int productId);
    public int findusergrowth(String nowData, int mouth, int userType);
    public int findwhiteuser(String nowData, int mouth);
}
