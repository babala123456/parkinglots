package com.cykj.bean;


public class TbProRecord {

  private long proRecordId;
  private long adminId;
  private long productId;
  private double pay;
  private String orderNum;
  private long orderState;


  public long getProRecordId() {
    return proRecordId;
  }

  public void setProRecordId(long proRecordId) {
    this.proRecordId = proRecordId;
  }


  public long getAdminId() {
    return adminId;
  }

  public void setAdminId(long adminId) {
    this.adminId = adminId;
  }


  public long getProductId() {
    return productId;
  }

  public void setProductId(long productId) {
    this.productId = productId;
  }


  public double getPay() {
    return pay;
  }

  public void setPay(double pay) {
    this.pay = pay;
  }


  public String getOrderNum() {
    return orderNum;
  }

  public void setOrderNum(String orderNum) {
    this.orderNum = orderNum;
  }


  public long getOrderState() {
    return orderState;
  }

  public void setOrderState(long orderState) {
    this.orderState = orderState;
  }

}
