package com.cykj.controller;

import com.cykj.bean.SpCommodity;
import com.cykj.bean.SpType;
import com.cykj.bean.TableInfo;
import com.cykj.bean.TbSchedules;
import com.cykj.service.CommodityService;
import com.cykj.util.Common;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class CommodityController {

    @Resource
    CommodityService commodityServiceImpl;

    /**
     * 跳转到商品表
     * @return
     */
    @RequestMapping("/market")
    @Log(operationName = "返回商品商城页面",operationType = "返回商品商城页面")
    public String marketLogin(HttpServletRequest request){
        List<SpType> spTypeList = commodityServiceImpl.findSpType();
        request.setAttribute("spTypeList",spTypeList);
        return "sp_commodity";
    }

    /**
     * 查询商品表列表
     * @param
     */
    @RequestMapping("/list")
    @Log(operationName = "返回商品页面",operationType = "返回商品页面")
    @ResponseBody
    public String findCommodity(HttpServletRequest request, int page, int limit,String spName) throws IOException {
        Map<String, Object> map = new HashMap<>();
        if(Common.notEmpty(spName)){
            request.setAttribute("spName",spName);
            map.put("spName", "%" + spName + "%");
        }
        List<SpCommodity> spCommodityList = commodityServiceImpl.findCommodity(map,(page-1)*limit,limit);
        int res = commodityServiceImpl.findComRecords(map);
        TableInfo tableInfo = new TableInfo();
        tableInfo.setCode(0);
        tableInfo.setCount(res);
        tableInfo.setMsg("用户列表数据信息");
        tableInfo.setData(spCommodityList);

        String remsg = new Gson().toJson(tableInfo);
        return remsg;
    }

    /**
     * 上架下架
     * @param cmtId
     * @param spState
     * @return
     */
    @RequestMapping("/changeSpState")
    @Log(operationName = "返回商品页面",operationType = "返回商品页面")
    @ResponseBody
    public String changeSpState(int cmtId,int spState){
        String n = commodityServiceImpl.changeSpState(cmtId,spState);
        return n;
    }

    /**
     * 修改一条商品信息
     * @return
     */
    @RequestMapping("/updateCommodity")
    @Log(operationName = "返回商品页面",operationType = "返回商品页面")
    @ResponseBody
    public int updateCommodity(String spName, int price, int inventory,int teid, String spDetails, int cmtId){
        int n = commodityServiceImpl.updateCommodity(spName,price,inventory,teid,spDetails,cmtId);
        System.out.println("这里的n是多少呢？"+n);
        return n;
    }

    /**
     * 新增商品
     * @return
     */
    @RequestMapping("/addCommodity")
    @Log(operationName = "返回商品页面",operationType = "返回商品页面")
    @ResponseBody
    public int addCommodity(String spName,int price,int inventory,int teid,String spDetails){
        int n = commodityServiceImpl.addCommodity(spName,price,inventory,teid,spDetails);
        return n;
    }

    /**
     * 删除一条商品表信息
     * @param cmtId
     * @return
     */
    @RequestMapping("/delCommodity")
    @Log(operationName = "返回商品页面",operationType = "返回商品页面")
    @ResponseBody
    public String delCommodity(int cmtId){
        String result = commodityServiceImpl.delCommodity(cmtId);
        return result;
    }

}
