package com.cykj.service;

import com.cykj.bean.TbPark;
import org.apache.ibatis.annotations.Param;

/**
 * @author Administrator
 */
public interface ParkService {

    /**
     * 康春杰
     * [前台车辆入场功能]：通过传入识别出来的图片进行后台数据逻操作
     * @param carNumFile
     * @param surplus
     * @param imgFile
     * @return
     */
    public String parkByCarNumImg(int surplus,String carNumFile,String imgFile);



    /**
     * 康春节
     * [前台车辆入场功能]：通过传入 车牌号码 进行后台数据逻操作
     * @param carNum
     * @param surplus
     * @return
     */
    public String parkByCarNum(int surplus,String carNum);

    /**
     *康春杰
     *[前台车辆入场功能]：将 carId / placeId/enterTime/parkState添加至 停车表 中
     * @param tbPark
     * @return
     */
    public int addParkInfo(TbPark tbPark);


    /**
     * 康春杰
     * [前台车辆出场功能]：通过传入识别出来的图片进行后台数据逻出场操作
     * @param carNumFile
     * @param imgFile
     * @return
     */
    public String outByCarNumImg(String carNumFile,String imgFile);

    /**
     * 康春杰
     * [前台车辆出场功能]： 手动输入车牌 进行后台数据逻出场操作
     * @param carNum
     * @return
     */
    public String outByCarNum(String carNum);

    /**
     * 康春杰
     *  [前台车辆出场功能]： 修改用户出场时间
     *  2020年11月20日10:57:56
     * @param parkState
     * @param outImg
     * @param parkId
     * @return
     */
    public int updateInfo(String outImg,int parkState,int parkId);

    /**
     * 康春杰
     *  [前台车辆出场功能]： 返回停车时间
     * @param parkId
     * @return
     */
    public String findParkTime(int parkId);

    /**
     * 康春杰
     * [场内车辆查看功能] ：联表查询 停车信息 用于显示图片
     * @param mName
     * @return
     */
    public TbPark findCarImg(@Param("mName")String mName);

    /**
     * 出场方法
     * @param carNum
     * @param carNumImg
     * @param imgFile
     * @return
     */
    public String carOut(String carNum,String carNumImg,String imgFile);

    /**
     * 进场方法
     * @param carNum
     * @param carNumImg
     * @param imgFile
     * @return
     */
    public String CarEnter(String carNum,String carNumImg,String imgFile);


    /**
     * 根据车牌查询停车对象
     * @param carNum
     * @param parkId
     * @return
     */
    public TbPark findParkByCarNum(String carNum,int parkId);


    /**
     * 康春杰
     * 2020年11月20日14:25:10
     * 查询车辆是否在park表中 并且停车状态为 未出场
     * @param carId
     * @param parkState
     * @return
     */
    public TbPark findCarWhetherIn( int carId,int parkState);

    /**
     * 查询当日停车总数
     * @return
     */
    public int findRecords(String startTime, String endTime);

    /**
     * 根据车牌号查询停车信息
     * @param carNum
     * @return
     */
    public TbPark findByCarNum(String carNum);
}
