package com.cykj.mapper;

import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbLog;
import org.apache.ibatis.annotations.Mapper;
import org.mybatis.spring.annotation.MapperScan;

import java.util.List;
import java.util.Map;

@MapperScan(value = "logMapper")
@Mapper
public interface LogMapper {
    public List<TbLog> findLogOnPage(Map<String,Object> map);
    public int findLogNum(Map<String,Object> map);
   public int addBackLog(TbLog tbLog);
}
