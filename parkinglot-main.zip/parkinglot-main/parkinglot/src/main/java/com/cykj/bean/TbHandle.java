package com.cykj.bean;

/**
 * @author Administrator
 */
public class TbHandle {

    private int bussId;
    private int carId;
    private int productId;
    private String effectedTime;
    private String finishTime;
    private String orderNum;
    private int handleState;
    private TbProduct tbProduct;
    private TbUser tbUser;
    private TbCar tbCar;
    private TbParameter tbParameter;


    public TbHandle() {

    }

    public TbHandle(int bussId, int carId, int productId, String effectedTime, String finishTime, int handleState, TbProduct tbProduct, TbUser tbUser, TbCar tbCar, TbParameter tbParameter) {
        this.bussId = bussId;
        this.carId = carId;
        this.productId = productId;
        this.effectedTime = effectedTime;
        this.finishTime = finishTime;
        this.handleState = handleState;
        this.tbProduct = tbProduct;
        this.tbUser = tbUser;
        this.tbCar = tbCar;
        this.tbParameter = tbParameter;
    }

    public int getBussId() {
        return bussId;
    }

    public void setBussId(int bussId) {
        this.bussId = bussId;
    }

    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getEffectedTime() {
        return effectedTime;
    }

    public void setEffectedTime(String effectedTime) {
        this.effectedTime = effectedTime;
    }

    public String getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(String finishTime) {
        this.finishTime = finishTime;
    }

    public int getHandleState() {
        return handleState;
    }

    public void setHandleState(int handleState) {
        this.handleState = handleState;
    }

    public TbProduct getTbProduct() {
        return tbProduct;
    }

    public void setTbProduct(TbProduct tbProduct) {
        this.tbProduct = tbProduct;
    }

    public TbUser getTbUser() {
        return tbUser;
    }

    public void setTbUser(TbUser tbUser) {
        this.tbUser = tbUser;
    }

    public TbCar getTbCar() {
        return tbCar;
    }

    public void setTbCar(TbCar tbCar) {
        this.tbCar = tbCar;
    }

    public TbParameter getTbParameter() {
        return tbParameter;
    }

    public void setTbParameter(TbParameter tbParameter) {
        this.tbParameter = tbParameter;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }
}
