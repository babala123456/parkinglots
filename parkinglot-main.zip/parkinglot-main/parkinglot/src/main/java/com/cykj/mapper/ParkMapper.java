package com.cykj.mapper;

import com.cykj.bean.TbCar;
import com.cykj.bean.TbPark;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @author Administrator
 */
@Repository
@Mapper
public interface ParkMapper {

    /**
     * 根据车牌号查询停车信息
     * @param carNum
     * @return
     */
    public TbPark findByCarNum(@Param("carNum") String carNum);

    /**
     * 康春杰
     * [前台车辆入场功能]：将车牌信息添加至 tb_car表中 并返回插入后的 ID
     * @param tbCar
     * @return
     */
    public int addCar(TbCar tbCar);

    /**
     *康春杰
     *[前台车辆入场功能]：将 carId / placeId添加至 停车表 中
     * @param tbPark
     * @return
     */
    public int addParkInfo(TbPark tbPark);

    /**
     * 康春杰
     *  [前台车辆出场功能]： 修改用户出场 的信息
     *  2020年11月20日10:56:27
     * @param parkState
     * @param outImg
     * @param parkId
     * @return
     */
    public int updateInfo(@Param("outImg") String outImg,@Param("parkState") int parkState,@Param("parkId") int parkId);


    /**
     *康春杰
     *[前台车辆出场功能]：通过carId 返回  TbPark对象
     * @param parkId
     * @return
     */
    public TbPark findParkTime(@Param("parkId") int parkId);

    /**
     * 康春杰
     * 2020年11月20日14:25:10
     * 查询车辆是否在park表中
     * @param carId
     * @param parkState
     * @return
     */
    public TbPark findCarWhetherIn(@Param("carId") int carId,@Param("parkState")int parkState);

    /**
     * 康春杰
     * [场内车辆查看功能] ：联表查询 停车信息 用于显示图片
     * @param mName
     * @return
     */
    public TbPark findCarImg(@Param("mName")String mName);

    /**
     * 根据车牌查询停车对象
     * @param carNum
     * @param parkId
     * @return
     */
    public TbPark findParkByCarNum(@Param("carNum") String carNum,
           @Param("parkId")int parkId);


    /**
     * 根据车牌查询停车对象
     * @param carNum
     * @return
     */
    public TbPark findParkByNumt(@Param("carNum") String carNum,
                                 @Param("enterTime") String enterTime);


    /**
     * 查询当日停车总数
     * @return
     */
    public int findRecords(@Param("startTime") String startTime,
                           @Param("endTime") String endTime);
}


