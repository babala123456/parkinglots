package com.cykj.service;

import com.cykj.bean.TbProRecord;

public interface ProRecordService {

    //添加产品办理记录方法
    public int addRecord(TbProRecord proRecord);

    //修改产品办理状态方法
    public int changeState(int proRecordId, int state);
}
