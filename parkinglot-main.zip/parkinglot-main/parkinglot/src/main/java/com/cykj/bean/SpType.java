package com.cykj.bean;


public class SpType {

  private int teid;
  private String spType;

  public SpType() {
  }

  public SpType(int teid, String spType) {
    this.teid = teid;
    this.spType = spType;
  }

  public int getTeid() {
    return teid;
  }

  public void setTeid(int teid) {
    this.teid = teid;
  }

  public String getSpType() {
    return spType;
  }

  public void setSpType(String spType) {
    this.spType = spType;
  }
}
