package com.cykj.bean;


public class SpCommodity {

  private int cmtId;
  private String spName;
  private int price;
  private int teid;
  private String spDetails;
  private int inventory;
  private int spState;

  private SpType spTypes;
  private TbParameter parameter;
  private String spType;
  private String state;

  public SpCommodity() {
  }

  public SpCommodity(int cmtId, String spName, int price, int teid, String spDetails, int inventory, int spState, SpType spTypes, TbParameter parameter, String spType, String state) {
    this.cmtId = cmtId;
    this.spName = spName;
    this.price = price;
    this.teid = teid;
    this.spDetails = spDetails;
    this.inventory = inventory;
    this.spState = spState;
    this.spTypes = spTypes;
    this.parameter = parameter;
    this.spType = spType;
    this.state = state;
  }

  public int getCmtId() {
    return cmtId;
  }

  public void setCmtId(int cmtId) {
    this.cmtId = cmtId;
  }

  public String getSpName() {
    return spName;
  }

  public void setSpName(String spName) {
    this.spName = spName;
  }

  public int getPrice() {
    return price;
  }

  public void setPrice(int price) {
    this.price = price;
  }

  public int getTeid() {
    return teid;
  }

  public void setTeid(int teid) {
    this.teid = teid;
  }

  public String getSpDetails() {
    return spDetails;
  }

  public void setSpDetails(String spDetails) {
    this.spDetails = spDetails;
  }

  public int getInventory() {
    return inventory;
  }

  public void setInventory(int inventory) {
    this.inventory = inventory;
  }

  public int getSpState() {
    return spState;
  }

  public void setSpState(int spState) {
    this.spState = spState;
  }

  public SpType getSpTypes() {
    return spTypes;
  }

  public void setSpTypes(SpType spTypes) {
    this.spTypes = spTypes;
  }

  public TbParameter getParameter() {
    return parameter;
  }

  public void setParameter(TbParameter parameter) {
    this.parameter = parameter;
  }

  public String getSpType() {
    return spType;
  }

  public void setSpType(String spType) {
    this.spType = spType;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }
}
