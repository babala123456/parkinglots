package com.cykj.controller;


import com.cykj.bean.MyPoint;
import com.cykj.bean.TbPark;
import com.cykj.bean.TbPlace;
import com.cykj.service.ParameterService;
import com.cykj.service.ParkService;
import com.cykj.service.PlaceService;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.apache.taglibs.standard.tag.common.sql.DataSourceUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.time.Duration;
import java.time.LocalDateTime;

@Controller
@RequestMapping("/map")
public class MapController {

    @Resource
    private ParameterService parameterServiceImpl;
    @Resource
    private PlaceService placeServiceImpl;
    @Resource
    private ParkService parkServiceImpl;


    public static void main(String[] args) {
//        String oldTime = "2020-11-17 02:28:50";
        LocalDateTime oldTime = LocalDateTime.of(2020,11,16,
                14,28,50);
        LocalDateTime outTime = LocalDateTime.now();

        Duration duration = Duration.between(oldTime, outTime);

        System.out.println();
        System.out.println(outTime);
        System.out.println(duration.toHours());
        System.out.println(outTime.toString().split("T")[0]);
    }


    @RequestMapping("/toMapMg")
    @Log(operationName = "访问车位信息修改页面",operationType = "访问车位信息修改页面")
    public String testMap()
    {
        return "back_mapMg";
    }


    @RequestMapping("/searchExit")
    @Log(operationName = "反向寻车的车是否存在",operationType = "反向寻车的车是否存在")
    public @ResponseBody String searchExit(String carNum)
    {
        String msg = "";
        TbPark park = parkServiceImpl.findByCarNum(carNum);
        if(park == null){
            msg =  "fail";
        }else{
           msg = "success";
        }
        return msg;
    }


    /**
     *
     * @param request
     * @return
     */
    @RequestMapping("/searchCar")
    @Log(operationName = "反向寻车方法",operationType = "反向寻车方法")
    public String searchCar(String carNum, HttpServletRequest request)
    {
        String msg = "";
        //设置导航起点坐标
        MyPoint start = (MyPoint) request.getSession().getAttribute("start");

        //设置导航起点
        if(start == null)
        {
            synchronized (MyPoint.class)
            {
                if(start == null)
                {
                    start = new MyPoint();
                    String pointX = parameterServiceImpl.findByType("导航起点X轴位置");
                    String pointY = parameterServiceImpl.findByType("导航起点Y轴位置");
                    start.setPointX(pointX);
                    start.setPointY(pointY);

                    request.getSession().setAttribute("start",start);
                }
            }
        }

        //设置导航终点坐标
        MyPoint end = new MyPoint();

        TbPlace place = placeServiceImpl.findByCarNum(carNum);

        if(place != null){
            end.setPointX(place.getPointX());
            end.setPointY(place.getPointY());

            System.out.println("终点坐标:" + end.getPointX() + "-" + end.getPointY());

            request.setAttribute("end",end);
        }

        return "front_searchCar";
    }


    /**
     * 跳转鸟瞰图页面方法
     * @return
     */
    @RequestMapping("/eagleEye")
    @Log(operationName = "访问鸟瞰图页面",operationType = "访问鸟瞰图页面")
    public String eagleEye(){
        return "back_eagleEyeMap";
    }


    /**
     * 跳转鸟瞰图页面方法
     * @return
     */
    @RequestMapping("/photosMap")
    @Log(operationName = "访问查看停车照片页面",operationType = "访问查看停车照片页面")
    public String photosMap(){
        return "back_photosMap";
    }

    @RequestMapping("/showCarImg")
    @ResponseBody
    @Log(operationName = "查询停车车辆图片",operationType = "逻辑操作")
    public String showCarImg(String mName){
        TbPark tbPark = parkServiceImpl.findCarImg(mName);
        if (null!=tbPark){
            String result = new Gson().toJson(tbPark);
            System.out.println("result:"+result);
            return result+"&success";
        }else if (null==tbPark){
            System.out.println("tbPark为空");
            return "null";
        }else{
            return "lose";
        }
    }
}
