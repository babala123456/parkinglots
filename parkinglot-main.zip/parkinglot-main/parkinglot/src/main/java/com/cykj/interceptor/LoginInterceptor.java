package com.cykj.interceptor;

import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbUser;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class LoginInterceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {
        boolean flag = false;

        String requestUri = request.getRequestURI();
        String contextPath = request.getContextPath();
        String url = requestUri.substring(contextPath.length());

        if("/toLogin".equals(url) || "/login".equals(url) || "/getVcode".equals(url)
            || "/welcome".equals(url) || "/toRegister".equals(url)
            || "/frontRegister".equals(url))
        {
            flag = true;
        }
        else
        {
            TbAdmin tbAdmin = (TbAdmin) request.getSession().getAttribute("admin");

            if(tbAdmin == null)
            {
                request.getRequestDispatcher("/vlogin").forward(request,response);
                flag = false;
            }
            else
            {
                flag = true;
            }
        }
        return flag;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {
        System.out.println("-- 页面被拦截掉了喔 --");
    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {
        System.out.println("--- 拦截后 ---");
    }
}
