package com.cykj.service;

import com.cykj.bean.TbRole;
import com.cykj.bean.TbUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface BackUserService {
    public List<TbUser> backuserSelect();

    public List<TbRole> roleSelect();

    public List<TbUser> selectAccount(String account);//查询账号是否已存在

    public int deFrontUser(int userId);

    boolean changeUserState(String userId, String userState);//前台状态修改

    public int insertUser(TbUser tbUser);

    List<TbUser> finduserPage(Map<String, Object> map, int page, int limit);//

    int finduserNum(Map<String, Object> map);

    int updateUser(int userId, String userName, String phone, String email);
}
