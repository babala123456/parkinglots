package com.cykj.service;

import com.cykj.bean.TbHandle;
import com.cykj.bean.TbProduct;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
public interface HandleService {

    /**
     * 获取业务信息展示在页面上
     * @return
     */
    public List<TbProduct> getProducts();

    /**
     * 根据车辆id查询车辆最新办理的业务
     * @param carId
     * @return
     */
    public TbHandle findByCarId(int carId);


    /**
     * 办理业务时续费业务的方法
     * @param tbHandle
     * @return
     */
    public int setFinishTime(TbHandle tbHandle);


    /**
     * 新增业务办理记录方法
     * @param tbHandle
     * @return
     */
    public int addHandle(TbHandle tbHandle);

    /**
     * 康春杰
     * 2020年11月19日14:13:54
     * [车辆出场功能] 查询 用户是否有办理 产品
     * @param carId
     * @param handleState
     * @return
     */
    public List<TbHandle> findHandleByCarId(int carId, int handleState);

    /**
     * 数据查询与模糊查询
     * @param map
     * @param curPage
     * @param limit
     * @return
     */
    public List<TbHandle> findHandlePage(Map<String, Object> map, int curPage, int limit);
    public int findHandleNum(Map<String,Object> map);//分页查询

}
