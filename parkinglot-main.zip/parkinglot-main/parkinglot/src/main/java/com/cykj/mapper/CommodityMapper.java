package com.cykj.mapper;

import com.cykj.bean.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface CommodityMapper {

    /**
     * 查询商品表
     * @param map
     * @param starNum
     * @param endNum
     * @return
     */
    public List<SpCommodity> findCommodity(@Param("map") Map map, @Param("starNum") Integer starNum, @Param("endNum") Integer endNum);

    /**
     * 查询记录数
     * @param map
     * @return
     */
    public int findComRecords(@Param("map") Map<String, Object> map);

    /**
     * 商品的禁用启用
     * @param cmtId
     * @param spState
     * @return
     */
    public int changeSpState(int cmtId, int spState);

    /**
     * 修改商品信息
     * @return
     */
    public int updateCommodity(String spName, int price, int inventory, int teid,String spDetails, int cmtId);

    /**
     * 查找sp_type的spType
     * @return
     */
    public List<SpType> findSpType();

    /**
     * 新增商品信息
     * @param map
     * @return
     */
    public int addCommodity(Map map);

    //重复名判断
    public List<SpCommodity> findNameAgain(String spName);

    /**
     * 删除一条商品表信息
     * @param cmtId
     * @return
     */
    public int delCommodity(int cmtId);

}
