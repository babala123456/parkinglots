package com.cykj.bean;

import org.springframework.stereotype.Component;

/**
 * @author Administrator
 */
@Component
public class TbUser {

  private int userId;
  private String account;
  private String password;
  private String userName;
  private String sex;
  private String phone;
  private String email;
  private String regTime;
  private int userState;

    public TbUser() {
    }

    public TbUser(int userId, String account, String password, String userName, String sex, String phone, String email, String regTime, int userState) {
        this.userId = userId;
        this.account = account;
        this.password = password;
        this.userName = userName;
        this.sex = sex;
        this.phone = phone;
        this.email = email;
        this.regTime = regTime;
        this.userState = userState;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRegTime() {
        return regTime;
    }

    public void setRegTime(String regTime) {
        this.regTime = regTime;
    }

    public int getUserState() {
        return userState;
    }

    public void setUserState(int userState) {
        this.userState = userState;
    }
}
