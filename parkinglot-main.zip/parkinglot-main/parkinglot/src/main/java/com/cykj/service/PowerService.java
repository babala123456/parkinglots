package com.cykj.service;

import com.cykj.bean.TbPower;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface PowerService {


    public int deletePower(@Param("roleId") String roleId);
    public int insertPower(@Param("roleId") String roleId, @Param("menuId") String menuId);

    /**
     * 删除所有的权限id等信息
     * @param roleId
     * @return
     */
    public int deleteAllPower(int roleId);

    /**
     * 康春杰
     * [权限配置功能] --数据添加权限
     * 2020年11月23日16:37:32
     * @param menuId
     * @param roleId
     * @return
     */
    public int addPower(int menuId, int roleId);

    /**
     * 康春杰
     * [权限配置功能]：添加前判断是否在数据库中
     * 2020年11月23日16:43:47
     * @param arr
     * @param roleId
     * @return
     */
    public String judgePower(String arr ,int roleId);
}
