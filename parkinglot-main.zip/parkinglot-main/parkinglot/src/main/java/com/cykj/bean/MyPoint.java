package com.cykj.bean;


import org.springframework.stereotype.Component;

@Component   //坐标位置对象
public class MyPoint {
    String pointX;
    String pointY;

    public MyPoint() {
    }

    public MyPoint(String pointX, String pointY) {
        this.pointX = pointX;
        this.pointY = pointY;
    }

    public String getPointX() {
        return pointX;
    }

    public void setPointX(String pointX) {
        this.pointX = pointX;
    }

    public String getPointY() {
        return pointY;
    }

    public void setPointY(String pointY) {
        this.pointY = pointY;
    }
}
