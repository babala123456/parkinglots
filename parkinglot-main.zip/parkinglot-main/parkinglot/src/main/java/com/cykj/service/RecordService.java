package com.cykj.service;

import com.cykj.bean.TbRecord;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

import java.util.List;

/**
 * @author Administrator
 */
public interface RecordService {

    /**
     * 将车牌的消费情况添加至该表
     * @param tbRecord
     * @return
     */
    public int addRecord(TbRecord tbRecord);

    /**
     * 数据查询与模糊查询
     * @param map
     * @param curPage
     * @param limit
     * @return
     */
    public List<TbRecord> findRecordPage(Map<String, Object> map, int curPage, int limit);
    public int findRecordNum(Map<String,Object> map);//分页查询

    public int[] getFeeCensus(List<Integer> idList, String startTime, String endTime);

    /**
     *根据日志id 更新 订单编号字段
     * @param outTradeNo
     * @param recordId
     * @return
     */
    public int updateOutTradeNo(String outTradeNo,int recordId);
}
