package com.cykj.service.serviceImpl;

import com.cykj.bean.TbPark;
import com.cykj.bean.TbRule;
import com.cykj.mapper.ParameterMapper;
import com.cykj.mapper.ParkMapper;
import com.cykj.mapper.RuleMapper;
import com.cykj.service.RuleService;
import com.cykj.util.Common;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;


@Service
public class RuleServiceImpl implements RuleService {

    @Resource
    private RuleMapper ruleMapper;

    @Resource
    private ParameterMapper parameterMapper;

    @Resource
    private ParkMapper parkMapper;


    /**
     * 查询当前使用中的的规则
     * @return
     */
    @Override
    public TbRule selUsingRule() {
        return ruleMapper.selUsingRule();
    }

    /**
     * 条件查询数据总数
     * @param condition
     * @return
     */
    @Override
    public int findRecords(Map<String, Object> condition) {
        return ruleMapper.findRecords(condition);
    }

    /**
     * 分页查询规则数据
     * @param condition
     * @param startIndex
     * @param endIndex
     * @return
     */
    @Override
    public List<TbRule> findRulesByPage(Map<String, Object> condition, Integer startIndex, Integer endIndex) {
        return ruleMapper.findRulesByPage(condition,startIndex,endIndex);
    }


    /**
     * 修改规则状态方法
     * @param rule
     * @return
     */
    @Override
    public int changeState(TbRule rule) {
        return ruleMapper.changeState(rule);
    }


    /**
     * 根据车牌号计费
     * @param carNum
     * @return
     */
    @Override
    public String consume(String carNum, int parkId) {
        String fee = "";

        //获取当前效用的规则
        TbRule rule =selUsingRule();
        TbPark park = null;

        System.out.println("车牌号:"+carNum);

        if(carNum != null && !carNum.trim().equals("")) {

            park = parkMapper.findParkByCarNum(carNum,parkId);

            System.out.println(carNum);

            if(rule != null){
                //规则起始日期
                LocalDateTime start = Common.getDateTime(rule.getStartDay());
                //规则终止日期
                LocalDateTime end = Common.getDateTime(rule.getEndDay());
                //当前时间
                LocalDateTime now = LocalDateTime.now();
                //车辆进场时间
                LocalDateTime enterTime = null;

                //如果当前时间位于规则有效期限内
                if(now.compareTo(start) > 0 && now.compareTo(end) < 0){
                    if(park != null && Common.notEmpty(park.getEnterTime())){
                        enterTime = Common.getDateTime(park.getEnterTime());

                        if(rule.getIsFree() == 0) {
                            Duration duration = Duration.between(enterTime, now);
                            long changeHours = duration.toMinutes() % 60 == 0 ? duration.toMinutes()
                                    / 60 : duration.toMinutes() / 60 + 1;

                            System.out.println("停车时间："+changeHours);

                            //超过第三等级
                            if(rule.getThirdLevel() > 0
                                    && changeHours >= rule.getThirdLevel()){
                                fee = String.valueOf(rule.getThirdMoney());
                                System.out.println("进三");
                            }
                            //第二等级--第三等级
                            else if(rule.getTwoLevel() > 0
                                    && rule.getTwoLevel() <= changeHours
                                    && rule.getThirdLevel() > 0
                                    && changeHours < rule.getThirdLevel()){
                                double change = rule.getBasicMoney() + (changeHours - rule.getTwoLevel())
                                        * rule.getTwoMoney();
                                fee = String.valueOf(change);

                                System.out.println("进二");
                            }
                            //第一等级--第二等级
                            else if(rule.getOneLevel() > 0
                                    && rule.getOneLevel() <= changeHours
                                    && rule.getTwoLevel() > 0
                                    && changeHours < rule.getTwoLevel()){
                                double change = rule.getBasicMoney() + (changeHours - rule.getOneLevel())
                                        * rule.getOneMoney();
                                fee = String.valueOf(change);

                                System.out.println("进一");
                            }
                            //免费--第一等级
                            else{
                                fee = String.valueOf(rule.getBasicMoney());
                                System.out.println("基础费用："+rule.getBasicMoney());
                            }
                        }
                    }
                }else{
                    fee = parameterMapper.findByType("基础费用");
                }
            }else{
                fee = parameterMapper.findByType("基础费用");
            }
        }


        System.out.println("费用："+fee);
        return fee;
    }


    /**
     * 修改规则信息方法
     * @param rule
     * @return
     */
    @Override
    public int setRule(TbRule rule) {
        return ruleMapper.setRule(rule);
    }


    /**
     * 根据规则名字，查询是否已存在相同名字规则
     * @param ruleName
     * @return
     */
    @Override
    public TbRule legal(String ruleName) {
        return ruleMapper.legal(ruleName);
    }


    /**
     * 新增规则方法
     * @param rule
     * @return
     */
    @Override
    public int newRule(TbRule rule) {
        return ruleMapper.newRule(rule);
    }
}
