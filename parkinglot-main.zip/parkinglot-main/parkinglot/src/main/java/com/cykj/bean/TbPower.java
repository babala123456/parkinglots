package com.cykj.bean;

public class TbPower {

  private int pid;
    private String menuId;
    private String roleId;


    public TbPower() {
  }

    public TbPower(int pid, String menuId, String roleId) {
        this.pid = pid;
        this.menuId = menuId;
        this.roleId = roleId;
    }

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }
}
