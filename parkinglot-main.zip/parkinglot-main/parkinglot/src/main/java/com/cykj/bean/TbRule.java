package com.cykj.bean;


public class TbRule {

  private long ruleId;
  private String ruleName;
  private int ruleState;
  private String startDay;
  private String endDay;
  private long isFree;
  private double baseTime;
  private double basicMoney;
  private double oneLevel;
  private double oneMoney;
  private double twoLevel;
  private double twoMoney;
  private double thirdLevel;
  private double thirdMoney;
  private String showState;
  private String showFree;


  public long getRuleId() {
    return ruleId;
  }

  public void setRuleId(long ruleId) {
    this.ruleId = ruleId;
  }


  public String getRuleName() {
    return ruleName;
  }

  public void setRuleName(String ruleName) {
    this.ruleName = ruleName;
  }


  public int getRuleState() {
    return ruleState;
  }

  public void setRuleState(int ruleState) {
    this.ruleState = ruleState;
  }


  public String getStartDay() {
    return startDay;
  }

  public void setStartDay(String startDay) {
    this.startDay = startDay;
  }


  public String getEndDay() {
    return endDay;
  }

  public void setEndDay(String endDay) {
    this.endDay = endDay;
  }


  public long getIsFree() {
    return isFree;
  }

  public void setIsFree(long isFree) {
    this.isFree = isFree;
  }


  public double getBaseTime() {
    return baseTime;
  }

  public void setBaseTime(double baseTime) {
    this.baseTime = baseTime;
  }


  public double getBasicMoney() {
    return basicMoney;
  }

  public void setBasicMoney(double basicMoney) {
    this.basicMoney = basicMoney;
  }


  public double getOneLevel() {
    return oneLevel;
  }

  public void setOneLevel(double oneLevel) {
    this.oneLevel = oneLevel;
  }


  public double getOneMoney() {
    return oneMoney;
  }

  public void setOneMoney(double oneMoney) {
    this.oneMoney = oneMoney;
  }


  public double getTwoLevel() {
    return twoLevel;
  }

  public void setTwoLevel(double twoLevel) {
    this.twoLevel = twoLevel;
  }


  public double getTwoMoney() {
    return twoMoney;
  }

  public void setTwoMoney(double twoMoney) {
    this.twoMoney = twoMoney;
  }


  public double getThirdLevel() {
    return thirdLevel;
  }

  public void setThirdLevel(double thirdLevel) {
    this.thirdLevel = thirdLevel;
  }


  public double getThirdMoney() {
    return thirdMoney;
  }

  public void setThirdMoney(double thirdMoney) {
    this.thirdMoney = thirdMoney;
  }


  public String getShowState() {
    return showState;
  }

  public void setShowState(String showState) {
    this.showState = showState;
  }

  public String getShowFree() {
    return showFree;
  }

  public void setShowFree(String showFee) {
    this.showFree = showFree;
  }
}
