package com.cykj.controller;


import com.alibaba.fastjson.JSON;
import com.cykj.bean.*;
import com.cykj.service.CarService;
import com.cykj.service.HandleService;
import com.cykj.bean.TableInfo;
import com.cykj.bean.TbCar;
import com.cykj.bean.TbHandle;
import com.cykj.bean.TbUser;
import com.cykj.service.CarService;
import com.cykj.service.UserService;
import com.cykj.util.Common;
import com.cykj.util.Log;
import com.cykj.util.MD5util;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
@Controller
public class UserController {
    @Resource
    private UserService userServiceImpl;
    @Resource
    private HandleService handleServiceImpl;
    @Resource
    private CarService carServiceImpl;



    @RequestMapping("/findCars")
    @Log(operationName = "查询用户名下的车辆",operationType = "")
    public @ResponseBody String findCars(HttpServletRequest request){
        String msg = "";
        TbUser tbUser = (TbUser) request.getSession().getAttribute("user");

        List<TbCar> list = carServiceImpl.findByUserId(tbUser.getUserId());

        System.out.println("用户名下的车数量:"+list.size());

        if(list.size() > 0){
            msg = JSON.toJSONString(list);
        }else{
            msg = "fail";
        }

        return msg;
    }

    

    @RequestMapping("/getProducts")
    @Log(operationName = "获取可办理的产品",operationType = "")
    public String getProducts(HttpServletRequest request){
        List<TbProduct> list = handleServiceImpl.getProducts();
        System.out.println("获取可办理的产品:"+list.size());
        request.setAttribute("products",list);

        return "user_investMoney";
    }


    @RequestMapping("/addHandle")
    @Log(operationName = "添加办理产品业务记录",operationType = "")
    public String addHandle(String orderNum,Integer carId,  HttpServletRequest request){

        //获取车辆已办理最新的业务
        TbHandle banedHandle = handleServiceImpl.findByCarId(carId);
        //获取当前时间
        LocalDateTime now = LocalDateTime.now();
        //获取新办理业务的到期时间
        String showEffect = (String) request.getSession().getAttribute("showEffect");
        Long effect = Long.parseLong(showEffect);
        LocalDateTime end = LocalDateTime.of(LocalDate.now().plusDays(effect), LocalTime.MAX);
        String finishTime = Common.getTimeString(end);
        //如果车辆尚未办理业务，新增记录
        if(banedHandle == null){
            String proId = (String) request.getSession().getAttribute("proId");

            String effectTime = Common.getTimeString(now);
            System.out.println("生效时间：" + effectTime + "  失效时间：" + finishTime);
            //构造新增记录对象
            TbHandle tbHandle = new TbHandle();
            tbHandle.setCarId(carId);
            tbHandle.setProductId(Integer.parseInt(proId));
            tbHandle.setEffectedTime(effectTime);
            tbHandle.setFinishTime(finishTime);
            tbHandle.setOrderNum(orderNum);
            //调用新增方法
            handleServiceImpl.addHandle(tbHandle);
        }else{  //如果已办理业务
            LocalDateTime banedEnd = Common.getDateTime(banedHandle.getFinishTime());

            //判断业务是否到期，如果未到期，修改业务到期的时间
            if(banedEnd.compareTo(now) > 0){
                //获取当前套餐的到期时间往后推迟新的期限
                LocalDate changeEnd = LocalDate.of(banedEnd.getYear(),banedEnd.getMonth(),
                        banedEnd.getDayOfMonth());
                LocalDateTime endTime = LocalDateTime.of(changeEnd.plusDays(effect), LocalTime.MAX);
                String setEnd = Common.getTimeString(endTime);
                //设置修改对象的值
                banedHandle.setFinishTime(setEnd);
                banedHandle.setOrderNum(orderNum);
                //调用修改方法
                handleServiceImpl.setFinishTime(banedHandle);
            }else{  //如果已办理业务到期，新增记录
                String proId = (String) request.getSession().getAttribute("proId");

                String effectTime = Common.getTimeString(now);
                System.out.println("生效时间：" + effectTime + "  失效时间：" + finishTime);
                //构造新增记录对象
                TbHandle tbHandle = new TbHandle();
                tbHandle.setCarId(carId);
                tbHandle.setProductId(Integer.parseInt(proId));
                tbHandle.setEffectedTime(effectTime);
                tbHandle.setFinishTime(finishTime);
                tbHandle.setOrderNum(orderNum);
                //调用新增方法
                handleServiceImpl.addHandle(tbHandle);
            }
        }
        TbUser user = (TbUser) request.getSession().getAttribute("user");
        if (null!=user){
            List<TbCar> cars = carServiceImpl.findCarNum(user.getUserId());
            request.setAttribute("cars",cars);
        }

        return "user_main";
    }

    @RequestMapping("/userLogin")
    @ResponseBody
    @Log(operationName = "用户登录",operationType = "")
    public String userLogin(String account , String password, HttpServletRequest request){
        TbUser tbUser = userServiceImpl.userLogin(account, MD5util.code(password));
        if (null!=tbUser){
            List<TbCar> tbCars = carServiceImpl.findCarNum(tbUser.getUserId());
            int stopNumber = userServiceImpl.stopNumber(tbUser.getUserId());
            request.getSession().setAttribute("stopNumber",stopNumber);
            request.getSession().setAttribute("carNum",tbCars);
            request.getSession().setAttribute("user",tbUser);
            return "success";
        }else{
            System.out.println("tbUser为null");
        }
        return "lose";
    }

    /**
     * 重新刷新页面，页面返回数据
      * @return
     */
    @RequestMapping("/findUserCarInfo")
    @Log(operationName = "用户登录返回车牌信息至页面",operationType = "")
    public String getUserLoginInfo(HttpServletRequest request){
        TbUser user = (TbUser) request.getSession().getAttribute("user");
        if (null!=user){
            List<TbCar> cars = carServiceImpl.findCarNum(user.getUserId());
            request.setAttribute("cars",cars);
        }
        return "user_main";
    }



    @RequestMapping("/userOrder")
    @Log(operationName = "用户产品订单查询",operationType = "")
    public  @ResponseBody String userOrder(String carNum,int page,int limit ,HttpServletRequest request, String effectedTime, String finishTime, String proName, String pValue){
        System.err.println("carNum:"+carNum);
        TbUser user = (TbUser) request.getSession().getAttribute("user");
        List<TbCar> cars = carServiceImpl.findCarNum(user.getUserId());
        Map<String,Object> selectmap = new HashMap();
        selectmap.put("effectedTime",effectedTime);
        selectmap.put("finishTime",finishTime);
        selectmap.put("proName",proName);
        selectmap.put("carNum",carNum);
        selectmap.put("pValue",pValue);
        selectmap.put("page",(page-1)*limit);
        selectmap.put("limit",limit);
        List<TbHandle> orderList = userServiceImpl.findUserOrder(selectmap);
        int userOrderRecord = userServiceImpl.findUserOrderRecord(selectmap);
        TableInfo tableInfo = new TableInfo();
        tableInfo.setCode(0);
        tableInfo.setCount(userOrderRecord);
        tableInfo.setData(orderList);
        tableInfo.setMsg("用户订单");
        String json = new Gson().toJson(tableInfo);
        return json;
    }

    @RequestMapping("/order")
    @Log(operationName = "前往order页面",operationType = "")
    public String gotoOrderPage(String carNum,HttpServletRequest request){
        request.setAttribute("carNum",carNum);
        return "user_order";
    }


    @RequestMapping("/resetPassword")
    @Log(operationName = "修改用户密码",operationType = "")
    @ResponseBody
    public String resetPassword(String pwd,String newPwd,String userId ,HttpServletRequest request){
        System.out.println(pwd+"|"+newPwd+"|"+userId);
        TbUser userInfo = userServiceImpl.findUserInfo(Integer.parseInt(userId));
        if (MD5util.code(pwd).equals(userInfo.getPassword())){
            String result = userServiceImpl.resetPassword(MD5util.code(newPwd), Integer.parseInt(userId));
            return result;
        }else{
            System.out.println("pwd:"+MD5util.code(pwd));
            System.out.println("newPwd:"+userInfo.getPassword());
            return "different";
        }
    }

    @RequestMapping("/outLogin")
    @Log(operationName = "退出登录",operationType = "")
    public String outLogin(HttpSession session){
        //session移除 user
        session.removeAttribute("user");
        return "user_main";
    }

    @RequestMapping("/bindingCarNum")
    @Log(operationName = "用户车牌绑定",operationType = "")
    @ResponseBody
    public String bindingCarNum(String carNum,int userId){
        String result = carServiceImpl.bingDing(carNum, userId);
        System.out.println("result:"+result);
        return result;
    }




    @RequestMapping("/userInfo")
    @Log(operationName = "用户登录后信息返回",operationType = "")
    public String returnUserInfo(TbUser tbUser,HttpServletRequest request){
        System.out.println("taUser:"+tbUser);
        return null;
    }
    @RequestMapping("/userMain")
    @Log(operationName = "用户主页面跳转",operationType = "")
    public String gotoUserMain(){
        return "user_main";
    }

    @RequestMapping("/secCenter")
    @Log(operationName = "用户安全页面跳转",operationType = "")
    public String secCenterController(){
        return "user_securityCenter";
    }

    @RequestMapping("/investMoney")
    @Log(operationName = "页面跳转",operationType = "")
    public String investMoney(){
        return "user_investMoney";
    }

    @RequestMapping("/payController")
    @Log(operationName = "用户支付页面跳转",operationType = "")
    public String payController(){
        return "user_pay";
    }

    @RequestMapping("/price")
    @Log(operationName = "支付",operationType = "")
    public void price (String money, HttpServletRequest request)
    {
        request.getSession().setAttribute("money",money);
    }


    @RequestMapping("/reg")
    @Log(operationName = "前往注册页面",operationType = "页面跳转")
    public String gotoReg () {
        return "front_register";
    }


    @RequestMapping("/img")
    @Log(operationName = "测试跳转页面",operationType = "页面跳转")
    public String test () {
        return "test";
    }

    @RequestMapping("/userError")
    @Log(operationName = "错误页面跳转",operationType = "页面跳转")
    public String error () {
        return "error";
    }
}
