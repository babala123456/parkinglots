package com.cykj.service.serviceImpl;

import com.cykj.bean.TbParameter;
import com.cykj.mapper.ParameterMapper;
import com.cykj.service.ParameterService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class ParameterServiceImpl implements ParameterService {

    @Resource
    private ParameterMapper parameterMapper;

    @Override
    public List<TbParameter> findParameterOnPage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit", limit);
        map.put("offset", (curPage - 1) * limit);
        return parameterMapper.findParameterOnPage(map);
    }

    @Override
    public int findParameterNum(Map<String, Object> map) {
        return parameterMapper.findParameterNum(map);
    }


    @Override
    public List<TbParameter> selectParameter() {
        return parameterMapper.selectParameter();
    }

    @Override
    public int deleteParameter(int pId) {
        return parameterMapper.deleteParameter(pId);
    }

    @Override
    public int updateParameter(int pId, String pType, String pValue) {
        return parameterMapper.updateParameter(pId, pType, pValue);
    }

    @Override
    public int insertParameter(String pType, String pValue) {
        return parameterMapper.insertParameter(pType, pValue);
    }


    /**
     * 根据参数类型查询参数值
     *
     * @param pType
     * @return
     */
    @Override
    public String findByType(String pType) {
        String params = parameterMapper.findByType(pType);
        return params;
    }

    /**
     * 根据参数类型查询同类型的所有参数信息
     * @param pType
     * @return
     */
    @Override
    public List<TbParameter> findTypeList(String pType) {
        return parameterMapper.findTypeList(pType);
    }
}
