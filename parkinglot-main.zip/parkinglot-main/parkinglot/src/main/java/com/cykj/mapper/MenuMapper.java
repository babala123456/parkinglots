package com.cykj.mapper;

import com.cykj.bean.TbMenu;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository(value = "menuMapper")
@Mapper
public interface MenuMapper {
    public List<TbMenu> findMenuPage(Map<String, Object> map);//查询数据与模糊查询
    public int findMenuNum(Map<String, Object> map);//分页查询

    public List<TbMenu> findMenusByPid(@Param("roleId") String roleId, @Param("relevanceId") int relevanceId);//动态菜单
    public List<TbMenu> laterMenu(@Param("roleid") String roleId);//未拥有的菜单
    public List<TbMenu> Menu();//总菜单查询
    public int deleteMenu(@Param("menuId") int menuId);//删除菜单

    /**
     * 更改菜单
     * @param menuId
     * @param menuName
     * @param menuPath
     * @param relevanceId
     * @return
     */
    public int updateMenu(@Param("menuId") int menuId, @Param("menuName") String menuName, @Param("menuPath") String menuPath, @Param("relevanceId") String relevanceId);

    /**
     * 添加菜单
     * @param menuName
     * @param menuPath
     * @param relevanceId
     * @return
     */
    public int insertMenu(@Param("menuName") String menuName, @Param("menuPath") String menuPath, @Param("relevanceId") String relevanceId);

    /**
     * 康春杰
     * [权限配置功能] -- 根据父级ID 查询所有 父级id菜单
     * 2020年11月23日14:39:14
     * @param relevanceId
     * @return
     */
    public List<TbMenu> findParentMenu(@Param("relevanceId")int relevanceId);

    /**
     * 康春杰
     * [权限配置功能] -- 根据权限 返回已分配菜单列表
     * 2020年11月23日12:12:05
     * @param roleId
     * @param relevanceId
     * @return
     */
    public List<TbMenu>findMenuByPid(@Param("roleId") int roleId,@Param("relevanceId")int relevanceId);

    /**
     * 康春杰
     * [权限配置功能] -- 根据权限 返回 未分配的 菜单列表
     * 2020年11月23日12:41:05
     * @param roleId
     * @param relevanceId
     * @return
     */
    public List<TbMenu>findNoneMenu(@Param("roleId") int roleId,@Param("relevanceId")int relevanceId);
}
