package com.cykj.controller;


import com.cykj.bean.TbProRecord;
import com.cykj.service.ProRecordService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

@Controller
@RequestMapping("/proRecord")
public class ProRecordController {

    @Resource
    private ProRecordService proRecordServiceImpl;


    /**
     * 添加产品办理记录方法
     * @param proRecord
     * @return
     */
    public @ResponseBody String addRecord(@RequestBody TbProRecord proRecord){
        String msg = "";

        int res = proRecordServiceImpl.addRecord(proRecord);

        if(res > 0){
            msg = "success";
        }else{
            msg = "fail";
        }

        return msg;
    }



}
