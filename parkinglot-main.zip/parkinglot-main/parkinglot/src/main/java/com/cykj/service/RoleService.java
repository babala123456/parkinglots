package com.cykj.service;

import com.cykj.bean.TbRole;

import java.util.List;
import java.util.Map;

public interface RoleService {
    public List<TbRole> roleSelect();//角色查询
    /**
     * 数据查询与模糊查询
     * @param map
     * @param curPage
     * @param limit
     * @return
     */
    public List<TbRole> findRolePage(Map<String, Object> map, int curPage, int limit);
    public int findRoleNum(Map<String,Object> map);//分页查询
    public int updateRole(int roleId,String userRole);//更改角色
    public int insertRole(String userRole);//添加角色
    /**
     * 康春杰
     * [权限管理功能]：角色选择
     * 2020年11月23日10:10:28
     * @return
     */
    public List<TbRole> findRole();


}
