package com.cykj.util;

import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


@Component
public class Common {

    /**
     * 传入数字和单位，判断时长
     * @param day
     * @param danWei
     * @return
     */
    public static int getDays(int day, String danWei){
        int res = 0;

        if(danWei.equals("天")){
            res = day;
        }else if(danWei.equals("月")){
            res = day * 30;
        }else if(danWei.equals("年")){
            res = day * 365;
        }

        return res;
    }


    /**
     * 字符串非空判定方法
     * @param string
     * @return
     */
    public static boolean notEmpty(String string)
    {
        if(string != null && string.length() > 0 && !string.trim().equals(""))
        {
            return true;
        }
        else
            return false;
    }


    /**
     * 根据参数表id，返回对应的参数字符串
     * @param value
     * @return
     */
    public static String getString(int value)
    {
        String res = "";

        if (value == 6)
            res = "启用";
        else if (value == 7)
            res = "禁用";
        else if (value == 8)
            res = "已删除";
        else if (value == 9)
            res = "未停车";
        else if (value == 10)
            res = "已停车";
        else if (value == 12)
            res = "启用";
        else if (value == 13)
            res = "未启用";
        else if (value == 14)
            res = "已删除";

        return res;
    }


    /**
     * 根据参数字符串返回参数值
     * @param type
     * @return
     */
    public static int getValue(String type){
        int res = 0;

        {
            if (type.equals("启用"))
                res = 6;
            else if (type.equals("禁用"))
                res = 7;
            else if (type.equals("已删除"))
                res = 8;
            else if (type.equals("未停车"))
                res = 9;
            else if (type.equals("已停车"))
                res = 10;
            else if (type.equals("启用"))
                res = 12;
            else if (type.equals("未启用"))
                res = 13;
            else if (type.equals("已删除"))
                res = 14;
        }

        return res;
    }



    /**
     * 返回时间对象的字符串格式化形式
     * @param date
     * @return
     */
    public static String getTimeString(LocalDateTime date)
    {
        String time = "";
        if(date != null){
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            time = dtf.format(date);
        }
        return time;
    }


    /**
     * 根据格式化后的日期字符串，返回对应的localDateTime对象
     * @param time
     * @return
     */
    public static LocalDateTime getDateTime(String time){
        LocalDateTime dateTime = null;
        int year = 0, month = 0, day = 0, hour = 0, minutes = 0, seconds = 0;

        if(notEmpty(time)) {
            String[] base = time.split(" ");

            if(notEmpty(base[0])){
                String[] fir = base[0].split("-");

                if(notEmpty(fir[0])){
                    year = Integer.parseInt(fir[0]);
                }

                if(notEmpty(fir[1])){
                    month = Integer.parseInt(fir[1]);
                }

                if(notEmpty(fir[2])){
                    day = Integer.parseInt(fir[2]);
                }

            }

            if(notEmpty(base[1])) {
                String[] sec = base[1].split(":");

                if(notEmpty(sec[0])){
                    hour = Integer.parseInt(sec[0]);
                }

                if(notEmpty(sec[1])){
                    minutes = Integer.parseInt(sec[1]);
                }


                if(notEmpty(sec[2])){
                    seconds = Integer.parseInt(sec[2]);
                }
            }
            dateTime = LocalDateTime.of(year,month,day,hour,minutes,seconds);
        }

        return dateTime;
    }


    /**
     * 根据localDateTime格式的字符串，返回切割后对应的整型数组
     * @param time
     * @return
     */
    public static int[] getIntTime(String time){
        String year = "",month = "",day = "",hour = "",minutes = "",seconds = "";

        String head = time.split(" ")[0];
        String wei = time.split(" ")[1];

        if(notEmpty(head)){
            year = head.split("-")[0];
            month = head.split("-")[1];
            day = head.split("-")[2];
        }

        if(notEmpty(wei)){
            hour = wei.split(":")[0];
            minutes = wei.split(":")[1];
            seconds = wei.split(":")[2];
        }

        int[] sets = new int[6];

        sets[0] = Integer.parseInt(year);
        sets[1] = Integer.parseInt(month);
        sets[2] = Integer.parseInt(day);
        sets[3] = Integer.parseInt(hour);
        sets[4] = Integer.parseInt(minutes);
        sets[5] = Integer.parseInt(seconds);

        return sets;
    }
}
