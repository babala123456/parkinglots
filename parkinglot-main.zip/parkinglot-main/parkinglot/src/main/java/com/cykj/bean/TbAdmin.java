package com.cykj.bean;

/**
 * @author Administrator
 */
public class TbAdmin {

  private int aId;
  private String account;
  private String apwd;
  private int roleIds;
  private String aName;
  private String regTime;
  private TbRole tbRole;

    public TbAdmin() {
    }

    @Override
    public String toString() {
        return "TbAdmin{" +
                "aId=" + aId +
                ", account='" + account + '\'' +
                ", apwd='" + apwd + '\'' +
                ", roleIds=" + roleIds +
                ", aName='" + aName + '\'' +
                ", regTime='" + regTime + '\'' +
                ", tbRole=" + tbRole +
                '}';
    }

    public TbAdmin(int aId, String account, String apwd, int roleIds, String aName, String regTime, TbRole tbRole) {
        this.aId = aId;
        this.account = account;
        this.apwd = apwd;
        this.roleIds = roleIds;
        this.aName = aName;
        this.regTime = regTime;
        this.tbRole = tbRole;
    }

    public int getaId() {
        return aId;
    }

    public void setaId(int aId) {
        this.aId = aId;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getApwd() {
        return apwd;
    }

    public void setApwd(String apwd) {
        this.apwd = apwd;
    }

    public int getRoleIds() {
        return roleIds;
    }

    public void setRoleIds(int roleIds) {
        this.roleIds = roleIds;
    }

    public String getaName() {
        return aName;
    }

    public void setaName(String aName) {
        this.aName = aName;
    }

    public String getRegTime() {
        return regTime;
    }

    public void setRegTime(String regTime) {
        this.regTime = regTime;
    }

    public TbRole getTbRole() {
        return tbRole;
    }

    public void setTbRole(TbRole tbRole) {
        this.tbRole = tbRole;
    }
}
