package com.cykj.service;

import com.cykj.bean.TbAdmin;

import java.util.List;
import java.util.Map;

public interface AdminService {
    public List<TbAdmin> adminuserSelect();
    public int delAdminById(int aid);
    public TbAdmin login(String username, String userpwd);

    public int insertAdminUser(TbAdmin tbAdmin);

    List<TbAdmin> findAdminPage(Map<String, Object> map, int page, int limit);

    int findAdminNum(Map<String, Object> map);

    /**
     * 修改
     * @param aId
     * @param aName
     * @return
     */
    public int updateAdmin(int aId, String aName);

//    boolean changeUserState(String userId, String userState);
}
