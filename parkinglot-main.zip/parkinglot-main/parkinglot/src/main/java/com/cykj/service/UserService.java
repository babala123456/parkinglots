package com.cykj.service;

import com.cykj.bean.TbHandle;
import com.cykj.bean.TbUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

public interface UserService {

    public TbUser login(String username, String userpwd);


    /**
     * 根据添加查找用户 订单记录
     * @param map
     * @return
     */
    public List<TbHandle> findUserOrder(Map map);

    /**
     * 康春杰
     * [前台用户登录功能]
     * 2020年11月24日21:12:28
     * @param account
     * @param password
     * @return
     */
    public TbUser userLogin(String account,String password);



    /**
     * 查询停车次数
     * @param userId
     * @return
     */
    public int stopNumber(int userId);

    /**
     * [车主端] 自主修改密码
     * @param password
     * @param userId
     * @return
     */
    public String resetPassword(String password,int userId);

    /**
     * [车主端] 根据ID返回用户信息
     * @param userId
     * @return
     */
    public TbUser findUserInfo(@Param("userId")int userId);

    /**
     * 根据条件查询返回的记录数
     * @param map
     * @return
     */
    public int findUserOrderRecord(Map map);
}
