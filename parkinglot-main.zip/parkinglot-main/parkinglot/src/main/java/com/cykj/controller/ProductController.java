package com.cykj.controller;

import com.cykj.bean.TableInfo;
import com.cykj.bean.TbProduct;
import com.cykj.service.ProductService;
import com.cykj.util.Common;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class ProductController {
    @Resource
    private ProductService productServiceImpl;

    @RequestMapping("/productLogin")
    @Log(operationName = "返回月缴产品页面",operationType = "返回月缴产品页面")
    public String productLogin(){
        return "back_product";
    }

    //搜索产品
    @RequestMapping("/searchProduct")
    @Log(operationName = "返回月缴产品页面",operationType = "返回月缴产品页面")
    @ResponseBody
    public void searchProduct(HttpServletResponse response, HttpServletRequest request, @Param("proName") String proName) throws ServletException, IOException {

        System.out.println(proName);
        Map<String, Object> map = new HashMap<>();
        if(Common.notEmpty(proName)){
            request.setAttribute("proName",proName);
            map.put("proName", "%" + proName + "%");
        }
        String page = request.getParameter("page");
        String limit = request.getParameter("limit");
        int cur = Integer.parseInt(page);
        int sizes = Integer.parseInt(limit);
        List<TbProduct> productList = productServiceImpl.findProduct(map,(cur-1)*sizes,sizes);

        int records = productServiceImpl.findRecords(map);

        TableInfo tableInfo = new TableInfo();
        tableInfo.setCode(0);
        tableInfo.setCount(records);
        tableInfo.setMsg("用户列表数据信息");
        tableInfo.setData(productList);

        String remsg = new Gson().toJson(tableInfo);
        response.setContentType("test/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.write(remsg);
        out.flush();
        out.close();
    }

    //删除月缴产品数据
    @RequestMapping("/delProduct")
    @Log(operationName = "返回月缴产品页面",operationType = "返回月缴产品页面")
    @ResponseBody
    public String delProduct(int proId,int proState){
        String result = productServiceImpl.delProduct(proId,proState);
        return result;
    }

    //恢复删除
    @RequestMapping("/recoverProduct")
    @Log(operationName = "返回月缴产品页面",operationType = "返回月缴产品页面")
    @ResponseBody
    public String recoverProduct( int proId,int proState){
        String result = productServiceImpl.recoverProduct(proId,proState);
        return result;
    }

    //修改月缴产品数据
    @RequestMapping("/updateProduct")
    @Log(operationName = "返回月缴产品页面",operationType = "返回月缴产品页面")
    @ResponseBody
    public String updateProduct(String proName , int proDeadline , String proUnit , int proPrice, int proId){
        System.out.println(proDeadline);
        System.out.println(proName);
        String result = productServiceImpl.updateProduct(proName,proDeadline,proUnit,proPrice,proId);
        System.out.println(result);
        return result;
    }


    //月缴产品的禁用启用
    @RequestMapping("/changeStateProduct")
    @Log(operationName = "返回月缴产品页面",operationType = "返回月缴产品页面")
    @ResponseBody
    public String changeProState(int proId, int proState){
        String result = productServiceImpl.changeProState(proId,proState);
        return result;

    }

    //新增一条月缴产品信息
    @RequestMapping("/addProduct")
    @Log(operationName = "返回月缴产品页面",operationType = "返回月缴产品页面")
    @ResponseBody
    public String addProduct(String proName , int proDeadline , String proUnit , int proPrice){
        String result = productServiceImpl.addProduct(proName,proDeadline,proUnit,proPrice);
        return result;
    }
}
