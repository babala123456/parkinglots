package com.cykj.service.serviceImpl;

import com.cykj.bean.TbAdmin;
import com.cykj.bean.TbWhite;
import com.cykj.mapper.AdminMapper;
import com.cykj.service.AdminService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class AdminServiceImpl implements AdminService {

    @Resource
    private AdminMapper adminMapper;

    @Override//后台用户查询
    public List<TbAdmin> adminuserSelect() {

        return adminMapper.adminUser();
    }

    @Override//后台用户删除
    public int delAdminById(int aid) {

        return adminMapper.delAdminById(aid);
    }

    @Override
    public TbAdmin login(String username, String userpwd) {
        return adminMapper.login(username, userpwd);
    }

    @Override
    public int insertAdminUser(TbAdmin tbAdmin) {
        return adminMapper.insertAdminUser(tbAdmin);
    }


    @Override
    public List<TbAdmin> findAdminPage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit",limit);
        map.put("offset",(curPage-1)*limit);
        List<TbAdmin> findAdminPage = adminMapper.findAdminPage(map);
        return findAdminPage;
    }

    @Override
    public int findAdminNum(Map<String, Object> map) {
        int all = adminMapper.findAdminNum(map);
        return all;
    }

    /**
     * 修改
     * @param aId
     * @param aName
     * @return
     */
    @Override
    public int updateAdmin(int aId, String aName) {
        return adminMapper.updateAdminUser(aId,aName);
    }


//    @Override
//    public boolean changeUserState(String userId, String userState) {
//        return adminMapper.changeState(Integer.parseInt(userId),Integer.parseInt(userState));
//    }
}
