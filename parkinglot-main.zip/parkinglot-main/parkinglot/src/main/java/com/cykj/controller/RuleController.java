package com.cykj.controller;


import com.cykj.bean.TableInfo;
import com.cykj.bean.TbPark;
import com.cykj.bean.TbRule;
import com.cykj.service.ParkService;
import com.cykj.service.RuleService;
import com.cykj.service.serviceImpl.ParameterServiceImpl;
import com.cykj.util.Common;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/rule")
public class RuleController {

    @Resource
    private RuleService ruleServiceImpl;
    @Resource
    private ParameterServiceImpl parameterServiceImpl;
    @Resource
    private ParkService parkServiceImpl;


    /**
     * 跳转规则配置页面方法
     * @return
     */
    @RequestMapping("/toRuleMg")
    @Log(operationName = "访问规则配置页面",operationType = "访问规则配置页面")
    public String toPlaceMg()
    {
        return "back_ruleMg";
    }


    /**
     * 根据车牌号，结算应缴费用
     * @param carNum
     * @return
     */
    @RequestMapping("/consume")
    @Log(operationName = "计算费用方法",operationType = "计算费用方法")
    public @ResponseBody String consume(String carNum,int parkId){
        String fee = "";

        TbRule rule = ruleServiceImpl.selUsingRule();
        TbPark park = null;

        if(Common.notEmpty(carNum)) {
            park = parkServiceImpl.findParkByCarNum(carNum,parkId);
        }

        if(rule != null){
            //规则起始日期
            LocalDateTime start = Common.getDateTime(rule.getStartDay());
            //规则终止日期
            LocalDateTime end = Common.getDateTime(rule.getEndDay());
            //当前时间
            LocalDateTime now = LocalDateTime.now();
            //车辆进场时间
            LocalDateTime enterTime = null;

            //如果当前时间位于规则有效期限内
            if(now.compareTo(start) > 0 && now.compareTo(end) < 0){
                if(park == null){
                    fee = "wrong carNum";
                }else if(park != null && Common.notEmpty(park.getEnterTime())){
                    enterTime = Common.getDateTime(park.getEnterTime());

                    if(rule.getIsFree() < 0) {
                        Duration duration = Duration.between(enterTime, now);
                        String stay = String.valueOf(duration.toHours());
                        int stayTime = Integer.parseInt(stay);

                        //超过第三等级
                        if(stayTime >= rule.getThirdLevel()){
                            fee = String.valueOf(rule.getThirdMoney());
                        }
                        //第二等级--第三等级
                        else if(rule.getTwoLevel() <= stayTime && stayTime < rule.getThirdLevel()){
                            double change = rule.getBasicMoney() + (stayTime - rule.getTwoLevel())
                                    * rule.getTwoMoney();
                            fee = String.valueOf(change);
                        }
                        //第一等级--第二等级
                        else if(rule.getOneLevel() <= stayTime && stayTime < rule.getTwoLevel()){
                            double change = rule.getBasicMoney() + (stayTime - rule.getOneLevel())
                                    * rule.getOneMoney();
                            fee = String.valueOf(change);
                        }
                        //免费--第一等级
                        else{
                            fee = String.valueOf(rule.getBasicMoney());
                        }
                    }
                }
            }else{
                fee = parameterServiceImpl.findByType("基础费用");
            }
        }else{
            fee = parameterServiceImpl.findByType("基础费用");
        }

        return fee;
    }


    /**
     * 分页搜素规则信息
     * @param ruleName
     * @param ruleState
     * @param sOneTime
     * @param sTwoTime
     * @param eOneTime
     * @param eTwoTime
     * @param request
     * @return
     */
    @RequestMapping("/findRulesByPage")
    @Log(operationName = "分页搜素规则信息方法",operationType = "分页搜素规则信息方法")
    public @ResponseBody String findRulesByPage(String ruleName, String ruleState,
            String sOneTime, String sTwoTime, String eOneTime, String eTwoTime,
            HttpServletRequest request){
        Map<String, Object> condition = new HashMap<>();

        //搜索条件
        {
            //规则名字
            if (Common.notEmpty(ruleName)) {
                condition.put("ruleName", "%" + ruleName + "%");
            }

            //规则状态
            if (Common.notEmpty(ruleState)) {
                condition.put("ruleState", ruleState);
            }

            //起效起始时间
            if (Common.notEmpty(sOneTime)) {
                condition.put("sOneTime", sOneTime + " 00:00:00");
            }

            //起效终止时间
            if (Common.notEmpty(sTwoTime)) {
                condition.put("sTwoTime", sTwoTime + "24:59:59");
            }

            //到期起始时间
            if (Common.notEmpty(eOneTime)) {
                condition.put("eOneTime", eOneTime + " 00:00:00");
            }

            //到期终止时间
            if (Common.notEmpty(eTwoTime)) {
                condition.put("eTwoTime", eTwoTime + "24:59:59");
            }
        }

        TableInfo tableInfo = new TableInfo();

        int records = ruleServiceImpl.findRecords(condition);

        String curPage = request.getParameter("page");
        String pageSize = request.getParameter("limit");
        int cur = Integer.parseInt(curPage);
        int sizes = Integer.parseInt(pageSize);

        List<TbRule> list = ruleServiceImpl.findRulesByPage(condition,
                (cur - 1) * sizes,cur * sizes);

        //显示状态设置
        if(list != null && list.size() > 0){
            for (TbRule rule : list) {
                //获取规则的启用状态
                rule.setShowState(Common.getString(rule.getRuleState()));

                if(rule.getIsFree() == 0)
                {
                    rule.setShowFree("否");
                }else if(rule.getIsFree() == 1){
                    rule.setShowFree("是");
                }
            }
        }

        tableInfo.setCode(0);
        tableInfo.setMsg("规则列表数据信息");
        tableInfo.setCount(records);
        tableInfo.setData(list);

        String json = new Gson().toJson(tableInfo);
        return json;
    }


    /**
     * 修改规则状态方法
     * @param rule
     * @return
     */
    @RequestMapping("/changeState")
    @Log(operationName = "修改规则状态方法",operationType = "修改规则状态方法")
    public @ResponseBody String changeState(@RequestBody TbRule rule){
        int res = ruleServiceImpl.changeState(rule);
        String msg = "";

        if(res > 0) {
            msg = "success";
        } else {
            msg = "fail";
        }

        return msg;
    }


    /**
     * 修改规则信息方法
     * @param rule
     * @return
     */
    @RequestMapping("/setRule")
    @Log(operationName = "修改规则信息方法",operationType = "修改规则信息方法")
    public @ResponseBody String setRule(@RequestBody TbRule rule){
        String res = "";

        int flag = ruleServiceImpl.setRule(rule);

        if(flag > 0)
            res = "success";
        else
            res = "fail";

        return res;
    }


    /**
     * 新增规则方法
     * @param rule
     * @return
     */
    @RequestMapping("/newRule")
    @Log(operationName = "修改规则信息方法",operationType = "修改规则信息方法")
    public @ResponseBody String newRule(@RequestBody TbRule rule){
        String msg = "";

        TbRule tbRule = ruleServiceImpl.legal(rule.getRuleName());

        if(tbRule != null){
            msg = "duplicated";
        }else{
            int res = ruleServiceImpl.newRule(rule);

            if(res > 0)
                msg = "success";
            else
                msg = "fail";
        }



        return msg;
    }
}
