package com.cykj.service.serviceImpl;

import com.cykj.bean.TbHandle;
import com.cykj.bean.TbProduct;
import com.cykj.mapper.HandleMapper;
import com.cykj.mapper.ProductMapper;
import com.cykj.service.HandleService;
import com.cykj.util.Common;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
@Service
public class HandleServiceImpl implements HandleService {

    @Resource
    private HandleMapper handleMapper;
    @Resource
    private ProductMapper productMapper;



    /**
     * 获取可办理的业务信息展示在页面上
     * @return
     */
    @Override
    public List<TbProduct> getProducts() {
        List<TbProduct> list = productMapper.getProducts();

        for(TbProduct product : list){
            product.setShowEffect(Common.getDays(product.getProDeadline(),
                    product.getProUnit()));

            if(product.getShowEffect() > 0){
                double yuan = product.getProPrice() * 1.0 / product.getShowEffect();
                DecimalFormat df = new DecimalFormat("#.00");
                product.setShowYuan(df.format(yuan));
            }
        }

        return list;
    }

    /**
     * 根据车辆id查询车辆最新办理的业务
     * @param carId
     * @return
     */
    @Override
    public TbHandle findByCarId(int carId) {
        return handleMapper.findByCarId(carId);
    }

    /**
     * 办理业务时续费业务的方法
     * @param tbHandle
     * @return
     */
    @Override
    public int setFinishTime(TbHandle tbHandle) {
        return handleMapper.setFinishTime(tbHandle);
    }

    /**
     * 新增业务办理记录方法
     * @param tbHandle
     * @return
     */
    @Override
    public int addHandle(TbHandle tbHandle) {
        return handleMapper.addHandle(tbHandle);
    }

    @Override
    public List<TbHandle> findHandleByCarId(int carId, int handleState) {
        List<TbHandle> handleList = handleMapper.findHandleByCarId(carId,handleState);

        return handleList;
    }
    @Override
    public List<TbHandle> findHandlePage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit",limit);
        map.put("offset",(curPage-1)*limit);
        return handleMapper.findHandlePage(map);
    }

    @Override
    public int findHandleNum(Map<String, Object> map) {
        return handleMapper.findHandleNum(map);
    }
}
