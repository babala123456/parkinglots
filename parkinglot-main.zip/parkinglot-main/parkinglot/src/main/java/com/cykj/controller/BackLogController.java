package com.cykj.controller;

import com.cykj.bean.Pages;
import com.cykj.bean.TableInfo;
import com.cykj.bean.TbLog;
import com.cykj.service.LogService;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class BackLogController {

    @Resource
    private LogService logServiceImpl;


    @RequestMapping("/logPage")
    @Log(operationName = "登录",operationType = "登录")
    public String backLogPage(){
        return "back_log";
    }


     @RequestMapping("/findLog")
     @Log(operationName = "登录",operationType = "登录")
    public @ResponseBody String findLog(Pages pages){

         Map<String,Object> map = new HashMap<>();

         if (pages.getbUserName() != null){
             map.put("aName",pages.getbUserName());
         } else {
             map.put("aName","");
         }
         if (pages.getEndTime() != null&&pages.getEndTime().length() !=0){
             map.put("endTime",pages.getEndTime());
         }
         if (pages.getBeginTime() != null&&pages.getBeginTime().length() !=0){
             map.put("begin",pages.getBeginTime());
         }
         List<TbLog> list = logServiceImpl.findLogOnPage(map,pages.getPage(),pages.getLimit());
         int all = logServiceImpl.findLogNum(map);
         TableInfo tableInfo = new TableInfo(0,"用户数据信息",all,list);

        return new Gson().toJson(tableInfo);
     }


}
