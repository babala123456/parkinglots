package com.cykj.controller;

import com.cykj.bean.*;
import com.cykj.service.*;
import com.cykj.util.Log;
import com.cykj.util.MD5util;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
@Controller
public class AdminController {
    @Resource
    private UserService userServiceImpl;

    @Resource
    private AdminService adminServiceImpl;

    @Resource
    private BackUserService backUserServiceImpl;

    @Resource
    private LogService LogServiceImpl;

    @Resource
    private RoleService roleService;

    /**
     * 后台用户管理页面
     *
     * @return
     */
    @RequestMapping("/admin")
    @Log(operationName = "后台用户管理页面", operationType = "后台用户管理页面")
    public String adminHome(HttpServletRequest request) {
        List<TbRole> tbRolesList = roleService.roleSelect();
        request.setAttribute("roleList", tbRolesList);
        return "admin_user";
    }

    /**
     * 后台用户信息列表
     *
     * @param pages
     * @return
     */
    @RequestMapping("/findAdminUser")//后台用户信息列表
    @Log(operationName = "后台用户信息列表", operationType = "后台用户信息列表")
    public @ResponseBody
    String findAdminUser(Pages pages) {
        Map<String, Object> map = new HashMap<>();
        if (pages.getbUserName() != null) {//根据车牌来查询
            map.put("aName", pages.getbUserName());
        } else {
            map.put("aName", "");
        }
        if (pages.getEndTime() != null && pages.getEndTime().length() != 0) {
            map.put("endTime", pages.getEndTime());
        }
        if (pages.getBeginTime() != null && pages.getBeginTime().length() != 0) {
            map.put("beginTime", pages.getBeginTime());
        }
        List<TbAdmin> list = adminServiceImpl.findAdminPage(map, pages.getPage(), pages.getLimit());
        System.out.println("后台用户信息列表：" + list);
        int all = adminServiceImpl.findAdminNum(map);
        TableInfo tableInfo = new TableInfo(0, "后台用户信息列表", all, list);

        return new Gson().toJson(tableInfo);
    }

    /**
     * 日志查看主页
     *
     * @return
     */
    @RequestMapping("/logadmin")
    @Log(operationName = "日志查看主页", operationType = "日志查看主页")
    public String logadmin() {
        System.out.println("日志查看主页");
        return "back_log";
    }


    /**
     * delAdminUser 后台用户删除
     *
     * @param request
     * @param response
     */
    //删除
    @RequestMapping("/delAdminUser")
    @Log(operationName = "后台用户删除", operationType = "后台用户删除")
    public void delAdminUser(HttpServletRequest request, HttpServletResponse response) {
        String aid = request.getParameter("aid");
        adminServiceImpl.delAdminById(Integer.parseInt(aid));
        System.out.println(aid + "QWER");
    }

    /**
     * 后台用户添加
     *
     * @param tbAdmin
     * @return
     */
    @RequestMapping("/adminReg")//后台用户添加
    @Log(operationName = "后台用户添加", operationType = "后台用户添加")
    @ResponseBody
    public String adminReg(TbAdmin tbAdmin) {
        String adminmsg = null;
        System.out.println("后台用户数据：" + tbAdmin);
        String pwd = MD5util.code(tbAdmin.getApwd());
        tbAdmin.setApwd(pwd);
        int register = adminServiceImpl.insertAdminUser(tbAdmin);
        if (register > 0) {
            System.out.println("新增成功");
            adminmsg = "新增成功";
        }
        return adminmsg;
    }

    /**
     * updateAdmin 后台用户修改
     *
     * @param
     * @return
     */
//    后台用户信息修改
    @RequestMapping("/updateAdmin")
    @Log(operationName = "后台用户修改", operationType = "后台用户修改")
    @ResponseBody
    public String updateAdmin(@RequestParam("aId") int aId, @RequestParam("aName") String aName) {
        System.out.println("参数id" + aId + aName);
        String inputPar = null;
        int deletePar = adminServiceImpl.updateAdmin(aId, aName);
        if (deletePar > 0) {
            System.out.println("测试修改成功！");
            inputPar = "yes";
        } else {
            inputPar = "no";
        }
        return inputPar;
    }

    /**
     * 前台用户状态修改
     *
     * @param request
     * @param response
     * @param userId
     * @param userState
     * @throws IOException
     */
    @RequestMapping("/changeState")
    @Log(operationName = "前台用户状态修改", operationType = "前台用户状态修改")
    @ResponseBody
    public void changeState(HttpServletRequest request, HttpServletResponse response, String userId, String userState) throws IOException {
        System.out.println("用户id:" + userId);
        System.out.println("zhuangtai" + userState);
        boolean isSuccess = backUserServiceImpl.changeUserState(userId, userState);
        if (isSuccess) {
            response.getWriter().write("success");
        } else {
            response.getWriter().write("failed");
        }

    }


}
