package com.cykj.service.serviceImpl;

import com.cykj.bean.TbLog;
import com.cykj.bean.TbWhite;
import com.cykj.mapper.WhiteMapper;
import com.cykj.service.WhiteService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class WhiteServiceImpl implements WhiteService {
    @Resource
    private WhiteMapper whiteMapper;
    @Override
    public List<TbWhite> whiteuserSelect() {
        return null ;
    }

    @Override//白名单删除
    public int delWhiteById(int whiteid) {

        return whiteMapper.delWhiteById(whiteid);
    }

    @Override
    public List<TbWhite> findWhitePage(Map<String, Object> map, int curPage, int limit) {
        map.put("limit",limit);
        map.put("offset",(curPage-1)*limit);
        List<TbWhite> findWhitePage = whiteMapper.findWhitePage(map);
        return findWhitePage;
    }

    @Override
    public int findWhiteNum(Map<String, Object> map) {
        int all = whiteMapper.findWhiteNum(map);
        return all;
    }


    /**
     * 判断车牌是否为白名单
     * @param carNum
     * @return
     */
    @Override
    public Boolean findWhiteByCarNum(String carNum) {
        TbWhite tbWhite = whiteMapper.findWhiteByCarNum(carNum);
        if (null!=tbWhite){
            return true;
        }
        return false;
    }

    /**
     * 添加用户
     * @param tbWhite
     * @return
     */
    @Override
    public int addWhite(TbWhite tbWhite) {
        return whiteMapper.addWhite(tbWhite);
    }

    @Override
    public boolean changewhiteState(String whiteId, String wState) {
        return whiteMapper.changewhiteState(Integer.parseInt(whiteId),Integer.parseInt(wState));
    }
}
