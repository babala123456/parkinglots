package com.cykj.controller;


import com.alibaba.fastjson.JSON;
import com.cykj.bean.*;
import com.cykj.service.*;
import com.cykj.util.Common;
import com.cykj.util.Log;
import com.cykj.util.MD5util;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;



import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Administrator
 */
@Controller
public class LoginController {

    @Resource
    private SchedulesService schedulesServiceImpl;
    @Resource
    private BackUserService backUserServiceImpl;
    @Resource
    private WhiteService whiteServiceImpl;
    @Resource
    private AdminService adminServiceImpl;
    @Resource
    private WorkService workServiceImpl;


    @RequestMapping("/vlogin")
    @Log(operationName = "管理端登录",operationType = "管理端登录")
    public String vlogin() {
        return "back_login";

    }

    /**
     * 后台用户的登陆
     * @param name
     * @param pwd
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    @RequestMapping("/login")
    @Log(operationName = "开始登录",operationType = "开始登录")
    public @ResponseBody String login(String name, String pwd,HttpServletRequest request,HttpServletResponse response) throws IOException {

        String msg = "";
        //当前时间
        LocalDateTime now = LocalDateTime.now();
        String timeString = now.toString();

        System.out.println("当前时间："+timeString.split("T")[0] + ":"
                + timeString.split("T")[1]);

        //接收
        String pwd2 = MD5util.code(pwd);//登录之后进行密码的加密
        TbAdmin tbAdmin = adminServiceImpl.login(name,pwd2);
        if (tbAdmin != null){
            if(tbAdmin.getRoleIds() == 2) {
                System.out.println("登录成功");
                String tb = new Gson().toJson(tbAdmin);
                System.out.println("角色id：" + tbAdmin.getRoleIds());
                request.getSession().setAttribute("admin", tbAdmin);
                msg =  "success&" + tb;
            }else if(tbAdmin.getRoleIds() == 3){

                TbSchedules tbSchedules = schedulesServiceImpl.findByAdminId
                        (tbAdmin.getaId(),timeString.split("T")[0],
                                timeString.split("T")[1]);

                if(tbSchedules != null){
                    request.getSession().setAttribute("admin", tbAdmin);
                    String tb = new Gson().toJson(tbAdmin);

                    request.getSession().setAttribute("schedule",tbSchedules.getsId());

                    String workDay = tbSchedules.getWorkDay();

                    TbWork tbWork = workServiceImpl.findWork(tbSchedules.getWorkId());
                    String startTime = tbWork.getStarTime();
                    String endTime = tbWork.getEndTime();

                    //收费员上班时间
                    LocalDateTime start = Common.getDateTime(workDay + " " + startTime);
                    LocalDateTime canLog = Common.getDateTime(workDay + " " + endTime);
                    //判定五分钟后的时间
                    LocalDateTime end = LocalDateTime.of(start.getYear(),start.getMonth(),
                            start.getDayOfMonth(), start.getHour(),
                            start.getMinute() + 5, start.getSecond());

                    //在上班前五分钟
                    if(now.compareTo(start) > 0 && now.compareTo(end) < 0){
                        msg =  "tip&" + tb;
                    }else{
                        msg =  "success&" + tb;
                    }
                } else{
                    String tb = new Gson().toJson(tbAdmin);
                    msg = "not&" + tb;
                }
            }
        }else {
            System.out.println("登录失败");
            msg =  "fail";
        }
        return msg;
    }

    /**
     * 返回注册页面
     * @return
     */
    @RequestMapping("/vregin")//前台注册
    @Log(operationName = "返回注册页面",operationType = "返回注册页面")
    public String regin() {
        System.out.println("5222225！");
        return "front_register";
    }

    /**
     * 进行注册
     * @param tbUser
     * @return
     */
    @RequestMapping("/rega")
    @Log(operationName = "进行注册",operationType = "进行注册")
        @ResponseBody
        public String outReg(TbUser tbUser ){
            String msg = null;
            System.out.println("用户数据2："+tbUser);
           List<TbUser>userList = backUserServiceImpl.selectAccount(tbUser.getAccount());
           if (userList.size()>0){
               msg="账号重复";
           }else {
               String pwd = MD5util.code(tbUser.getPassword());
               tbUser.setPassword(pwd);
               int register = backUserServiceImpl.insertUser(tbUser);
               if (register>0){
                   System.out.println("注册成功");
                   msg="注册成功";
               }else{
                   msg = "fail";
               }
           }
            return msg;
    }

    /**
     * 修改用户数据
     * @param
     * @return
     */
    @RequestMapping("/updateUser")
    @Log(operationName = "修改用户数据",operationType = "修改用户数据")
    @ResponseBody
    public String updateUser(@RequestParam("userId")int userId, @RequestParam("userName")String userName, @RequestParam("phone")String phone
            , @RequestParam("email")String email){
        System.out.println("用户id"+userId+userName+phone+email);
        String inputPar = null;
        int deletePar = backUserServiceImpl.updateUser(userId, userName,phone,email);
        if (deletePar>0){
            System.out.println("测试修改成功！");
            inputPar="yes";
        }else {
            inputPar="no";
        }
        return inputPar;
    }

    /**
     * 前台用户删除
     * @param request
     * @param response
     * @param userId
     * @return
     */
    @RequestMapping("/deFrontUser")//前台用户删除
    @Log(operationName = "进行前台用户删除",operationType = "进行前台用户删除")
    @ResponseBody
    public String deFrontUser(HttpServletRequest request, HttpServletResponse response,String userId ){
        System.out.println("usersid:"+userId);
        int i = backUserServiceImpl.deFrontUser(Integer.parseInt(userId));
        System.out.println("i:"+i);
        if(i>0){
            System.out.println("删除成功");
            return "success";
        }else{
            System.out.println("删除失败");
            return "lose";
        }
    }

    /**
     * 返回前台用户信息列表
     * @return
     */
    //返回前台用户信息列表
    @RequestMapping("/frontuser")
    @Log(operationName = "返回前台用户信息列表",operationType = "返回前台用户信息列表")
    public String user() {
        return "front_user";
    }

    /**
     * 前台用户信息列表
     * @param pages
     * @return
     */
    @RequestMapping("/findUser")//前台名单
    @Log(operationName = "前台用户信息列表",operationType = "前台用户信息列表")
    public @ResponseBody String findUser(Pages pages){
        Map<String,Object> map = new HashMap<>();
        if (pages.getbUserName() != null){
            map.put("userName",pages.getbUserName());
        } else {
            map.put("userName","");
        }
        if (pages.getEndTime() != null&&pages.getEndTime().length() !=0){
            map.put("endTime",pages.getEndTime());
        }
        if (pages.getBeginTime() != null&&pages.getBeginTime().length() !=0){
            map.put("beginTime",pages.getBeginTime());
        }
        List<TbUser> list = backUserServiceImpl.finduserPage(map,pages.getPage(),pages.getLimit());
        System.out.println("前台用户查看数据："+list);
        int all = backUserServiceImpl.finduserNum(map);
        TableInfo tableInfo = new TableInfo(0,"日前台用户查看数据信息",all,list);
        return new Gson().toJson(tableInfo);
    }

    /**
     * 返回白名单用户信息列表
     * @return
     */
    @RequestMapping("/whitelist")
    @Log(operationName = "返回白名单用户信息列表",operationType = "返回白名单用户信息列表")
    public String whiteusercon() {
        return "back_whitelist";
    }

    /**
     * 白名单用户信息列表
     * @param pages
     * @return
     */
    @RequestMapping("/whiteuser")//白名单
    @Log(operationName = "白名单用户信息列表",operationType = "白名单用户信息列表")
    public @ResponseBody String findLog(Pages pages){
        Map<String,Object> map = new HashMap<>();
        if (pages.getbUserName() != null){//根据车牌来查询
            map.put("carNum",pages.getbUserName());
        } else {
            map.put("carNum","");
        }
        if (pages.getEndTime() != null&&pages.getEndTime().length() !=0){
            map.put("endTime",pages.getEndTime());
        }
        if (pages.getBeginTime() != null&&pages.getBeginTime().length() !=0){
            map.put("beginTime",pages.getBeginTime());
        }
        List<TbWhite> list = whiteServiceImpl.findWhitePage(map,pages.getPage(),pages.getLimit());
        System.out.println("白名单："+list);
        int all = whiteServiceImpl.findWhiteNum(map);
        TableInfo tableInfo = new TableInfo(0,"白名单数据信息",all,list);

        return new Gson().toJson(tableInfo);
    }

    /**
     * 白名单删除
     * @param request
     * @param response
     * @param whiteid
     */
    @RequestMapping("/delWhiteUser")//白名单删除
    @Log(operationName = "白名单删除",operationType = "白名单删除")
    public void delWhiteUser(HttpServletRequest request, HttpServletResponse response,String whiteid ){
        whiteServiceImpl.delWhiteById(Integer.parseInt(whiteid));
        System.out.println(whiteid);
    }

    /**
     * 白名单用户添加
     * @param carNum
     * @param regtime
     * @return
     */
    @RequestMapping("/addWhite")//白名单用户添加
    @Log(operationName = "白名单用户添加",operationType = "白名单用户添加")
    @ResponseBody
    public String addWhite(String carNum,String regtime ){
        String whitemsg = null;
        System.out.println("后台用户数据："+regtime);
        TbWhite tbWhite = new TbWhite();
        tbWhite.setCarNum(carNum);
        tbWhite.setRegtime(regtime);
        int register = whiteServiceImpl.addWhite(tbWhite);
        if (register>0){
            System.out.println("新增成功");
            whitemsg="新增成功";
        }
        return whitemsg;
    }

    /**
     *
     * @param request
     * @param response
     * @param whiteId
     * @param wState
     * @throws IOException
     */
    @RequestMapping("/changewhiteState")
    @Log(operationName = "前台用户状态修改",operationType = "前台用户状态修改")
    @ResponseBody
    public void changewhiteState(HttpServletRequest request, HttpServletResponse response, String whiteId, String wState) throws IOException {
        System.out.println("用户id:" + whiteId);
        System.out.println("zhuangtai"+wState);
        boolean isSuccess = whiteServiceImpl.changewhiteState(whiteId, wState);
        if (isSuccess) {
            response.getWriter().write("success");
        } else {
            response.getWriter().write("failed");
        }

    }
    /**
     * 后台界面内部内容展示
     * @return
     */
    @RequestMapping("/cartoon")//后台界面内部内容展示
    @Log(operationName = "后台界面内部内容展示",operationType = "后台界面内部内容展示")
    public String cartoon(){
        return "cartoon";
    }
}
