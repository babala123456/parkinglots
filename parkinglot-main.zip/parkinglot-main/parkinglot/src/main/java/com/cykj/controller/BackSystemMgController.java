package com.cykj.controller;


import com.cykj.bean.*;
import com.cykj.mapper.RoleMapper;
import com.cykj.service.*;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class BackSystemMgController {
    @Resource
    private RoleMapper roleMapper;
    @Resource
    private MenuService menuServiceImpl;
    @Resource
    private PowerService powerServiceImpl;
    @Resource
    private RoleService roleServiceImpl;
    @Resource
    private ParameterService parameterServiceImpl;
    @Resource
    private TableInfo tableInfo;

    @Resource
    private HandleService handleServiceImpl;
    /**
     * 后台页面
     * @param request
     * @return
     */
    @RequestMapping("/menu")
    @Log(operationName = "返回后台页面",operationType = "")
    public String menu(HttpServletRequest request) {
        TbAdmin admin = (TbAdmin) request.getSession().getAttribute("admin");
        Map<String, List<TbMenu>> menuMap = null;
        //在没有进行登录的时候，默认登录管理员的
        if (null == admin) {
            return "back_login";
        } else {
            menuMap = menuServiceImpl.findMenusByPid(Integer.toString(admin.getRoleIds()), 0);
            request.setAttribute("menuMap", menuMap);
            request.setAttribute("adminName", admin.getaName());
        }
        return "back_home";
    }

    /**
     * 返回权限页面
     * 2020年11月23日15:39:32
     * @return
     */
    @RequestMapping("/gotoBackRole")
    @Log(operationName = "返回权限页面",operationType = "")
    public String gotoBackRole(){
        return "back_role_list";
    }

    /**
     * 根据id 查询所拥有的的权限
     * 2020年11月23日15:38:46
     * @param RoleId
     */
    @RequestMapping("backPermission")
    @Log(operationName = "查询所拥有的权限",operationType = "")
    public String backPermission(int RoleId,HttpServletRequest request){
        Object[] menu = menuServiceImpl.findMenu(RoleId);
        //返回数据至页面
        request.setAttribute("haveMap",menu[0]);
        request.setAttribute("noneMap",menu[1]);
        request.setAttribute("roleId",RoleId);
        return "authorityMan";
    }

    /**
     * 康春杰
     * [权限配置功能]选择权限----查询 所有 角色
     * 2020年11月23日15:38:54
     * @return
     */
    @RequestMapping("findRole")
    @ResponseBody
    @Log(operationName = "权限的选择",operationType = "")
    public String role(){
        List<TbRole> roleList = roleMapper.findRole();
        tableInfo.setCode(0);
        tableInfo.setCount(roleList.size());
        tableInfo.setData(roleList);
        tableInfo.setMsg("角色列表");
        String roleJson = new Gson().toJson(tableInfo);
        return roleJson;
    }

    @RequestMapping("save")
    @ResponseBody
    @Log(operationName = "保存权限设置",operationType = "")
    public String savePower(String arr ,int rid){
        System.out.println("id:"+arr);
        System.out.println("rid:"+rid);

        String result = powerServiceImpl.judgePower(arr, rid);

        return result;
    }

    /**
     * 参数配置表
     * @return
     */
    @RequestMapping("/parameter")//参数配置表
    @Log(operationName = "参数配置表",operationType = "")
    public String parameter(){
        return "back_parameter";
    }

    /**
     * 参数配置传输数据
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/backParameter")//参数传值
    @Log(operationName = "参数配置传输数据",operationType = "")
    public @ResponseBody String backParameter(HttpServletRequest request, HttpServletResponse response, Pages pages) throws IOException {
        Map<String,Object> map = new HashMap<>();

        if (pages.getbUserName() != null){
            map.put("pType",pages.getbUserName());
        } else {
            map.put("pType","");
        }
        List<TbParameter> list = parameterServiceImpl.findParameterOnPage(map,pages.getPage(),pages.getLimit());
        System.out.println("参数数据："+list);
        int all = parameterServiceImpl.findParameterNum(map);
        TableInfo tableInfo = new TableInfo(0,"参数信息",all,list);
        return new Gson().toJson(tableInfo);
    }

    /**
     * 删除数据
     * @param pId
     * @return
     */
    @RequestMapping("/deleteParameter")//删除参数
    @Log(operationName = "删除数据",operationType = "")
    @ResponseBody
    public String deleteParameter(@RequestParam("pId")int pId){
        String inputPar = null;
        int deletePar = parameterServiceImpl.deleteParameter(pId);
        if (deletePar>0){
            inputPar="yes";
        }else {
            inputPar="no";
        }
     return inputPar;
    }

    /**
     * 更改参数
     * @param pId
     * @param pType
     * @param pValue
     * @return
     */
    @RequestMapping("/updaterParameter")//修改参数
    @Log(operationName = "更改参数",operationType = "")
    @ResponseBody
    public String updateParameter(@RequestParam("pId")int pId,@RequestParam("pType")String pType,@RequestParam("pValue")String pValue){
        System.out.println("参数id"+pId+pValue+pType);
        String inputPar = null;
        int deletePar = parameterServiceImpl.updateParameter(pId, pType, pValue);
        if (deletePar>0){
            System.out.println("测试修改成功！");
            inputPar="yes";
        }else {
            inputPar="no";
        }
        return inputPar;
    }

    /**
     * 添加参数
     * @param pType
     * @param pValue
     * @return
     */
    @RequestMapping("/insertParameter")//添加参数
    @Log(operationName = "添加参数",operationType = "")
    @ResponseBody
    public String insertParameter(@RequestParam("pType")String pType,@RequestParam("pValue")String pValue){
        System.out.println("添加的参数："+pValue+pType);
        String inputPar = null;
        int insertPar = parameterServiceImpl.insertParameter(pType, pValue);
        if (insertPar > 0){
            System.out.println("测试添加成功！");
            inputPar="yes";
        }else {
            inputPar="no";
        }
        return inputPar;
    }


    /**
     * 菜单管理表
     * @param request
     * @return
     */
    @RequestMapping("/menuMnagement")//菜单管理
    @Log(operationName = "菜单管理表",operationType = "")
    public String menuMnagement(HttpServletRequest request){
        List<TbMenu> list = new ArrayList<>();
        List<TbMenu> fMenuList = menuServiceImpl.Menu();//拿到菜单
        for (TbMenu menu : fMenuList){
            if (menu.getRelevanceId().equals("0")){
                list.add(menu);
            }
        }
        request.setAttribute("menuList",list);
        return "back_menuMg";
    }

    /**
     * 传输菜单数据
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/inputMenu")//输入菜单值
    @Log(operationName = "传输菜单数据",operationType = "")
    @ResponseBody
    public String inputMenu(HttpServletRequest request, HttpServletResponse response, Pages pages) throws IOException {
        Map<String,Object> map = new HashMap<>();

        if (pages.getbUserName() != null){
            map.put("menuName",pages.getbUserName());
        } else {
            map.put("menuName","");
        }
        List<TbMenu> list = menuServiceImpl.findMenuPage(map,pages.getPage(),pages.getLimit());
        System.out.println("菜单数据："+list);
        int all = menuServiceImpl.findMenuNum(map);
        TableInfo tableInfo = new TableInfo(0,"菜单信息表",all,list);
        return new Gson().toJson(tableInfo);
    }

    /**
     * 删除菜单
     * @param menuId
     * @return
     */
    @RequestMapping("/deleteMenu")//删除菜单
    @Log(operationName = "删除菜单",operationType = "")
    @ResponseBody
    public String deleteMenu(@RequestParam("menuId")int menuId){
        String inputMenu = null;
        System.out.println("菜单id："+menuId);
        int deleteMenu = menuServiceImpl.deleteMenu(menuId);
        if (deleteMenu>0){
            inputMenu="yes";
        }else {
            inputMenu="no";
        }
        return inputMenu;
    }

    /**
     * 更改菜单
     * @param menuId
     * @param menuName
     * @param menuPath
     * @param relevanceId
     * @return
     */
    @RequestMapping("/updateMenu")//修改菜单
    @Log(operationName = "更改菜单",operationType = "")
    @ResponseBody
    public String updateMenu(@RequestParam("menuId")int menuId,@RequestParam("menuName")String menuName,@RequestParam("menuPath")String menuPath,@RequestParam("relevanceId")String relevanceId){
        System.out.println("修改的菜单id"+menuId+menuName+menuPath+relevanceId);
        String inputMenu = null;
        int deleteMenu = menuServiceImpl.updateMenu(menuId, menuName, menuPath, relevanceId);
        if (deleteMenu>0){
            System.out.println("测试修改成功！");
            inputMenu="yes";
        }else {
            inputMenu="no";
        }
        return inputMenu;
    }

    /**
     * 添加的菜单
     * @param menuName
     * @param menuPath
     * @param relevanceId
     * @return
     */
    @RequestMapping("/insertMenu")//添加的菜单
    @Log(operationName = "添加的菜单",operationType = "")
    @ResponseBody
    public String insertMenu(@RequestParam("menuName")String menuName,@RequestParam("menuPath")String menuPath,@RequestParam("relevanceId")String relevanceId){
        System.out.println("添加的菜单："+menuName+menuPath+relevanceId);
        String inputMenu = null;
        int insertMenu = menuServiceImpl.insertMenu(menuName, menuPath, relevanceId);
        if (insertMenu > 0){
            System.out.println("测试添加成功！");
            inputMenu="yes";
        }else {
            inputMenu="no";
        }
        return inputMenu;
    }

    /**
     * 后台权限配置角色表
     * @return
     */
    @RequestMapping("/backRoles")
    @Log(operationName = "后台权限配置角色表",operationType = "")
    public String backRole(){
        return "back_roleMg";
    }

    /**
     * 角色表
     * @param pages
     * @return
     */
    @RequestMapping("/roleList")
    @Log(operationName = "角色表",operationType = "")
    public @ResponseBody String rolet(Pages pages){
        Map<String,Object> map = new HashMap<>();
        if (pages.getbUserName() != null){
            map.put("userRole",pages.getbUserName());
        } else {
            map.put("userRole","");
        }
        List<TbRole> list = roleServiceImpl.findRolePage(map,pages.getPage(),pages.getLimit());
        System.out.println("角色数据："+list);
        int all = roleServiceImpl.findRoleNum(map);
        TableInfo tableInfo = new TableInfo(0,"角色信息表",all,list);
        return new Gson().toJson(tableInfo);
    }

    /**
     * 更改角色
     * @return
     */
    @RequestMapping("/updateRole")
    @Log(operationName = "更改角色",operationType = "")
    public @ResponseBody String updateRole(@RequestParam("roleId")int roleId,@RequestParam("userRole")String userRole){
        System.out.println("更改角色："+userRole+roleId);
        String inputRole = null;
        int updateRole = roleServiceImpl.updateRole(roleId, userRole);
        if (updateRole > 0){
            System.out.println("测试更改角色成功！");
            inputRole="yes";
        }else {
            inputRole="no";
        }
        return inputRole;
    }

    /**
     * 添加角色
     * @return
     */
    @RequestMapping("/insertRole")
    @Log(operationName = "添加角色",operationType = "")
    public @ResponseBody String insertRole(@RequestParam("userRole")String userRole){
        System.out.println("添加角色："+userRole);
        String inputRole = null;
        int insertRole = roleServiceImpl.insertRole(userRole);
        if (insertRole > 0){
            System.out.println("测试添加成功！");
            inputRole="yes";
        }else {
            inputRole="no";
        }
        return inputRole;
    }

    /**
     * 后台车辆管理
     * @return
     */
    @RequestMapping("/backCarManagement")
    @Log(operationName = "后台车辆管理",operationType = "")
    public String backCarManagement(){
        System.out.println("车辆管理ID：");
        return "back_carMg";
    }

    /**
     * 返回预约管理界面
     * @return
     */
    @RequestMapping("/backBookingMag")
    @Log(operationName = "后台车辆管理",operationType = "")
    public String backBookingMag(){
        System.out.println("车辆管理ID：");
        return "bookingLogMag";
    }

    /**
     * 车辆管理信息
     * @param request
     * @param response
     * @param pages
     * @return
     * @throws IOException
     */
    @RequestMapping("/inputCar")//车辆管理信息
    @Log(operationName = "车辆管理信息",operationType = "")
    @ResponseBody
    public String inputCar(HttpServletRequest request,HttpServletResponse response,Pages pages) throws IOException {
        Map<String,Object> map = new HashMap<>();

        if (pages.getbUserName() != null){
            map.put("carNum",pages.getbUserName());
        } else {
            map.put("carNum","");
        }
        List<TbHandle> list = handleServiceImpl.findHandlePage(map,pages.getPage(),pages.getLimit());
        System.out.println("车辆数据："+list);
        int all = handleServiceImpl.findHandleNum(map);
        TableInfo tableInfo = new TableInfo(0,"车辆信息表",all,list);
        return new Gson().toJson(tableInfo);
    }



}
