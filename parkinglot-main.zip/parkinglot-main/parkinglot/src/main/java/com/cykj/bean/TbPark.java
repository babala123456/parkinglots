package com.cykj.bean;

import org.springframework.stereotype.Component;

/**
 * @author Administrator
 */
@Component
public class TbPark {

  private int parkId;
  private int carId;
  private int placeId;
  private String enterTime;
  private String outTime;
  private String enterImg;
  private String outImg;
  private int parkState;

  public TbPark() {

  }

  public TbPark(int parkId, int carId, int placeId, String enterTime, String outTime, String enterImg, String outImg, int parkState) {
    this.parkId = parkId;
    this.carId = carId;
    this.placeId = placeId;
    this.enterTime = enterTime;
    this.outTime = outTime;
    this.enterImg = enterImg;
    this.outImg = outImg;
    this.parkState = parkState;
  }

  @Override
  public String toString() {
    return "TbPark{" +
            "parkId=" + parkId +
            ", carId=" + carId +
            ", placeId=" + placeId +
            ", enterTime='" + enterTime + '\'' +
            ", outTime='" + outTime + '\'' +
            ", enterImg='" + enterImg + '\'' +
            ", outImg='" + outImg + '\'' +
            ", parkTime=" + parkState +
            '}';
  }

  public int getParkState() {
    return parkState;
  }

  public void setParkState(int parkState) {
    this.parkState = parkState;
  }

  public String getEnterImg() {
    return enterImg;
  }

  public void setEnterImg(String enterImg) {
    this.enterImg = enterImg;
  }

  public String getOutImg() {
    return outImg;
  }

  public void setOutImg(String outImg) {
    this.outImg = outImg;
  }

  public int getParkId() {
    return parkId;
  }

  public void setParkId(int parkId) {
    this.parkId = parkId;
  }

  public int getCarId() {
    return carId;
  }

  public void setCarId(int carId) {
    this.carId = carId;
  }

  public int getPlaceId() {
    return placeId;
  }

  public void setPlaceId(int placeId) {
    this.placeId = placeId;
  }

  public String getEnterTime() {
    return enterTime;
  }

  public void setEnterTime(String enterTime) {
    this.enterTime = enterTime;
  }

  public String getOutTime() {
    return outTime;
  }

  public void setOutTime(String outTime) {
    this.outTime = outTime;
  }
}
