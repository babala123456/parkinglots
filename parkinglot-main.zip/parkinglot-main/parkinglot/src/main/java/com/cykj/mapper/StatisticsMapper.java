package com.cykj.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface StatisticsMapper {
//    public int findStatistics(@Param("times") String times,@Param("i") int i,@Param("productId") int productId);
    public int findComboMenu(@Param("productId") int productId);
    public int findusergrowth(@Param("nowData") String nowData,@Param("mouth") int mouth,@Param("userType") int userType);
    public int findwhiteuser(@Param("nowData") String nowData,@Param("mouth") int mouth);
}
