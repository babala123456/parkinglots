package com.cykj.controller;

import com.cykj.bean.Pages;
import com.cykj.bean.TableInfo;
import com.cykj.bean.TbRecord;
import com.cykj.bean.TbRefund;
import com.cykj.service.RecordService;
import com.cykj.service.RefundService;
import com.cykj.util.Log;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class IncomeController {

    @Resource
    private RecordService recordService;
    @Resource
    private RefundService refundService;
    /**
     * 收入表
     * @return
     */
    @RequestMapping("/backIncomeList")//收入表
    @Log(operationName = "收入表",operationType = "")
    public String backIncomeList(){
        return "back_incomeList";
    }

    /**
     * 收入表传输数据
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/backIncomeData")//收入表传值
    @Log(operationName = "收入表传值",operationType = "")
    public @ResponseBody String backIncomeData(HttpServletRequest request, HttpServletResponse response, Pages pages) throws IOException {
        Map<String,Object> map = new HashMap<>();

        if (pages.getbUserName() != null){
            map.put("carNum",pages.getbUserName());
        } else {
            map.put("carNum","");
        }
        List<TbRecord> list = recordService.findRecordPage(map,pages.getPage(),pages.getLimit());
        int all = recordService.findRecordNum(map);
        TableInfo tableInfo = new TableInfo(0,"收入表信息",all,list);
        return new Gson().toJson(tableInfo);
    }

//    /**
//     * 收入表删除数据
//     * @param pId
//     * @return
//     */
//    @RequestMapping("/deleteIncome")//删除收入表
//    @ResponseBody
//    public String deleteIncome(@RequestParam("pId")int pId){
//        String inputPar = null;
//        int deletePar = parameterServiceImpl.deleteParameter(pId);
//        if (deletePar>0){
//            inputPar="yes";
//        }else {
//            inputPar="no";
//        }
//        return inputPar;
//    }
//
//    /**
//     * 更改收入表
//     * @param pId
//     * @param pType
//     * @param pValue
//     * @return
//     */
//    @RequestMapping("/updaterIncome")//修改收入表
//    @ResponseBody
//    public String updaterIncome(@RequestParam("pId")int pId,@RequestParam("pType")String pType,@RequestParam("pValue")String pValue){
//        System.out.println("收入表id"+pId+pValue+pType);
//        String inputPar = null;
//        int deletePar = parameterServiceImpl.updateParameter(pId, pType, pValue);
//        if (deletePar>0){
//            System.out.println("收入表修改成功！");
//            inputPar="yes";
//        }else {
//            inputPar="no";
//        }
//        return inputPar;
//    }
//
//    /**
//     * 添加收入表
//     * @param pType
//     * @param pValue
//     * @return
//     */
//    @RequestMapping("/insertIncome")//添加收入表
//    @ResponseBody
//    public String insertIncome(@RequestParam("pType")String pType,@RequestParam("pValue")String pValue){
//        System.out.println("添加的收入表："+pValue+pType);
//        String inputPar = null;
//        int insertPar = parameterServiceImpl.insertParameter(pType, pValue);
//        if (insertPar > 0){
//            System.out.println("收入表加成功！");
//            inputPar="yes";
//        }else {
//            inputPar="no";
//        }
//        return inputPar;
//    }



    /**
     * 退费表
     * @return
     */
    @RequestMapping("/backProduct")//退费表
    @Log(operationName = "退费表",operationType = "")
    public String backProduct(){
        return "back_productLIst";
    }

    /**
     * 退费表传输数据
     * @param request
     * @param response
     * @throws IOException
     */
    @RequestMapping("/backProductData")//退费表传值
    @Log(operationName = "退费表传值",operationType = "")
    public @ResponseBody String backProductData(HttpServletRequest request, HttpServletResponse response, Pages pages) throws IOException {
        Map<String,Object> map = new HashMap<>();

        if (pages.getbUserName() != null){
            map.put("proName",pages.getbUserName());
        } else {
            map.put("proName","");
        }
        List<TbRefund> list = refundService.findRefundPage(map,pages.getPage(),pages.getLimit());
        int all = refundService.findRefundNum(map);
        TableInfo tableInfo = new TableInfo(0,"退费表信息",all,list);
        return new Gson().toJson(tableInfo);
    }

}
