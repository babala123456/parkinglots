package com.cykj.mapper;

import com.cykj.bean.TbParameter;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Mapper
public interface ParameterMapper {
    public List<TbParameter> findParameterOnPage(Map<String, Object> map);//查询数据与模糊查询
    public int findParameterNum(Map<String, Object> map);//分页查询

    public List<TbParameter> selectParameter();//查询所有参数
    public int deleteParameter(@Param("pId") int pId);//删除参数
    public int updateParameter(@Param("pId") int pId, @Param("pType") String pType,
           @Param("pValue") String pValue);//更改参数
    public int insertParameter(@Param("pType") String pType,
           @Param("pValue") String pValue);//添加参数


    public String findByType(@Param("pType") String pType);


    /**
     * 根据参数类型查询同类型的所有参数信息
     * @param pType
     * @return
     */
    public List<TbParameter> findTypeList(@Param("pType") String pType);
}
