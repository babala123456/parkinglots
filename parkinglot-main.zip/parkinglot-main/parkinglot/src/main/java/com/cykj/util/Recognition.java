package com.cykj.util;

import com.alibaba.fastjson.JSON;
import com.baidu.aip.util.Base64Util;
import com.cykj.bean.RecognitionInfo;

import java.net.URLEncoder;
import java.util.regex.Pattern;

/**
 * @author Administrator
 */
public class Recognition {

    public static String CAR_URL = "https://aip.baidubce.com/rest/2.0/ocr/v1/license_plate";
    public static final String CAR_ACCESS_TOKEN = "24.a8a55633d8dcd2c7459e116afbca6066.2592000.1608107164.282335-22989808";



    public Recognition() {

    }

    public static String licensePlateRecognition( String imgPath ) {
        // 请求url
        try {
            // 本地文件路径
            String filePath = imgPath;
            byte[] imgData = FileUtil.readFileByBytes(filePath);
            String imgStr = Base64Util.encode(imgData);
            String imgParam = URLEncoder.encode(imgStr, "UTF-8");

            String param = "image=" + imgParam;

            // 注意这里仅为了简化编码每一次请求都去获取access_token，线上环境access_token有过期时间， 客户端可自行缓存，过期后重新获取。

            String result = HttpUtil.post(CAR_URL, CAR_ACCESS_TOKEN, param);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 验证车牌
     * @param content
     * @return
     */
    public static boolean checkPlateNumberFormat(String content) {
        String pattern = "([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼]{1}(([A-HJ-Z]{1}[A-HJ-NP-Z0-9]{5})|([A-HJ-Z]{1}(([DF]{1}[A-HJ-NP-Z0-9]{1}[0-9]{4})|([0-9]{5}[DF]{1})))|([A-HJ-Z]{1}[A-D0-9]{1}[0-9]{3}警)))|([0-9]{6}使)|((([沪粤川云桂鄂陕蒙藏黑辽渝]{1}A)|鲁B|闽D|蒙E|蒙H)[0-9]{4}领)|(WJ[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼·•]{1}[0-9]{4}[TDSHBXJ0-9]{1})|([VKHBSLJNGCE]{1}[A-DJ-PR-TVY]{1}[0-9]{5})";
        return Pattern.matches(pattern, content);
    }




    public static void main(String[] args) {
        String result = licensePlateRecognition("F:/A-Study/第四阶段/智能停车系统/测试/timg.jpg");
        RecognitionInfo recognitionInfo = JSON.parseObject(result, RecognitionInfo.class);
        System.out.println(recognitionInfo.getWordsResult().getNumber());
    }

}
