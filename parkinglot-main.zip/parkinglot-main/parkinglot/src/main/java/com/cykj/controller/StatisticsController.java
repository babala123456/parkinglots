package com.cykj.controller;

import com.cykj.service.StatisticsService;
import com.cykj.util.Log;
import org.springframework.core.NamedInheritableThreadLocal;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Administrator
 */
@Controller
public class StatisticsController {
    @Resource
    public StatisticsService statisticsServiceImp;

    @RequestMapping("/statistics")
    @Log(operationName = "渠道量统计数据",operationType = "")
    public String statistics(HttpServletRequest request) {
        //设置日期格式
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        List<Integer> Integerlist = new ArrayList<Integer>();
        List<Integer> usergrowthlist = new ArrayList<Integer>();
        List<Integer> usergrowthlist1 = new ArrayList<Integer>();
        List<Integer> whiteuserlist = new ArrayList<Integer>();
        for(int i = 1;i<6;i++){
            int k = statisticsServiceImp.findComboMenu(i);
            Integerlist.add(k);
        }

        for(int i = 0;i<6;i++){
            int k = statisticsServiceImp.findusergrowth(df.format(new Date()),i,24);
            int j = statisticsServiceImp.findusergrowth(df.format(new Date()),i,23);
            usergrowthlist.add(k);
            usergrowthlist1.add(j);
        }
        for (int i = 0;i<6;i++){
            int o = statisticsServiceImp.findwhiteuser(df.format(new Date()),i);
            whiteuserlist.add(o);
        }
        request.setAttribute("Integerlist",Integerlist);
        request.setAttribute("usergrowthlist",usergrowthlist);
        request.setAttribute("usergrowthlist1",usergrowthlist1);
        request.setAttribute("whiteuserlist",whiteuserlist);
        return "Statistics";
    }

}
