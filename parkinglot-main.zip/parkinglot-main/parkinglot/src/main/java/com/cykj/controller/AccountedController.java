package com.cykj.controller;


import com.alibaba.fastjson.JSON;
import com.cykj.bean.MyAccounted;
import com.cykj.bean.TableInfo;
import com.cykj.bean.TbAdmin;
import com.cykj.service.AccountedService;
import com.cykj.util.Common;
import com.cykj.util.Log;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/accounted")
public class AccountedController {

    @Resource
    private AccountedService accountedServiceImpl;


    /**
     * 跳转日结算页面
     * @return
     */
    @RequestMapping("/toAccounted")
    @Log(operationName = "访问日结算页面",operationType = "访问日结算页面")
    public String toAccounted(){
        return "back_accounted";
    }


    /**
     * 查询日结算基础信息方法
     * @return
     */
    @RequestMapping("/findAccounteds")
    @Log(operationName = "获取日结算数据",operationType = "获取日结算数据")
    public void findAccounteds(HttpServletRequest request, HttpServletResponse response) throws IOException {

        TableInfo tableInfo = new TableInfo();
        String totalPark = "";
        String totalFee = "";

        String curPage = request.getParameter("page");
        String pageSize = request.getParameter("limit");
        int cur = Integer.parseInt(curPage);
        int sizes = Integer.parseInt(pageSize);

        TbAdmin admin = (TbAdmin) request.getSession().getAttribute("admin");
        int schedule = (int) request.getSession().getAttribute("schedule");

        //获取日计算基本信息
        String msg = accountedServiceImpl.findAccounts(admin.getaId(),
                (cur - 1) * sizes,sizes,schedule);

        if(Common.notEmpty(msg)){
            String listJson = msg.split("/")[0];

            if(!listJson.equals("first work")){
                List<MyAccounted> list = new Gson().fromJson
                        (listJson, new TypeToken<List<MyAccounted>>(){}.getType());
          
                tableInfo.setData(list);

                totalPark = msg.split("/")[1];
                totalFee = msg.split("/")[2];
                System.out.println("totalpark:"+totalPark);
                System.out.println("totalFee:"+totalFee);
            }else{
                totalPark = "0";
                totalFee = "0";
            }

            request.getSession().setAttribute("totalPark", totalPark);
            request.getSession().setAttribute("totalFee", totalFee);

            tableInfo.setCount(Integer.parseInt(totalPark));
        }

        tableInfo.setCode(0);
        tableInfo.setMsg("日结算列表数据信息");

        String json = new Gson().toJson(tableInfo);
        response.getWriter().write(json);
    }

}
