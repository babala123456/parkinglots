package com.cykj.service;

import com.cykj.bean.TbBooking;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author Administrator
 */
public interface BookingService {

    /**
     * 康春杰
     * [车辆预约功能] --添加预约
     * @param tbBooking
     * @return
     */
    public String addBooking(TbBooking tbBooking);

    /**
     * 康春杰
     * [车位预约功能] --查询预约记录
     * 2020年11月29日15:43:00
     * @param carId
     * @return
     */
    public List<TbBooking> findBookingByCarId(int carId);

    /**
     * 康春杰
     * [车位预约功能] --查询预约记录 条数
     * 2020年11月29日15:43:00
     * @param  carId
     * @return
     */
    public int findBookingCountByCarId(int carId);


    /**
     * 康春杰
     * [车位预约功能] --查询预约记录
     * 2020年11月29日15:43:00
     * @return
     */
    public List<TbBooking> findBooking();

    /**
     * 康春杰
     * [车位预约功能] --查询预约记录 条数
     * 2020年11月29日15:43:00
     * @return
     */
    public int findBookingCount();



    /**
     * 康春杰
     * [车位预约功能] -- 查询 某一车牌的预约记录 / 是否预约
     * 2020年11月29日15:53:21
     * @param carId
     * @param bookingState
     * @return
     */
    public TbBooking whetherBooking(int carId,int bookingState);


    /**
     * 康春杰
     * [车位预约功能] -- 修改 预约状态为已失效，代表已出场或者 时间到了
     * 2020年11月29日17:09:20
     * @param bookingState
     * @param bookingId
     * @return
     */
    public int updateBookingState(@Param("bookingState")int bookingState, @Param("bookingId")int bookingId);

    /**
     * 康春杰
     * [后台管理预约记录功能] 删除记录
     * @param bookingId
     * @return
     */
    public int delBooking(@Param("bookingId")int bookingId);
}
