package com.cykj.service.serviceImpl;


import com.alibaba.fastjson.JSON;
import com.cykj.bean.*;
import com.cykj.mapper.*;
import com.cykj.service.AccountedService;
import com.cykj.service.ParkService;
import com.cykj.util.Common;
import org.omg.CosNaming.NamingContextPackage.NotEmpty;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class AccountedServiceImpl implements AccountedService {

    @Resource
    private AccountedMapper accountedMapper;
    @Resource
    private ParkService parkServiceImpl;
    @Resource
    private WorkMapper workMapper;
    @Resource
    private ParkMapper parkMapper;
    @Resource
    private RecordMapper recordMapper;
    @Resource
    private SchedulesMapper schedulesMapper;



    /**
     * 查询日结算信息方法
     * @return
     */
    @Override
    public String findAccounts(int adminId, Integer startIndex, Integer endIndex
            ,int schedule) {
        //变量定义
        double totalFee = 0;
        double fee = 0;
        String res = "";

        TbSchedules tbSchedules = schedulesMapper.findBySid(schedule);
        //查询当前收费员的班次信息
        TbWork nowWork = workMapper.findWork(tbSchedules.getWorkId());

        if(!nowWork.getStarTime().equals("00:00:00")){
            //获取当前日期 yyyy-MM-dd
            LocalDateTime outTime = LocalDateTime.now();
            String nowDay = outTime.toString().split("T")[0];
            //设置查询的时间条件
            String startTime = nowDay + " 00:00:00";
            String endTime = nowDay + " " + nowWork.getStarTime();
            //根据班次时间分页搜索日结算记录
            List<MyAccounted> list = accountedMapper.findAccounts(startTime, endTime,
                    startIndex, endIndex);
            //遍历日结算，根据停车时间计算停车费用，统计总收费
            if(list.size() > 0){
                for (MyAccounted myAccounted : list){

                    //根据车牌号和车辆入场时间，查询车辆的停车信息
                    TbPark park = parkMapper.findParkByNumt(myAccounted.getCarNum(),
                            myAccounted.getEnterTime());

                    if(Common.notEmpty(park.getOutTime())){
                        //根据停车记录id查询车辆的消费记录
                        TbRecord record = recordMapper.findByParkId(park.getParkId());
                        if(record != null){
                            //设置停车时间
                            myAccounted.setStay(record.getParkTime());
                            //设置费用
                            fee = Double.parseDouble(record.getMoneyPay());
                            myAccounted.setFee(fee);
                            //统计总收费
                            totalFee += fee;
                            //设置收费类型
                            int change = Math.toIntExact(record.getType());
                            myAccounted.setParkType(Common.getString(change));
                        }
                    }
                }
            }

            int totalPark = parkServiceImpl.findRecords(startTime, endTime);

            res = JSON.toJSONString(list) + "/" + totalPark + "/" + totalFee;
            System.out.println("日结算信息："+res);
        }else{
            res = "first work";
        }

        return res;
    }
}
